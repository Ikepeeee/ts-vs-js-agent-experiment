# Known difference: rename detection in `status --porcelain`

The specification lists rename detection as a non-goal, so tgit does not implement it. The real git still
detects renames among staged changes in `status --porcelain` by default (`status.renames` follows
`diff.renames`, which is on). The difference shows up when a staged deletion and a staged addition are similar
enough (git's similarity estimate of at least 50%), not only when they are identical.

The random generator hits this occasionally: with `--count 500`, seed 3 fails one sequence (`v1-random-0285`).
Reduced reproduction (not kept under `test/difftest/scenarios/`, because it is expected to fail while rename
detection stays out of scope):

```json
{
  "name": "status --porcelain: a staged deletion and a similar staged addition (rename)",
  "steps": [
    { "git": ["init", "-q"] },
    { "write": "日本.txt", "content": "gamma\nbeta\nepsilon\ntheta\nbeta\niota\n" },
    { "git": ["add", "-A"] },
    { "git": ["commit", "-q", "-m", "initial"] },
    { "delete": "日本.txt" },
    { "write": "a.txt", "content": "theta\nepsilon\neta\ngamma\n" },
    { "run": ["add", "-A"] },
    { "run": ["status", "--porcelain"], "matchOutput": true }
  ]
}
```

The real git prints `R  "\346\227\245\346\234\254.txt" -> a.txt`; tgit prints `A  a.txt` and
`D  "\346\227\245\346\234\254.txt"`. Supporting it would mean porting git's similarity estimation
(diffcore-rename) for `status`.
