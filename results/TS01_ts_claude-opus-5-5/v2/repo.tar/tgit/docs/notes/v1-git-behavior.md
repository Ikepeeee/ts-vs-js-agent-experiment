# Real git behavior confirmed for v1

Observed with the real git under the difftest environment (`LANG=C`, `TZ=UTC`, `init.defaultBranch=main`).
Each item was tried with the real git before it was implemented.

## Dispatch

- No command, or an unknown command: exit 1.
- A command that needs a repository, run outside one: `fatal: not a git repository (or any of the parent directories): .git`, exit 128.
- Unknown options and missing option values are usage errors: exit 129.

## init

- Prints `Initialized empty Git repository in <abs>/.git/`; `-q` prints nothing.
- On an existing repository: `Reinitialized existing Git repository in <abs>/.git/`. With `-b`, it warns
  `warning: re-init: ignored --initial-branch=<name>` and HEAD is unchanged.
- The config file is `[core]` with `repositoryformatversion = 0`, `filemode = true`, `bare = false`, `logallrefupdates = true`.
- `-b 'a..b'`: `fatal: invalid initial branch name: 'a..b'`, exit 128. The real git has already created `.git/`,
  `refs/heads`, `refs/tags`, and `config` by then (but not `HEAD` or `objects`), and leaves them behind.
- Two directory arguments, `-b` without a value, or an unknown option: exit 129.
- A directory argument that is an existing file: `fatal: cannot mkdir <arg>: File exists`, exit 128.

## hash-object

- Works outside a repository; `-w` outside one fails with 128.
- Follows symlinks. A directory: `fatal: Unable to hash <path>`, 128. A missing file:
  `fatal: could not open '<path>' for reading: No such file or directory`, 128.
- `hash-object -x.txt` is an unknown switch (129); `hash-object -- -x.txt` works.

## cat-file

- `-p` of a tree: `<mode padded to 6> <type> <oid>\t<name>`, so directories show as `040000 tree`. Names are
  quoted like `ls-files` (non-ASCII as octal escapes, spaces not quoted). `-p` of a commit prints it raw.
- The empty tree `4b825dc...` can be read even if it is not stored.
- An unknown object (including a well-formed 40-hex ID that does not exist): `fatal: Not a valid object name X`, 128.
- No arguments, `-p` without an object, a single argument without a mode, two modes, or too many arguments: 129.

## rev-parse

- Prints the full ID of each revision. A 40-hex ID is printed even if the object does not exist.
- `^0` is the commit itself; `^2` on a commit with one parent fails. `@` is `HEAD`.
- The first argument that is not a revision is printed, and then must be an existing path; if not:
  `fatal: ambiguous argument 'X': unknown revision or path not in the working tree.`, 128. Every later
  argument is printed and must be an existing path (`fatal: X: no such path in the working tree.`).
  The output printed before the error stays on stdout.
- Arguments starting with `-` are echoed. `--` is echoed and every later argument is printed without checks.
- An unborn `HEAD` prints `HEAD` and fails with 128. Outside a repository, even with no arguments: 128.
- Short IDs need at least 4 hex digits and must be unique; followed by `~`/`^`, only commits are considered.

## Abbreviated IDs (log --oneline, branch -d, detached HEAD)

- At least 7 characters, extended until no other object in the repository shares the prefix.

## add

- No arguments: `Nothing specified, nothing added.` plus hints on stderr, exit 0.
- A pathspec that matches no tracked file and no untracked, non-ignored file, and that does not exist on
  disk: `fatal: pathspec 'X' did not match any files`, 128, before anything is added.
- An ignored path named by a pathspec is reported on stderr (`The following paths are ignored by one of your
  .gitignore files:` and the path), exit 1, but the other paths are still added. The reported path is the
  ignored file, or the topmost ignored directory, that the pathspec names or lies inside of. For example,
  with `d/` ignored, `add d/c.txt` on a tracked `d/c.txt` stages the change, reports `d`, and exits 1.
- A tracked file that matches an ignore pattern is not reported. `add .` and `add -A` never report ignored paths.
- A deleted tracked path named by a pathspec stages the deletion. Glob pathspecs such as `'*.txt'` match
  across directories. `'tmp/*'` inside an ignored directory matches nothing (128).
- `../x` outside the working tree: `fatal: ../x: '../x' is outside repository at '<worktree>'`, 128.
- `.git/index` is written only if entries changed: `add -A` with nothing to add does not create it.

## status --porcelain

- Paths are relative to the top of the working tree, even from a subdirectory. Paths with spaces are quoted
  (`"sp ace.txt"`), non-ASCII bytes are octal escaped.
- An untracked directory without tracked files is shown once as `dir/`, and only if it contains a file that is
  not ignored. Inside a directory with tracked files, untracked files are listed one by one.
- Tracked changes come first, sorted by path, then the `??` entries sorted bytewise (with the trailing `/`).
- `status` does not create `.git/index`.
- The real git detects renames among staged changes (`R  old -> new`). This is out of scope for v1 (see
  `docs/progress.md`).

## ls-files

- From a subdirectory, only the entries under it, relative to it. Non-ASCII is quoted, spaces are not.
- `-s`: `<mode> <oid> 0\t<path>`.

## commit

- Nothing to commit: the status goes to stdout and the exit code is 1. This check comes before the empty
  message check. An empty message after cleanup: `Aborting commit due to empty commit message.`, exit 1.
- The tree objects are written before these checks (a failed commit on a fresh repository writes the empty tree).
- Without `-a`, the index is written even when the commit fails, so `commit -m x` on a fresh repository creates an
  empty `.git/index`. A failed `commit -a` does not write the index.
- Each `-m` is a paragraph: the values are joined with a blank line. The message is then cleaned up in
  "whitespace" mode: trailing whitespace is stripped, runs of blank lines collapse, and leading and trailing
  blank lines go. Lines starting with `#` are kept.

## log

- Default format: `commit <oid>`, `Author: <name> <email>`, `Date:   <date>`, a blank line, then the message
  indented by 4 spaces (blank lines inside become 4 spaces). Commits are separated by a blank line.
- The date is in the author's timezone: `Tue Nov 14 22:13:20 2023 +0000` (the day is not zero-padded).
- `--oneline`: `<abbrev> <subject>`, where the subject is the first paragraph with its lines joined by spaces.
- `-n <n>`, `-n<n>`, `-<n>`, `--max-count=<n>`; `-n 0` prints nothing.
- `-n` without a value: `error: -n requires an argument`, 128. `-n x`: `fatal: 'x': not an integer`, 128.
  An unknown option: `fatal: unrecognized argument: --bogus`, 128.
- A bad revision: `fatal: ambiguous argument ...`, 128. An unborn branch:
  `fatal: your current branch 'main' does not have any commits yet`, 128.

## branch

- Listing: `* main` for the current branch and `  topic` for the others, sorted by ref name; non-ASCII names
  are not quoted. On an unborn branch, the unborn branch is not listed.
- A detached HEAD is listed first as `* (HEAD detached at <x>)` or `* (HEAD detached from <x>)`, from the last
  `checkout: moving from A to B` entry of the HEAD reflog: `<x>` is B's name if B is a tag or a remote-tracking
  branch, otherwise the abbreviated ID that HEAD was moved to; "at" if HEAD is still there. Without such an
  entry: `* (no branch)`.
- Errors (exit 128): an existing branch (`fatal: a branch named 'x' already exists`), a bad start point
  (`fatal: not a valid object name: 'HEAD~5'`), an invalid name such as `a..b`, `-dash`, or `HEAD`
  (`fatal: 'x' is not a valid branch name`), a name conflicting with an existing ref
  (`fatal: cannot lock ref 'refs/heads/feature': 'refs/heads/feature/x' exists; ...`). On an unborn branch
  `foo`, `branch x` fails with `fatal: not a valid object name: 'foo'`. Three arguments: 129.
- `-d`: `Deleted branch topic (was f7615f8).` on stdout. The current branch
  (`error: cannot delete branch 'main' used by worktree at '<worktree>'`), a missing branch
  (`error: branch 'nope' not found`), or a branch not merged into HEAD (`error: the branch 'x' is not fully
  merged`) fail with exit 1, after the other names are processed. On an unborn HEAD nothing counts as merged.
  `-d` without a name: `fatal: branch name required`, 128.

## switch

- On stderr: `Switched to branch 'x'`, `Switched to a new branch 'x'`, `Already on 'x'`.
- On stdout: the local changes carried over, compared with the new HEAD, as `M\tpath`, `A\tpath`, `D\tpath`.
- Errors (128): a missing branch (`fatal: invalid reference: y`), a revision that is not a branch
  (`fatal: a branch is expected, got ...`), no argument (`fatal: missing branch or commit argument`), `-c` with
  an existing or invalid name, `-c b nope`.
- Conflicting local changes: `error: Your local changes to the following files would be overwritten by checkout:`,
  exit 1, nothing changed. An untracked file where the new branch has a file:
  `error: The following untracked working tree files would be overwritten by checkout:`, exit 1, even if the
  content is the same. Ignored files are overwritten silently.
- The index and working tree follow git's two-way merge (`twoway_merge`); with I = index, O = old HEAD, N = new:
  - I present: kept if (!O && !N), (!O && N && I=N), (O && N && O=N), or (O && N && I=N). Removed if O && !N
    && I=O, and updated to N if O && N && I=O, both only if the working tree file matches I (or is missing).
    Anything else is a local change that blocks the switch.
  - I absent: O && N && O=N: nothing; O && N && O!=N: blocked. N only: written, unless an untracked, not
    ignored file is in the way. O only: blocked if an untracked, not ignored file exists there
    ("would be removed"), otherwise nothing (a staged deletion of a now-ignored file keeps the file).
  - Directories left empty by removed files are removed.
- `switch -c x` on an unborn branch only moves HEAD and does not create `.git/index`.
