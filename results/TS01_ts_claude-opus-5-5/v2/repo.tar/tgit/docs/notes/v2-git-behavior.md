# Real git behavior confirmed for v2

Observed with the real git 2.47 under the difftest environment (`LANG=C`, `TZ=UTC`, `init.defaultBranch=main`,
default settings otherwise). Each item was tried with the real git before it was implemented.

## The diff algorithm

The real git's defaults for `diff`, `show`, and the combined diff of merges: the Myers algorithm of its bundled
xdiff library (`diff.algorithm` is unset), with the **indent heuristic** (`diff.indentHeuristic` defaults to true),
3 lines of context, and no inter-hunk context. tgit ports the parts of xdiff that these defaults use:

- **Records.** Lines are compared as raw bytes including the newline, so `a` at the end of a file without a
  newline differs from `a\n`. Every distinct line gets a class number; the algorithms compare class numbers.
- **Preparation (Myers only).** The common prefix and suffix are cut off (`xdl_trim_ends`). Then lines that do
  not occur in the other file at all are dropped from the comparison and marked changed; lines that occur in
  the other file many times (at least `bogosqrt(n)` times, capped at 1024) are dropped too when they sit in a run
  of such lines (`xdl_cleanup_records`, `xdl_clean_mmatch`).
- **Myers.** The divide-and-conquer middle snake search (`xdl_recs_cmp`, `xdl_split`), with xdiff's cost limits:
  after an edit cost of 256 it accepts a long enough "snake" (20 lines) as a split point, and past
  `max(bogosqrt(diagonals), 256)` it gives up on the optimal path and takes the furthest-reaching one.
- **Compaction** (`xdl_change_compact`). Each group of changed lines is slid up and down as far as equal lines
  allow, merging with groups it touches. If it can line up with a change in the other file it is placed there;
  otherwise the indent heuristic scores every position (blank lines and indentation around both ends of the
  group) and picks the best, preferring the lowest position on ties.
- **Hunks.** Changes separated by at most 6 unchanged lines (twice the context) share a hunk. Context lines are
  taken from the new file. The header is `@@ -<start>,<count> +<start>,<count> @@`; a count of 1 is omitted,
  and an empty side shows the line before it (`@@ -0,0 +1 @@`).
- **Function names** after `@@`: the nearest line above the hunk's first line (in the old file) that starts with
  a letter, `_`, or `$`, cut to 80 bytes, with trailing whitespace removed. The search stops where the previous
  hunk's search started; if nothing is found there, the previous hunk's function name is shown again.
- **Common tail trimming.** When there is no context (the combined diff), the common tail of the two files is cut
  off in blocks of 1024 bytes before diffing, keeping whole lines.

Merges (`merge-ort`) always use the **histogram** algorithm (it is hard-coded) and no indent heuristic, followed
by the same compaction. Histogram diff does not use the preparation step above: it finds the line with the
fewest occurrences (at most 64) in the region, extends it to the longest common run around it, and recurses on
both sides; if every line occurs more than 64 times, it falls back to Myers for that region.

## Diff output (`diff`, `show`)

- Header: `diff --git a/<path> b/<path>`. For a path that needs quoting (non-ASCII, control characters, `"`,
  `\`), each side is quoted as a whole: `diff --git "a/\346\227\245.txt" "b/\346\227\245.txt"`; spaces are not
  quoted. In `--- a/<path>` and `+++ b/<path>` lines, a path containing a space gets a trailing TAB.
- New file: `new file mode 100644`, `index 0000000..<new>`, `--- /dev/null`. Deleted file:
  `deleted file mode 100644`, `index <old>..0000000`, `+++ /dev/null`.
- Mode change only: `old mode 100644` / `new mode 100755` and no `index` line, no patch. Mode and content:
  `old mode`, `new mode`, then `index <old>..<new>` without a mode. Same mode: `index <old>..<new> 100644`.
- A change of file type (regular file <-> symlink) is shown as a deletion followed by a creation.
- Abbreviated IDs on `index` lines use the usual rule (at least 7, unique among objects).
- Binary (a NUL byte within the first 8000 bytes of either side): `Binary files a/x and b/x differ`, with
  `/dev/null` for a missing side, and no `---`/`+++` lines.
- An empty new file: `new file mode` and `index` lines only. Deleting an empty file: likewise.
  From empty to content: `@@ -0,0 +1 @@`.
- `\ No newline at end of file` follows a line that has no newline at the end of a file.
- `diff` exits with 0 whether or not there are differences.
- Paths are always relative to the top of the working tree, also when run from a subdirectory, and the whole
  tree is compared.
- `--name-only`: one path per line, quoted like `ls-files` (non-ASCII quoted, spaces not).

### Which files are compared

- `diff`: index vs. working tree, for the paths in the index. A file missing from the working tree shows as
  deleted. Untracked files are not shown.
- `diff --cached`: HEAD vs. index; with no commits yet, everything in the index is new (an empty index prints
  nothing).
- `diff A B`: the trees of two commits.
- Errors: a revision that does not resolve (`diff nope`, `diff HEAD~9 HEAD`, `diff --cached nope`):
  `fatal: ambiguous argument ...`, exit 128. `diff HEAD HEAD` with no commits: 128. An unknown option: 129.
  Outside a repository, `diff` exits with 129 (it falls back to `--no-index` usage); `show`: 128.

### Unmerged paths

- `diff` (patch): a path with both stage 2 and stage 3 is shown as a combined diff of the working tree file
  against stages 2 and 3 (see below), printed right away while the index is walked, so before all other
  output. The other output keeps index order: for any other unmerged path (for example only stages 1 and 3),
  `* Unmerged path <path>` (the path not quoted), followed by the patch of its stage 2 against the working
  tree if they differ; changed paths in between print their patches as usual.
- `diff --name-only`: each unmerged path is printed once, and once more if the working tree file differs from
  stage 2 (so `b.txt` may appear twice), also for paths with stages 2 and 3.
- `diff --cached`: `* Unmerged path <path>` for each unmerged path, sorted by path among the other changes
  (HEAD's version of an unmerged path is not compared); `--name-only` prints each once.
- The combined diff of the working tree has `index <stage 2>,<stage 3>..0000000`.

## show

- `show` with no argument is `show HEAD`. Several revisions are shown in the order given, separated by a blank
  line. An unknown revision: `fatal: ambiguous argument ...`, 128. No commits yet: `fatal: your current branch
  'main' does not have any commits yet`, 128. An unknown option: 128 (`unrecognized argument`).
- Format: like `log` (`commit`, `Merge: <p1> <p2>` for merges with abbreviated parents, `Author`, `Date`, blank,
  message indented by 4), then a blank line and the patch against the first parent. A root commit shows every file
  as new.
- In messages, TABs are expanded to 8-column tab stops (counted from the start of the message line, before
  the 4-space indent). This applies to `log` too, which also prints the `Merge:` line.
- A merge commit is shown with a **dense combined diff** (`--cc`): only paths that differ from every parent
  are considered, and only hunks where the result differs from all parents in different ways are shown.
  The message is always followed by a blank line, even when no combined diff is printed.

### Combined diff format

```
diff --cc <path>
index <p1>,<p2>..<result>
--- a/<path>
+++ b/<path>
@@@ -1,1 -1,1 +1,1 @@@ <function name>
- main
 -topic
++resolved
```

- Paths are quoted as a whole (`diff --cc "\346\227\245.txt"`), without a TAB after names containing spaces.
- Counts are always printed, even when 1; a parent with no lines shows `-1,0`.
- A file added in the merge that no parent has: `index 0000000,0000000..<result>` and `new file mode 100644`,
  `--- /dev/null`. Mode differences: `mode <p1>,<p2>..<result>`. Deleted: `deleted file mode <p1>,<p2>`.
- The function name is taken from the lines above the hunk in the result, cut to 40 bytes, and (as in the real
  git) the last non-space character is dropped: `int main() {` shows as `int main() `.
- Binary: `Binary files differ` after the `index` line.
- Built per parent with a zero-context diff of parent -> result; lines removed from several parents are
  coalesced with an LCS, and context is 3 lines.

## merge-base

- Prints the full ID of the best common ancestor. With no common ancestor: no output, exit 1.
- Fewer than two arguments: usage, exit 129. An unknown revision: `fatal: Not a valid object name X`, 128.
  An unknown option: 129. Outside a repository: 128.
- With more than two arguments the real git computes the merge base of the first against all others; the
  specification only asks for two.

## merge

- Messages (`fmt-merge-msg`): `Merge branch '<name>'` for a branch given by name, `Merge branch '<name>' (early
  part)` for `<branch>~<n>` or `<branch>^`, `Merge commit '<arg>'` for anything else. ` into <branch>` is
  appended unless the current branch is `main` or `master`; with a detached HEAD, ` into HEAD`.
- `-m <msg>`: the message instead (several `-m` are joined as paragraphs). A fast-forward ignores it.
  Unlike `commit`, merge joins the `-m` values with `\n\n` as they are and adds one `\n`: `-m $'a\n' -m $'b\n\n'`
  gives `MERGE_MSG` `a\n\n\nb\n\n\n\n# Conflicts:\n#\ta.txt\n`. The commit of a clean merge cleans this up.
- Naming (`merge_name`): the argument is looked up as a ref first; if it is a branch (`topic`, `heads/topic`,
  `refs/heads/topic`), the message names it as given. Otherwise a trailing run of `^`, or a trailing `~<digits>`
  or `~`, is cut off, and if what remains is a branch: `Merge branch 'topic' (early part)`, except for `~0`
  (`~00`, ...), which gives `Merge branch 'topic'`. `topic~1^` and abbreviated IDs give `Merge commit '<arg>'`.
- Into a branch with no commits yet: a two-way checkout from the empty tree to the other commit (staged files
  that the commit does not have are kept), then the branch points at it; `-m` is ignored. If an untracked or
  staged file is in the way: `fatal: read-tree failed`, 128, nothing changed.
- Nothing to merge (the other commit is an ancestor of HEAD, or HEAD itself): `Already up to date.`, exit 0.
- Fast-forward: `Updating <a>..<b>`, `Fast-forward`, diffstat; uses the two-way checkout rules (local changes
  are kept unless they would be overwritten). If the checkout fails: exit 1, nothing changed.
- Not something we can merge (unknown name): `merge: X - not something we can merge`, exit 1. No argument:
  `fatal: No remote for the current branch.`, 128. An unknown option: 129. Outside a repository: 128.
- `MERGE_HEAD` exists: `fatal: You have not concluded your merge (MERGE_HEAD exists).`, 128. Unmerged entries in
  the index: `error: Merging is not possible because you have unmerged files.`, 128.
- A real merge first **saves the local changes like `git stash create`** when the index or the working tree
  differs from HEAD (untracked files do not count). This writes objects even if the merge then fails:
  - the index tree, and a commit of it with parent HEAD and message `index on <branch>: <abbrev> <subject>\n`;
  - the blobs of changed working tree files, a tree of the index with every tracked path replaced by its
    working tree version (or removed if the file is missing), and a commit of it with parents HEAD and the
    index commit and message `WIP on <branch>: <abbrev> <subject>` (no trailing newline).
  `<branch>` is `(no branch)` for a detached HEAD. On failure the saved state is restored, which leaves the
  index and working tree as they were.
- Then the index must match HEAD: otherwise `error: Your local changes to the following files would be
  overwritten by merge:` and `Merge with strategy ort failed.`, exit 2, before anything else is written.
- `merge-ort` computes the result tree and writes its new blobs and trees (also those with conflict markers).
  Then it checks out the result with the two-way rules; local changes or untracked files in the way:
  exit 2 (`Merge with strategy ort failed.`), with the merge's objects left behind.
- Clean: `Merge made by the 'ort' strategy.` and a merge commit with parents HEAD and the other commit, and the
  message cleaned up like `commit -m` (whitespace mode). `MERGE_MSG` is not left behind.
- Per path (three-way, without rename detection): if both sides agree, or only one side changed, that side
  wins. Otherwise a content merge (see below). Deleted on one side and unchanged on the other: deleted.
  Deleted on one side and modified on the other: `CONFLICT (modify/delete)`, stages 1 and 2 or 1 and 3, and the
  modified version is left in the working tree. Added on both sides with different contents: content merge
  with an empty base, `CONFLICT (add/add)`, stages 2 and 3.
- Content merge: `xdl_merge` with level "zealous", the "merge" conflict style, and 7-character markers:
  `<<<<<<< HEAD`, `=======`, `>>>>>>> <name as given on the command line>`. Overlapping or adjacent changes
  conflict unless they are identical. Conflicts are refined by diffing the two sides (common lines move out of
  the markers); conflicts separated by at most 3 lines are joined. A side whose conflicting part lacks a final
  newline gets one inside the markers. Binary files (a NUL in the first 8000 bytes of any version) are not
  merged: `warning: Cannot merge binary files`, the result is our version, and it is a conflict.
- Conflict: `Automatic merge failed; fix conflicts and then commit the result.`, exit 1. Written: `MERGE_HEAD`
  (`<oid>\n`), `MERGE_MODE` (empty), `ORIG_HEAD`, and `MERGE_MSG`:

  ```
  Merge branch 'topic'

  # Conflicts:
  #	a.txt
  ```

  with one `#\t<path>` line per unmerged path (not quoted), in index order. The index has stages 1-3 for
  conflicted paths; `status --porcelain` shows `UU` (both modified), `AA` (both added), `DU` (deleted by us),
  `UD` (deleted by them).
- While `MERGE_HEAD` exists, `switch` fails: `fatal: cannot switch branch while merging`, 128. The check comes after the
  target is resolved, so an unknown branch or an existing `-c` name fails with its own message first.
- `ls-files` prints an unmerged path once per stage; `ls-files -s` shows the stage numbers.
- `add <path>` (and `add -A`) replaces the stages with the working tree file, or removes the path if the file is
  missing.

## commit during a merge

- With unmerged entries: `error: Committing is not possible because you have unmerged files.`, 128.
  `commit -a` stages everything first, so it succeeds.
- The commit has parents HEAD and `MERGE_HEAD`, and is made even if its tree equals HEAD's tree.
- `commit --no-edit` takes the message from `MERGE_MSG`, cleaned in whitespace mode (the `# Conflicts:` lines
  stay). `commit -m <msg>` uses `<msg>` only. Afterwards `MERGE_HEAD`, `MERGE_MSG`, and `MERGE_MODE` are removed.
- `commit --no-edit` outside a merge: `Aborting commit due to empty commit message.`, exit 1.
