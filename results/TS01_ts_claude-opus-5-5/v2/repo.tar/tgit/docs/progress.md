# Progress

## v0.1.0

Implemented `docs/spec-v1.md`:

- Command dispatch and repository discovery (searching upward from the current directory for `.git`).
- `init` (directory argument, `-b`/`--initial-branch`, `-q`, reinitialization).
- Loose blob, tree, and commit objects; `hash-object` (`-w`) and `cat-file` (`-t`, `-s`, `-p`).
- The index (version 2; versions 2 and 3 are read), the root `.gitignore` and `.git/info/exclude`.
- `add` (paths, directories, globs, `.`, `-A`), `ls-files` (`-s`), `status --porcelain`.
- `commit` (`-m`, repeatable, and `-a`), with identities and dates from `GIT_AUTHOR_*`/`GIT_COMMITTER_*`
  (falling back to `user.name`/`user.email`).
- `rev-parse` (ref names, full and abbreviated IDs, `~<n>`, `^<n>`), `log` (default, `--oneline`, `-n`),
  `branch` (list, create, `-d`), `switch` (`<branch>`, `-c`), using git's two-way merge rules.
- Tests: unit tests (`npm test`), differential scenarios for every command under `test/difftest/scenarios/`,
  and random sequences (`npm run difftest` runs the scenarios plus 100 random sequences for each of 3 seeds;
  `node test/difftest/difftest.ts --seeds 1,2,3 --count 500` runs the full set).
- The real git behavior that was confirmed before implementing is in `docs/notes/v1-git-behavior.md`.

Known differences from the real git:

- `status --porcelain` does not detect renames (a non-goal of the specification): where the real git shows
  `R  old -> new` for a staged deletion and a similar staged addition, tgit shows `D  old` and `A  new`.
  The random sequences hit this now and then: with `--count 500`, seeds 1, 2, and 4 pass, and seed 3 fails one
  sequence (`v1-random-0285`) for this reason only. See `docs/notes/v1-rename-detection.md`.
- No reflogs are written. `branch` reads the HEAD reflog written by the real git to describe a detached HEAD.
- Refs are read only as loose files; `packed-refs` is not read (packfiles and `gc` are non-goals).
- Only the `.gitignore` at the top of the working tree is read, as the specification asks; `.gitignore` files in
  subdirectories and `core.excludesFile` are ignored.
- Changes in the working tree are always detected by hashing file contents; the index's stat data is
  written but not used to skip unchanged files.
- `commit` prints only the summary line (`[main (root-commit) abc1234] subject`), not the diffstat.
  Without `-m` it does not start an editor and fails with an empty message.
- Error messages on standard error do not always use the real git's wording.

## v0.2.0

Implemented `docs/spec-v2.md`:

- Unified diffs that match the real git's defaults: a port of xdiff's Myers algorithm with its preparation
  step and cost limits, the histogram algorithm (used by merges), compaction with the indent heuristic, hunks
  with function names, binary files, and missing final newlines.
- `diff` (working tree vs. index, `--cached`, two commits, `--name-only`), including unmerged paths.
- `show [<commit>]`: the commit as `log` shows it and its patch; merge commits get the dense combined diff
  (`diff --cc`).
- `merge-base <commit> <commit>`: the real git's `paint_down_to_common` and `remove_redundant`, so that the same
  base is chosen when there are several.
- `merge <commit>` and `merge -m <message> <commit>`: "Already up to date", fast-forward, a merge into a branch
  with no commits yet, and a three-way merge ported from `merge-ort` (path by path, with merged merge bases for
  criss-cross histories) and `xdl_merge` (the content merge with conflict markers). Conflicts leave index stages
  1 to 3, `MERGE_HEAD`, `MERGE_MSG`, and `MERGE_MODE`, and exit 1. Like the real git, local changes are first
  saved as `git stash create` would, and a merge that would overwrite them fails without changing anything.
- `commit` concludes a merge (`--no-edit` takes `MERGE_MSG`, `-m` replaces it); it refuses to commit unmerged
  paths, and `switch` refuses to run during a merge. The index keeps conflict stages.
- Tests: differential scenarios for every new command, unit tests for the content merge and conflict stages,
  and fuzz scripts that compare the diff, merge-base, combined diff, and tree merge against the real git on
  random inputs (`test/fuzz/`, run by hand). `npm run difftest` now runs random v1 and v2 sequences.
  With `--count 500`, the random v2 sequences pass for seeds 1, 2, and 3.
- The real git behavior confirmed before implementing is in `docs/notes/v2-git-behavior.md`.

Known differences from the real git:

- No rename detection (a non-goal of the specification). A merge does not follow renamed files: where the real
  git would merge a renamed file's changes into its new name, tgit merges by path, which can give a different
  result or conflict. The combined diff of `show` does not detect renames either; the real git does, and then
  compares a renamed file with its old name in a parent (the combined diff fuzz finds this now and then).
- `merge` does not print the diffstat after a fast-forward or a merge commit.
- Conflicts that the real git resolves by moving files aside are not handled the same way: for a file
  that is a regular file on one side and a symlink on the other, tgit keeps our version and reports a conflict,
  and paths that are a file on one side and a directory on the other are not supported.
- Only one commit can be merged (no octopus merges), only with the default strategy, and without
  `--abort`, `--continue`, or other options. `commit` during a conflicted merge does not start an editor: it
  needs `-m` or `--no-edit`.
