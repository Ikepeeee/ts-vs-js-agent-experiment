import path from "node:path";
import type { CommandContext } from "../cli/context.ts";
import { ExitError, fatal, usageError } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { quotePath } from "../cli/quote.ts";
import { formatCombinedDiff, type CombinedParent } from "../core/diff/combined.ts";
import { blobSide, filePairs, readBlob } from "../core/diff/file-pairs.ts";
import { formatPatch, type DiffBlob, type FilePair } from "../core/diff/patch.ts";
import { readIndex, type Index, type IndexEntry } from "../core/index/index-file.ts";
import { comparePaths } from "../core/paths.ts";
import { resolveHead } from "../core/refs/refs.ts";
import { discoverRepository, type Repository } from "../core/repo/repository.ts";
import { Abbreviator } from "../core/revision/abbrev.ts";
import { resolveCommit } from "../core/revision/resolve.ts";
import { commitFiles, indexFiles, treeMode } from "../core/status/changes.ts";
import { hashWorktreeFile, readContent } from "../core/worktree/files.ts";

/** What `diff` prints for each path, in order: a file pair, or a note that a path is unmerged. */
type DiffItem = { kind: "pair"; pair: FilePair } | { kind: "unmerged"; path: string };

/** The working tree file at a path as a diff side, or null if it is missing (or not a file). */
function worktreeSide(repo: Repository, filePath: string, previousMode: number | undefined): DiffBlob | null {
  const absPath = path.join(repo.workTree, filePath);
  const filemode = repo.config.getBool("core.filemode", true);
  const file = hashWorktreeFile(repo.gitDir, absPath, { filemode, previousMode, write: false });
  if (!file) return null;
  return { mode: treeMode(file.mode), oid: file.oid, data: readContent(absPath, file.mode) };
}

/** Compares an index entry with the working tree; null if they match. */
function compareWithWorktree(repo: Repository, entry: IndexEntry): FilePair | null {
  const next = worktreeSide(repo, entry.path, entry.mode);
  if (next && next.mode === treeMode(entry.mode) && next.oid === entry.oid) return null;
  return { path: entry.path, old: blobSide(repo.gitDir, { mode: treeMode(entry.mode), oid: entry.oid }), new: next };
}

/**
 * The combined diff of a working tree file against stages 2 and 3 of an unmerged path, which the
 * real git shows right away while it walks the index.
 */
function unmergedCombinedDiff(repo: Repository, filePath: string, stages: IndexEntry[], abbreviator: Abbreviator): Buffer {
  const parents: CombinedParent[] = [2, 3].map((stage) => {
    const entry = stages.find((e) => e.stage === stage) as IndexEntry;
    return { mode: entry.mode, oid: entry.oid, data: readBlob(repo.gitDir, entry.oid), added: false };
  });
  const result = worktreeSide(repo, filePath, undefined);
  const mode = result ? Number.parseInt(result.mode, 8) : 0;
  return formatCombinedDiff(
    { path: filePath, mode, oid: null, data: result?.data ?? Buffer.alloc(0), parents },
    (oid) => abbreviator.abbreviate(oid),
    true,
  );
}

/**
 * `diff` without revisions: the index against the working tree. An unmerged path is noted, and its
 * "ours" stage is compared with the working tree; with patch output, a path with both "ours" and
 * "theirs" stages is shown as a combined diff instead.
 */
function worktreeItems(repo: Repository, index: Index, combined: ((filePath: string, stages: IndexEntry[]) => void) | null): DiffItem[] {
  const items: DiffItem[] = [];
  for (const filePath of index.paths()) {
    const stages = index.stages(filePath);
    const entry = index.get(filePath) ?? stages.find((e) => e.stage === 2);
    if (stages.length > 0) {
      if (stages.some((e) => e.stage === 2) && stages.some((e) => e.stage === 3) && combined) {
        combined(filePath, stages);
        continue;
      }
      items.push({ kind: "unmerged", path: filePath });
    }
    const pair = entry && compareWithWorktree(repo, entry);
    if (pair) items.push({ kind: "pair", pair });
  }
  return items;
}

/** `diff --cached`: HEAD (or nothing, before the first commit) against the index. */
function cachedItems(repo: Repository, index: Index): DiffItem[] {
  const unmerged = index.unmergedPaths();
  const head = commitFiles(repo.gitDir, resolveHead(repo.gitDir));
  for (const filePath of unmerged) head.delete(filePath);
  const items: DiffItem[] = filePairs(repo.gitDir, head, indexFiles(index)).map((pair) => ({ kind: "pair", pair }));
  items.push(...unmerged.map((filePath): DiffItem => ({ kind: "unmerged", path: filePath })));
  const itemPath = (item: DiffItem): string => (item.kind === "pair" ? item.pair.path : item.path);
  return items.sort((a, b) => comparePaths(itemPath(a), itemPath(b)));
}

function resolveDiffCommit(gitDir: string, revision: string): string {
  const oid = resolveCommit(gitDir, revision);
  if (oid === null) throw fatal(`ambiguous argument '${revision}': unknown revision or path not in the working tree.`);
  return oid;
}

export function diff(ctx: CommandContext): number {
  const repo = discoverRepository(ctx.cwd, ctx.env);
  if (!repo) {
    // The real git falls back to comparing two paths outside a repository, and shows that usage.
    throw new ExitError("warning: Not a git repository. Use --no-index to compare two paths outside a working tree", 129);
  }
  const parsed = parseOptions(ctx.args, [
    { name: "cached", long: "cached" },
    { name: "cached", long: "staged" },
    { name: "name-only", long: "name-only" },
  ]);
  const commits = parsed.positionals.map((revision) => resolveDiffCommit(repo.gitDir, revision));
  const nameOnly = hasOption(parsed, "name-only");
  const abbreviator = new Abbreviator(repo.gitDir);
  const abbreviate = (oid: string): string => abbreviator.abbreviate(oid);
  const out: Buffer[] = [];

  let items: DiffItem[];
  const [from, to] = commits;
  if (commits.length === 2 && from !== undefined && to !== undefined) {
    items = filePairs(repo.gitDir, commitFiles(repo.gitDir, from), commitFiles(repo.gitDir, to)).map((pair) => ({ kind: "pair", pair }));
  } else if (commits.length > 0) {
    throw usageError("only 'diff', 'diff --cached', and 'diff <commit> <commit>' are supported");
  } else if (hasOption(parsed, "cached")) {
    items = cachedItems(repo, readIndex(repo.gitDir));
  } else {
    const combined = (filePath: string, stages: IndexEntry[]): void => {
      out.push(unmergedCombinedDiff(repo, filePath, stages, abbreviator));
    };
    items = worktreeItems(repo, readIndex(repo.gitDir), nameOnly ? null : combined);
  }

  for (const item of items) {
    if (nameOnly) out.push(Buffer.from(`${quotePath(item.kind === "pair" ? item.pair.path : item.path)}\n`));
    else if (item.kind === "unmerged") out.push(Buffer.from(`* Unmerged path ${item.path}\n`));
    else out.push(formatPatch(item.pair, abbreviate));
  }
  ctx.stdout(Buffer.concat(out));
  return 0;
}
