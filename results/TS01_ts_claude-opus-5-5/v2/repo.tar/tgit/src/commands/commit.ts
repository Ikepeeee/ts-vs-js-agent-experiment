import fs from "node:fs";
import path from "node:path";
import type { CommandContext } from "../cli/context.ts";
import { usageError } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { indexPath, readIndex, writeIndex, type Index } from "../core/index/index-file.ts";
import { cleanupMessage, joinMessages, readCommit } from "../core/objects/commit.ts";
import { writeTreeFromFiles } from "../core/objects/tree.ts";
import { writeCommit } from "../core/objects/write-commit.ts";
import { clearMergeState, readMergeHead, readMergeMessage } from "../core/merge/state.ts";
import { HEADS_PREFIX, readHead, resolveHead, updateHead } from "../core/refs/refs.ts";
import type { Repository } from "../core/repo/repository.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { Abbreviator } from "../core/revision/abbrev.ts";
import { indexFiles } from "../core/status/changes.ts";
import { hashWorktreeFile, toIndexEntry } from "../core/worktree/files.ts";

/** Updates the index with the working tree's version of every tracked file, conflicted or not (`commit -a`). */
function stageTrackedFiles(repo: Repository, index: Index): void {
  const filemode = repo.config.getBool("core.filemode", true);
  for (const filePath of index.paths()) {
    const previousMode = (index.get(filePath) ?? index.stages(filePath).at(-1))?.mode;
    const file = hashWorktreeFile(repo.gitDir, path.join(repo.workTree, filePath), { filemode, previousMode, write: true });
    if (file) index.set(toIndexEntry(filePath, file));
    else index.delete(filePath);
  }
}

export function commit(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [
    { name: "message", short: "m", long: "message", takesValue: true },
    { name: "all", short: "a", long: "all" },
    { name: "no-edit", long: "no-edit" },
  ]);
  if (parsed.positionals.length > 0) throw usageError("committing only some paths is not supported");
  const repo = requireRepository(ctx.cwd, ctx.env);
  const index = readIndex(repo.gitDir);
  const all = hasOption(parsed, "all");
  if (all) stageTrackedFiles(repo, index);
  if (index.unmergedPaths().length > 0) {
    ctx.stderr("error: Committing is not possible because you have unmerged files.\n");
    ctx.stderr("hint: Fix them up in the work tree, and then use 'git add/rm <file>'\n");
    ctx.stderr("hint: as appropriate to mark resolution and make a commit.\n");
    ctx.stderr("fatal: Exiting because of an unresolved conflict.\n");
    return 128;
  }

  const tree = writeTreeFromFiles(repo.gitDir, indexFiles(index));
  // Without -a the real git refreshes and writes the index even when the commit fails.
  if (!all && (index.changed || !fs.existsSync(indexPath(repo.gitDir)))) writeIndex(repo.gitDir, index);

  const parent = resolveHead(repo.gitDir);
  // Concluding a merge makes a commit even if it changes nothing.
  const mergeHead = parent === null ? null : readMergeHead(repo.gitDir);
  const parentTree = parent === null ? null : readCommit(repo.gitDir, parent)?.tree;
  if (mergeHead === null && (tree === parentTree || (parent === null && index.size === 0))) {
    ctx.stdout("nothing to commit, working tree clean\n");
    return 1;
  }
  const messages = parsed.options.get("message");
  const mergeMessage = mergeHead !== null && hasOption(parsed, "no-edit") ? readMergeMessage(repo.gitDir) : null;
  const message = cleanupMessage(messages ? joinMessages(messages) : (mergeMessage ?? ""));
  if (message === "") {
    ctx.stderr("Aborting commit due to empty commit message.\n");
    return 1;
  }

  const parents = parent === null ? [] : mergeHead === null ? [parent] : [parent, mergeHead];
  const oid = writeCommit(repo, ctx.env, tree, parents, message);
  updateHead(repo.gitDir, oid);
  if (all) writeIndex(repo.gitDir, index);
  clearMergeState(repo.gitDir);

  const head = readHead(repo.gitDir);
  const where = head.kind === "branch" ? head.ref.replace(HEADS_PREFIX, "") : "detached HEAD";
  const root = parent === null ? " (root-commit)" : "";
  ctx.stdout(`[${where}${root} ${new Abbreviator(repo.gitDir).abbreviate(oid)}] ${message.split("\n")[0]}\n`);
  return 0;
}
