import fs from "node:fs";
import path from "node:path";
import type { CommandContext } from "../cli/context.ts";
import { fatal } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { hashObject as hashBlob, writeObject } from "../core/objects/store.ts";
import { requireRepository } from "../core/repo/repository.ts";

export function hashObject(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "write", short: "w" }]);
  const write = hasOption(parsed, "write");
  // Hashing works outside a repository; writing needs one.
  const gitDir = write ? requireRepository(ctx.cwd, ctx.env).gitDir : null;

  for (const file of parsed.positionals) {
    let content: Buffer;
    try {
      content = fs.readFileSync(path.resolve(ctx.cwd, file));
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "EISDIR") throw fatal(`Unable to hash ${file}`);
      throw fatal(`could not open '${file}' for reading: No such file or directory`);
    }
    ctx.stdout(`${gitDir ? writeObject(gitDir, "blob", content) : hashBlob("blob", content)}\n`);
  }
  return 0;
}
