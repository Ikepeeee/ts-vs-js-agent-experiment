import fs from "node:fs";
import path from "node:path";
import type { CommandContext } from "../cli/context.ts";
import { fatal } from "../cli/errors.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { resolveRevision } from "../core/revision/resolve.ts";

/**
 * `git rev-parse <arg>...`: prints the object ID of each revision. Like the real git, the first
 * argument that is not a revision starts the file arguments: every argument from there on is
 * printed as is, and must name an existing path (unless it comes after "--").
 */
export function revParse(ctx: CommandContext): number {
  const repo = requireRepository(ctx.cwd, ctx.env);
  let inFiles = false;
  for (const [i, arg] of ctx.args.entries()) {
    if (arg === "--") {
      ctx.stdout(`${[arg, ...ctx.args.slice(i + 1)].join("\n")}\n`);
      return 0;
    }
    if (arg.startsWith("-")) {
      ctx.stdout(`${arg}\n`);
      continue;
    }
    const oid = inFiles ? null : resolveRevision(repo.gitDir, arg);
    if (oid !== null) {
      ctx.stdout(`${oid}\n`);
      continue;
    }
    ctx.stdout(`${arg}\n`);
    if (!fs.existsSync(path.resolve(ctx.cwd, arg)) && !isSymlink(path.resolve(ctx.cwd, arg))) {
      throw fatal(
        inFiles
          ? `${arg}: no such path in the working tree.`
          : `ambiguous argument '${arg}': unknown revision or path not in the working tree.`,
      );
    }
    inFiles = true;
  }
  return 0;
}

function isSymlink(absPath: string): boolean {
  try {
    return fs.lstatSync(absPath).isSymbolicLink();
  } catch {
    return false;
  }
}
