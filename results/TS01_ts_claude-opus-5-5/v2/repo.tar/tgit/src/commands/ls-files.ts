import type { CommandContext } from "../cli/context.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { quotePath } from "../cli/quote.ts";
import { readIndex } from "../core/index/index-file.ts";
import { requireRepository, worktreePrefix } from "../core/repo/repository.ts";
import { treeMode } from "../core/status/changes.ts";

export function lsFiles(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "stage", short: "s", long: "stage" }]);
  const repo = requireRepository(ctx.cwd, ctx.env);
  // From a subdirectory, only the entries under it are listed, relative to it.
  const prefix = worktreePrefix(repo, ctx.cwd);
  const lines: string[] = [];
  for (const entry of readIndex(repo.gitDir).allEntries()) {
    if (prefix !== "" && !entry.path.startsWith(`${prefix}/`)) continue;
    const name = quotePath(prefix === "" ? entry.path : entry.path.slice(prefix.length + 1));
    lines.push(hasOption(parsed, "stage") ? `${treeMode(entry.mode)} ${entry.oid} ${entry.stage ?? 0}\t${name}\n` : `${name}\n`);
  }
  ctx.stdout(lines.join(""));
  return 0;
}
