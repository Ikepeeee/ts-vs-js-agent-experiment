import type { CommandRun } from "../cli/context.ts";
import { add } from "./add.ts";
import { branch } from "./branch.ts";
import { catFile } from "./cat-file.ts";
import { commit } from "./commit.ts";
import { diff } from "./diff.ts";
import { hashObject } from "./hash-object.ts";
import { init } from "./init.ts";
import { log } from "./log.ts";
import { lsFiles } from "./ls-files.ts";
import { merge } from "./merge.ts";
import { mergeBase } from "./merge-base.ts";
import { revParse } from "./rev-parse.ts";
import { show } from "./show.ts";
import { status } from "./status.ts";
import { switchBranch } from "./switch.ts";

export const commands = new Map<string, CommandRun>([
  ["add", add],
  ["branch", branch],
  ["cat-file", catFile],
  ["commit", commit],
  ["diff", diff],
  ["hash-object", hashObject],
  ["init", init],
  ["log", log],
  ["ls-files", lsFiles],
  ["merge", merge],
  ["merge-base", mergeBase],
  ["rev-parse", revParse],
  ["show", show],
  ["status", status],
  ["switch", switchBranch],
]);
