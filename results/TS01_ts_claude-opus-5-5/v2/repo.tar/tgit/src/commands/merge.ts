import { reportCheckoutProblems } from "../cli/checkout-problems.ts";
import type { CommandContext } from "../cli/context.ts";
import { fatal } from "../cli/errors.ts";
import { parseOptions } from "../cli/options.ts";
import { switchTrees } from "../core/checkout/two-way.ts";
import { EMPTY_STAT, readIndex, writeIndex, type Index } from "../core/index/index-file.ts";
import { mergeCommits, type TreeMerge } from "../core/merge/ort.ts";
import { saveLocalChanges } from "../core/merge/save-state.ts";
import { readMergeHead, writeMergeState } from "../core/merge/state.ts";
import { cleanupMessage } from "../core/objects/commit.ts";
import { writeCommit } from "../core/objects/write-commit.ts";
import { HEADS_PREFIX, readHead, readRef, resolveHead, updateHead, writeRef } from "../core/refs/refs.ts";
import type { Repository } from "../core/repo/repository.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { Abbreviator } from "../core/revision/abbrev.ts";
import { mergeBases } from "../core/revision/merge-base.ts";
import { refCandidates, resolveCommit } from "../core/revision/resolve.ts";
import { commitFiles, diffFiles, indexFiles } from "../core/status/changes.ts";
import { IgnoreRules } from "../core/worktree/ignore.ts";

const MERGE_ACTION = { by: "merge", before: "merge" };

/** How the real git's `fmt-merge-msg` names what is merged: `branch 'topic'`, `branch 'topic' (early part)`, or `commit '<arg>'`. */
function describeMerged(gitDir: string, arg: string): string {
  const ref = refCandidates(arg).find((candidate) => readRef(gitDir, candidate) !== null);
  if (ref?.startsWith(HEADS_PREFIX)) return `branch '${arg}'`;

  // <branch>^..., <branch>~<n>, or <branch>~: the early part of a branch (except for <branch>~0).
  let suffix = /\^+$/.exec(arg)?.[0];
  let early = suffix !== undefined;
  if (!early) {
    suffix = /~\d*$/.exec(arg)?.[0];
    early = suffix !== undefined && (suffix === "~" || /[1-9]/.test(suffix));
  }
  if (suffix !== undefined) {
    const branch = arg.slice(0, -suffix.length);
    if (readRef(gitDir, HEADS_PREFIX + branch) !== null) return `branch '${branch}'${early ? " (early part)" : ""}`;
  }
  return `commit '${arg}'`;
}

function defaultMessage(gitDir: string, arg: string): string {
  const head = readHead(gitDir);
  const current = head.kind === "branch" ? head.ref.slice(HEADS_PREFIX.length) : "HEAD";
  const into = current === "main" || current === "master" ? "" : ` into ${current}`;
  return `Merge ${describeMerged(gitDir, arg)}${into}`;
}

/** Merging into a branch with no commits yet: check out the other commit and point the branch at it. */
function mergeIntoUnborn(repo: Repository, index: Index, theirs: string): number {
  if (switchTrees(repo, index, IgnoreRules.load(repo), new Map(), commitFiles(repo.gitDir, theirs))) throw fatal("read-tree failed");
  writeIndex(repo.gitDir, index);
  updateHead(repo.gitDir, theirs);
  return 0;
}

/** Records the merge's conflicts as index stages 1 to 3. */
function recordConflicts(index: Index, merge: TreeMerge): void {
  for (const conflict of merge.conflicts) {
    const stages = conflict.stages.flatMap((file, i) =>
      file ? [{ path: conflict.path, oid: file.oid, mode: parseInt(file.mode, 8), stat: EMPTY_STAT, stage: i + 1 }] : [],
    );
    index.setConflict(conflict.path, stages);
  }
}

export function merge(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "message", short: "m", long: "message", takesValue: true }]);
  const repo = requireRepository(ctx.cwd, ctx.env);
  const index = readIndex(repo.gitDir);
  if (index.unmergedPaths().length > 0) {
    ctx.stderr("error: Merging is not possible because you have unmerged files.\n");
    ctx.stderr("hint: Fix them up in the work tree, and then use 'git add/rm <file>'\n");
    ctx.stderr("hint: as appropriate to mark resolution and make a commit.\n");
    throw fatal("Exiting because of an unresolved conflict.");
  }
  if (readMergeHead(repo.gitDir) !== null) {
    throw fatal("You have not concluded your merge (MERGE_HEAD exists).\nPlease, commit your changes before you merge.");
  }
  const [arg, ...rest] = parsed.positionals;
  if (arg === undefined) throw fatal("No remote for the current branch.");
  if (rest.length > 0) throw fatal("merging more than one commit is not supported");
  const theirs = resolveCommit(repo.gitDir, arg);
  if (theirs === null) {
    ctx.stderr(`merge: ${arg} - not something we can merge\n`);
    return 1;
  }

  const head = resolveHead(repo.gitDir);
  if (head === null) return mergeIntoUnborn(repo, index, theirs);
  writeRef(repo.gitDir, "ORIG_HEAD", head);
  const bases = mergeBases(repo.gitDir, head, [theirs]);
  if (bases.length === 0) throw fatal("refusing to merge unrelated histories");
  if (bases.length === 1 && bases[0] === theirs) {
    ctx.stdout("Already up to date.\n");
    return 0;
  }

  const headFiles = commitFiles(repo.gitDir, head);
  const ignore = IgnoreRules.load(repo);
  if (bases.length === 1 && bases[0] === head) {
    const abbrev = new Abbreviator(repo.gitDir);
    ctx.stdout(`Updating ${abbrev.abbreviate(head)}..${abbrev.abbreviate(theirs)}\n`);
    const problems = switchTrees(repo, index, ignore, headFiles, commitFiles(repo.gitDir, theirs));
    if (problems) {
      reportCheckoutProblems(ctx, problems, MERGE_ACTION);
      return 1;
    }
    ctx.stdout("Fast-forward\n");
    writeIndex(repo.gitDir, index);
    updateHead(repo.gitDir, theirs);
    return 0;
  }

  // A real merge. Like the real git, save the local changes first (`git stash create`).
  saveLocalChanges(repo, ctx.env, index, head);
  const staged = [...diffFiles(headFiles, indexFiles(index)).keys()];
  if (staged.length > 0) {
    ctx.stderr(`error: Your local changes to the following files would be overwritten by merge:\n${staged.map((p) => `  ${p}\n`).join("")}`);
    ctx.stderr("Merge with strategy ort failed.\n");
    return 2;
  }
  const result = mergeCommits(repo.gitDir, head, theirs, bases, { ours: "HEAD", theirs: arg });
  for (const message of result.messages) ctx.stdout(`${message}\n`);
  for (const warning of result.warnings) ctx.stderr(`${warning}\n`);
  const problems = switchTrees(repo, index, ignore, headFiles, result.files);
  if (problems) {
    reportCheckoutProblems(ctx, problems, MERGE_ACTION);
    ctx.stderr("Merge with strategy ort failed.\n");
    return 2;
  }
  recordConflicts(index, result);
  writeIndex(repo.gitDir, index);

  const messages = parsed.options.get("message");
  const message = messages ? messages.join("\n\n") : defaultMessage(repo.gitDir, arg);
  if (result.conflicts.length > 0) {
    const conflicts = index.unmergedPaths().map((p) => `#\t${p}\n`).join("");
    writeMergeState(repo.gitDir, theirs, `${message}\n\n# Conflicts:\n${conflicts}`);
    ctx.stdout("Automatic merge failed; fix conflicts and then commit the result.\n");
    return 1;
  }
  updateHead(repo.gitDir, writeCommit(repo, ctx.env, result.tree, [head, theirs], cleanupMessage(`${message}\n`)));
  ctx.stdout("Merge made by the 'ort' strategy.\n");
  return 0;
}
