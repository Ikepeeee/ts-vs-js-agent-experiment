import fs from "node:fs";
import path from "node:path";
import type { CommandContext } from "../cli/context.ts";
import { fatal, usageError } from "../cli/errors.ts";
import { hasOption, lastValue, parseOptions } from "../cli/options.ts";
import { loadConfig } from "../core/config/config.ts";
import { HEADS_PREFIX, isValidBranchName } from "../core/refs/refs.ts";
import { isGitDirectory } from "../core/repo/repository.ts";

const DEFAULT_CONFIG = "[core]\n\trepositoryformatversion = 0\n\tfilemode = true\n\tbare = false\n\tlogallrefupdates = true\n";

export function init(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [
    { name: "quiet", short: "q", long: "quiet" },
    { name: "branch", short: "b", long: "initial-branch", takesValue: true },
  ]);
  if (parsed.positionals.length > 1) throw usageError("too many arguments");
  const quiet = hasOption(parsed, "quiet");
  const branch = lastValue(parsed, "branch");

  const target = path.resolve(ctx.cwd, parsed.positionals[0] ?? ".");
  try {
    fs.mkdirSync(target, { recursive: true });
  } catch {
    throw fatal(`cannot mkdir ${parsed.positionals[0]}: File exists`);
  }
  const gitDir = path.join(fs.realpathSync(target), ".git");

  if (isGitDirectory(gitDir)) {
    if (branch !== undefined) ctx.stderr(`warning: re-init: ignored --initial-branch=${branch}\n`);
    if (!quiet) ctx.stdout(`Reinitialized existing Git repository in ${gitDir}/\n`);
    return 0;
  }

  // The same order as the real git, which leaves the refs and the config behind when the branch
  // name is invalid.
  for (const dir of ["refs/heads", "refs/tags"]) fs.mkdirSync(path.join(gitDir, dir), { recursive: true });
  fs.writeFileSync(path.join(gitDir, "config"), DEFAULT_CONFIG);
  const initialBranch = branch ?? loadConfig(ctx.env, null).get("init.defaultBranch") ?? "master";
  if (!isValidBranchName(initialBranch)) throw fatal(`invalid initial branch name: '${initialBranch}'`);
  fs.writeFileSync(path.join(gitDir, "HEAD"), `ref: ${HEADS_PREFIX}${initialBranch}\n`);
  for (const dir of ["objects/info", "objects/pack"]) fs.mkdirSync(path.join(gitDir, dir), { recursive: true });
  if (!quiet) ctx.stdout(`Initialized empty Git repository in ${gitDir}/\n`);
  return 0;
}
