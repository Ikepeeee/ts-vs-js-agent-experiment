import type { CommandContext } from "../cli/context.ts";
import { fatal, usageError } from "../cli/errors.ts";
import { parseOptions } from "../cli/options.ts";
import { quotePath } from "../cli/quote.ts";
import { readObject, type GitObject } from "../core/objects/store.ts";
import { MODE_TREE, parseTree } from "../core/objects/tree.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { resolveRevision } from "../core/revision/resolve.ts";

const MODES = ["t", "s", "p"];

function prettyPrint(object: GitObject): Buffer {
  if (object.type !== "tree") return object.data;
  const lines = parseTree(object.data).map((entry) => {
    const type = entry.mode === MODE_TREE ? "tree" : entry.mode === "160000" ? "commit" : "blob";
    return `${entry.mode.padStart(6, "0")} ${type} ${entry.oid}\t${quotePath(entry.name)}\n`;
  });
  return Buffer.from(lines.join(""), "utf8");
}

export function catFile(ctx: CommandContext): number {
  const parsed = parseOptions(
    ctx.args,
    MODES.map((m) => ({ name: m, short: m })),
  );
  const modes = MODES.filter((m) => parsed.options.has(m));
  if (modes.length > 1) throw usageError(`options '-${modes[0]}' and '-${modes[1]}' cannot be used together`);
  const mode = modes[0];
  if (mode === undefined) throw usageError("only two arguments allowed in <type> <object> mode");
  if (parsed.positionals.length !== 1) {
    throw usageError(parsed.positionals.length === 0 ? `<object> required with '-${mode}'` : "too many arguments");
  }
  const name = parsed.positionals[0] as string;

  const repo = requireRepository(ctx.cwd, ctx.env);
  const oid = resolveRevision(repo.gitDir, name);
  const object = oid === null ? null : readObject(repo.gitDir, oid);
  if (!object) throw fatal(`Not a valid object name ${name}`);

  if (mode === "t") ctx.stdout(`${object.type}\n`);
  else if (mode === "s") ctx.stdout(`${object.data.length}\n`);
  else ctx.stdout(prettyPrint(object));
  return 0;
}
