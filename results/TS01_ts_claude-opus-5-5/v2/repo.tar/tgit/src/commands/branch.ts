import type { CommandContext } from "../cli/context.ts";
import { fatal, usageError } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { readReflog } from "../core/refs/reflog.ts";
import { HEADS_PREFIX, deleteRef, isValidBranchName, listRefs, readHead, readRef, resolveHead, writeRef } from "../core/refs/refs.ts";
import { requireRepository, type Repository } from "../core/repo/repository.ts";
import { Abbreviator } from "../core/revision/abbrev.ts";
import { refCandidates, resolveCommit } from "../core/revision/resolve.ts";
import { isAncestor } from "../core/revision/walk.ts";

/**
 * How the real git describes a detached HEAD: "at" or "from" the target of the last checkout
 * recorded in the HEAD reflog. A tag or remote-tracking branch is shown by name, anything else by
 * the abbreviated commit ID.
 */
function describeDetachedHead(repo: Repository, headOid: string): string {
  const checkout = readReflog(repo.gitDir, "HEAD")
    .reverse()
    .find((entry) => entry.message.startsWith("checkout: moving from "));
  if (!checkout) return "(no branch)";
  const target = checkout.message.slice(checkout.message.lastIndexOf(" to ") + 4);
  const ref = refCandidates(target).find((candidate) => readRef(repo.gitDir, candidate) !== null);
  const shortName = ref && /^refs\/(tags|remotes)\//.test(ref) ? ref.replace(/^refs\/(tags|remotes)\//, "") : null;
  const name = shortName ?? new Abbreviator(repo.gitDir).abbreviate(checkout.newOid);
  return `(HEAD detached ${headOid === checkout.newOid ? "at" : "from"} ${name})`;
}

function listBranches(ctx: CommandContext, repo: Repository): number {
  const head = readHead(repo.gitDir);
  const lines: string[] = [];
  if (head.kind === "detached") lines.push(`* ${describeDetachedHead(repo, head.oid)}\n`);
  for (const ref of listRefs(repo.gitDir, HEADS_PREFIX)) {
    const current = head.kind === "branch" && head.ref === ref.name;
    lines.push(`${current ? "*" : " "} ${ref.name.slice(HEADS_PREFIX.length)}\n`);
  }
  ctx.stdout(lines.join(""));
  return 0;
}

function createBranch(repo: Repository, name: string, startPoint: string | undefined): void {
  if (!isValidBranchName(name)) throw fatal(`'${name}' is not a valid branch name`);
  if (readRef(repo.gitDir, HEADS_PREFIX + name) !== null) throw fatal(`a branch named '${name}' already exists`);
  let start = startPoint;
  if (start === undefined) {
    // On an unborn branch the real git reports the branch's name as the bad start point.
    const head = readHead(repo.gitDir);
    start = head.kind === "branch" && resolveHead(repo.gitDir) === null ? head.ref.slice(HEADS_PREFIX.length) : "HEAD";
  }
  const oid = resolveCommit(repo.gitDir, start);
  if (oid === null) throw fatal(`not a valid object name: '${start}'`);
  writeRef(repo.gitDir, HEADS_PREFIX + name, oid);
}

function deleteBranches(ctx: CommandContext, repo: Repository, names: readonly string[]): number {
  if (names.length === 0) throw fatal("branch name required");
  const head = readHead(repo.gitDir);
  const headOid = resolveHead(repo.gitDir);
  const abbreviator = new Abbreviator(repo.gitDir);
  let failed = false;
  for (const name of names) {
    const ref = HEADS_PREFIX + name;
    const oid = readRef(repo.gitDir, ref);
    if (head.kind === "branch" && head.ref === ref) {
      ctx.stderr(`error: cannot delete branch '${name}' used by worktree at '${repo.workTree}'\n`);
      failed = true;
    } else if (oid === null) {
      ctx.stderr(`error: branch '${name}' not found\n`);
      failed = true;
    } else if (headOid === null || !isAncestor(repo.gitDir, oid, headOid)) {
      ctx.stderr(`error: the branch '${name}' is not fully merged\nhint: If you are sure you want to delete it, run 'git branch -D ${name}'\n`);
      failed = true;
    } else {
      deleteRef(repo.gitDir, ref);
      ctx.stdout(`Deleted branch ${name} (was ${abbreviator.abbreviate(oid)}).\n`);
    }
  }
  return failed ? 1 : 0;
}

export function branch(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "delete", short: "d", long: "delete" }]);
  const repo = requireRepository(ctx.cwd, ctx.env);
  const [name, startPoint, ...rest] = parsed.positionals;
  if (hasOption(parsed, "delete")) return deleteBranches(ctx, repo, parsed.positionals);
  if (name === undefined) return listBranches(ctx, repo);
  if (rest.length > 0) throw usageError("too many arguments for a create operation");
  createBranch(repo, name, startPoint);
  return 0;
}
