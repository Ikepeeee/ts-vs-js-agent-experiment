import type { CommandContext } from "../cli/context.ts";
import { fatal, usageError } from "../cli/errors.ts";
import { parseOptions } from "../cli/options.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { mergeBases } from "../core/revision/merge-base.ts";
import { resolveCommit, resolveRevision } from "../core/revision/resolve.ts";

/** `git merge-base <commit> <commit>...`: prints the best common ancestor, or exits 1 if there is none. */
export function mergeBase(ctx: CommandContext): number {
  const repo = requireRepository(ctx.cwd, ctx.env);
  const { positionals } = parseOptions(ctx.args, []);
  if (positionals.length < 2) throw usageError("usage: git merge-base <commit> <commit>...");
  const [one, ...twos] = positionals.map((revision) => {
    if (resolveRevision(repo.gitDir, revision) === null) throw fatal(`Not a valid object name ${revision}`);
    const oid = resolveCommit(repo.gitDir, revision);
    if (oid === null) throw fatal(`Not a valid commit name ${revision}`);
    return oid;
  });
  const [base] = mergeBases(repo.gitDir, one as string, twos);
  if (base === undefined) return 1;
  ctx.stdout(`${base}\n`);
  return 0;
}
