import type { CommandContext } from "../cli/context.ts";
import { usageError } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { quotePath } from "../cli/quote.ts";
import { readIndex, type IndexEntry } from "../core/index/index-file.ts";
import { comparePaths } from "../core/paths.ts";
import { resolveHead } from "../core/refs/refs.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { commitFiles, diffFiles, indexFiles, worktreeFiles } from "../core/status/changes.ts";
import { IgnoreRules } from "../core/worktree/ignore.ts";
import { scanWorktree } from "../core/worktree/scan.ts";

/** The two-letter code of an unmerged path, from the stages it has (1 base, 2 ours, 3 theirs). */
const UNMERGED_CODES = ["", "DD", "AU", "UD", "UA", "DU", "AA", "UU"];

function unmergedCode(stages: readonly IndexEntry[]): string {
  let mask = 0;
  for (const entry of stages) mask |= 1 << ((entry.stage ?? 1) - 1);
  return UNMERGED_CODES[mask] ?? "UU";
}

/** `git status --porcelain`: paths are always relative to the top of the working tree. */
export function status(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "porcelain", long: "porcelain" }]);
  if (!hasOption(parsed, "porcelain")) throw usageError("only --porcelain is supported");
  const repo = requireRepository(ctx.cwd, ctx.env);
  const index = readIndex(repo.gitDir);
  const files = indexFiles(index);
  const staged = diffFiles(commitFiles(repo.gitDir, resolveHead(repo.gitDir)), files);
  const unstaged = diffFiles(files, worktreeFiles(repo, index));
  const unmerged = new Map(index.unmergedPaths().map((filePath) => [filePath, unmergedCode(index.stages(filePath))]));
  for (const filePath of unmerged.keys()) staged.delete(filePath);

  const quote = (filePath: string): string => quotePath(filePath, { quoteSpace: true });
  const changed = [...new Set([...staged.keys(), ...unstaged.keys(), ...unmerged.keys()])].sort(comparePaths);
  const lines = changed.map((filePath) => {
    const code = unmerged.get(filePath) ?? `${staged.get(filePath) ?? " "}${unstaged.get(filePath) ?? " "}`;
    return `${code} ${quote(filePath)}\n`;
  });
  const { untracked } = scanWorktree(repo, index, IgnoreRules.load(repo), { collapseDirectories: true });
  for (const filePath of untracked.sort(comparePaths)) lines.push(`?? ${quote(filePath)}\n`);
  ctx.stdout(lines.join(""));
  return 0;
}
