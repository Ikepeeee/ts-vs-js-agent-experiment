import type { CommandContext } from "../cli/context.ts";
import { fatal } from "../cli/errors.ts";
import { formatCommitMedium } from "../cli/commit-format.ts";
import { formatCombinedDiff, type CombinedPath } from "../core/diff/combined.ts";
import { filePairs, readBlob } from "../core/diff/file-pairs.ts";
import { formatPatch } from "../core/diff/patch.ts";
import { readCommit, type Commit } from "../core/objects/commit.ts";
import { flattenTree, type FileEntry } from "../core/objects/tree.ts";
import { comparePaths } from "../core/paths.ts";
import { HEADS_PREFIX, readHead, resolveHead } from "../core/refs/refs.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { Abbreviator } from "../core/revision/abbrev.ts";
import { resolveCommit } from "../core/revision/resolve.ts";
import { commitFiles } from "../core/status/changes.ts";

const NULL_OID = "0".repeat(40);

function same(a: FileEntry | undefined, b: FileEntry | undefined): boolean {
  return a?.mode === b?.mode && a?.oid === b?.oid;
}

/**
 * The paths of a merge for its combined diff: those whose result differs from every parent,
 * each with the result and every parent's version.
 */
function combinedPaths(gitDir: string, commit: Commit): CombinedPath[] {
  const result = flattenTree(gitDir, commit.tree);
  const parents = commit.parents.map((parent) => commitFiles(gitDir, parent));
  const paths = new Set([...result.keys(), ...parents.flatMap((files) => [...files.keys()])]);
  const changed = [...paths].filter((filePath) => parents.every((files) => !same(files.get(filePath), result.get(filePath))));
  return changed.sort(comparePaths).map((filePath) => {
    const file = result.get(filePath);
    return {
      path: filePath,
      mode: file ? Number.parseInt(file.mode, 8) : 0,
      oid: file?.oid ?? null,
      data: file ? readBlob(gitDir, file.oid) : Buffer.alloc(0),
      parents: parents.map((files) => {
        const old = files.get(filePath);
        return {
          mode: old ? Number.parseInt(old.mode, 8) : 0,
          oid: old?.oid ?? NULL_OID,
          data: old ? readBlob(gitDir, old.oid) : Buffer.alloc(0),
          added: !old,
        };
      }),
    };
  });
}

/** A commit with its patch against its parent, or for a merge, its dense combined diff. */
function showCommit(gitDir: string, oid: string, commit: Commit, abbreviator: Abbreviator): Buffer {
  const abbreviate = (id: string): string => abbreviator.abbreviate(id);
  const header = Buffer.from(formatCommitMedium(oid, commit, abbreviator));
  if (commit.parents.length > 1) {
    const diffs = combinedPaths(gitDir, commit).map((item) => formatCombinedDiff(item, abbreviate, false));
    return Buffer.concat([header, Buffer.from("\n"), ...diffs]);
  }
  const pairs = filePairs(gitDir, commitFiles(gitDir, commit.parents[0] ?? null), flattenTree(gitDir, commit.tree));
  if (pairs.length === 0) return header;
  return Buffer.concat([header, Buffer.from("\n"), ...pairs.map((pair) => formatPatch(pair, abbreviate))]);
}

export function show(ctx: CommandContext): number {
  const repo = requireRepository(ctx.cwd, ctx.env);
  const revisions: string[] = [];
  for (const arg of ctx.args) {
    if (arg.startsWith("-")) throw fatal(`unrecognized argument: ${arg}`);
    revisions.push(arg);
  }
  if (revisions.length === 0) {
    if (resolveHead(repo.gitDir) === null) {
      const head = readHead(repo.gitDir);
      const name = head.kind === "branch" ? head.ref.replace(HEADS_PREFIX, "") : "HEAD";
      throw fatal(`your current branch '${name}' does not have any commits yet`);
    }
    revisions.push("HEAD");
  }
  const oids = revisions.map((revision) => {
    const oid = resolveCommit(repo.gitDir, revision);
    if (oid === null) throw fatal(`ambiguous argument '${revision}': unknown revision or path not in the working tree.`);
    return oid;
  });

  const abbreviator = new Abbreviator(repo.gitDir);
  const shown = oids.map((oid) => showCommit(repo.gitDir, oid, readCommit(repo.gitDir, oid) as Commit, abbreviator));
  ctx.stdout(Buffer.concat(shown.flatMap((entry, i) => (i === 0 ? [entry] : [Buffer.from("\n"), entry]))));
  return 0;
}
