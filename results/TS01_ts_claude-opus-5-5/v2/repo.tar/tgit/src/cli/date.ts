const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** Formats a date like the real git's default date format: "Tue Nov 14 22:13:20 2023 +0000". */
export function formatDefaultDate(timestamp: number, tz: string): string {
  // The real git reads the timezone as a decimal number (e.g. -700) and prints it with "%+05d".
  const tzValue = Number.parseInt(tz, 10) || 0;
  const offsetMinutes = Math.trunc(tzValue / 100) * 60 + (tzValue % 100);
  const date = new Date((timestamp + offsetMinutes * 60) * 1000);
  const pad = (n: number): string => String(n).padStart(2, "0");
  const time = `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;
  const zone = `${tzValue < 0 ? "-" : "+"}${String(Math.abs(tzValue)).padStart(4, "0")}`;
  return `${WEEKDAYS[date.getUTCDay()]} ${MONTHS[date.getUTCMonth()]} ${date.getUTCDate()} ${time} ${date.getUTCFullYear()} ${zone}`;
}
