import { usageError } from "./errors.ts";

export interface OptionDef {
  /** The key the option is stored under. */
  name: string;
  short?: string;
  long?: string;
  takesValue?: boolean;
}

export interface ParsedOptions {
  /** Values given for each option, in order. A flag without a value records "". */
  options: Map<string, string[]>;
  positionals: string[];
}

/**
 * Parses arguments like the real git's parse-options: options may come after positionals,
 * short flags may be clustered (`-qb main`, `-bmain`), long options take `--name=value` or
 * `--name value`, and `--` ends the options. Unknown options are usage errors (exit code 129).
 */
export function parseOptions(args: readonly string[], defs: readonly OptionDef[]): ParsedOptions {
  const options = new Map<string, string[]>();
  const positionals: string[] = [];
  const record = (def: OptionDef, value: string): void => {
    const values = options.get(def.name) ?? [];
    values.push(value);
    options.set(def.name, values);
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i] as string;
    if (arg === "--") {
      positionals.push(...args.slice(i + 1));
      break;
    }
    if (arg.startsWith("--")) {
      const eq = arg.indexOf("=");
      const name = eq < 0 ? arg.slice(2) : arg.slice(2, eq);
      const def = defs.find((d) => d.long === name);
      if (!def) throw usageError(`unknown option \`${name}'`);
      if (!def.takesValue) {
        if (eq >= 0) throw usageError(`option \`${name}' takes no value`);
        record(def, "");
      } else if (eq >= 0) {
        record(def, arg.slice(eq + 1));
      } else {
        if (i + 1 >= args.length) throw usageError(`option \`${name}' requires a value`);
        record(def, args[++i] as string);
      }
      continue;
    }
    if (arg.startsWith("-") && arg.length > 1) {
      for (let j = 1; j < arg.length; j++) {
        const ch = arg[j] as string;
        const def = defs.find((d) => d.short === ch);
        if (!def) throw usageError(`unknown switch \`${ch}'`);
        if (!def.takesValue) {
          record(def, "");
          continue;
        }
        if (j + 1 < arg.length) {
          record(def, arg.slice(j + 1));
        } else {
          if (i + 1 >= args.length) throw usageError(`switch \`${ch}' requires a value`);
          record(def, args[++i] as string);
        }
        break;
      }
      continue;
    }
    positionals.push(arg);
  }
  return { options, positionals };
}

/** Whether a flag was given at least once. */
export function hasOption(parsed: ParsedOptions, name: string): boolean {
  return parsed.options.has(name);
}

/** The last value given for an option. */
export function lastValue(parsed: ParsedOptions, name: string): string | undefined {
  return parsed.options.get(name)?.at(-1);
}
