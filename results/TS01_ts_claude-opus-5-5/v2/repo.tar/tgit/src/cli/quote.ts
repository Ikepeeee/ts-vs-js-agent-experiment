const ESCAPES: Record<number, string> = {
  0x07: "\\a",
  0x08: "\\b",
  0x09: "\\t",
  0x0a: "\\n",
  0x0b: "\\v",
  0x0c: "\\f",
  0x0d: "\\r",
  0x22: '\\"',
  0x5c: "\\\\",
};

/**
 * Quotes a path the way the real git does with the default `core.quotePath=true`: if it contains
 * a double quote, a backslash, a control character, or a non-ASCII byte, it is wrapped in double
 * quotes with C-style escapes and octal bytes. With `quoteSpace`, a space also forces quoting
 * (as in `git status --porcelain`).
 */
export function quotePath(path: string, options: { quoteSpace?: boolean } = {}): string {
  const bytes = Buffer.from(path, "utf8");
  let needsQuotes = options.quoteSpace === true && path.includes(" ");
  let body = "";
  for (const byte of bytes) {
    const escape = ESCAPES[byte];
    if (escape !== undefined) {
      body += escape;
      needsQuotes = true;
    } else if (byte < 0x20 || byte >= 0x7f) {
      body += "\\" + byte.toString(8).padStart(3, "0");
      needsQuotes = true;
    } else {
      body += String.fromCharCode(byte);
    }
  }
  return needsQuotes ? `"${body}"` : path;
}
