/** Ends the command: the message goes to standard error and the process exits with `code`. */
export class ExitError extends Error {
  readonly code: number;

  constructor(message: string, code: number) {
    super(message);
    this.code = code;
  }
}

/** A fatal error, reported like the real git's `die()`: exit code 128. */
export function fatal(message: string): ExitError {
  return new ExitError(`fatal: ${message}`, 128);
}

/** A usage error, reported like the real git's option parser: exit code 129. */
export function usageError(message: string): ExitError {
  return new ExitError(`error: ${message}`, 129);
}
