import { commitSubject, messageLines, parseIdent, type Commit } from "../core/objects/commit.ts";
import type { Abbreviator } from "../core/revision/abbrev.ts";
import { formatDefaultDate } from "./date.ts";

const TAB_WIDTH = 8;

/** The number of terminal columns a character takes: 2 for wide East Asian characters, 0 for combining marks. */
function charWidth(codePoint: number): number {
  if ((codePoint >= 0x300 && codePoint <= 0x36f) || (codePoint >= 0x200b && codePoint <= 0x200f)) return 0;
  const wide =
    (codePoint >= 0x1100 && codePoint <= 0x115f) ||
    (codePoint >= 0x2e80 && codePoint <= 0xa4cf && codePoint !== 0x303f) ||
    (codePoint >= 0xac00 && codePoint <= 0xd7a3) ||
    (codePoint >= 0xf900 && codePoint <= 0xfaff) ||
    (codePoint >= 0xfe30 && codePoint <= 0xfe4f) ||
    (codePoint >= 0xff00 && codePoint <= 0xff60) ||
    (codePoint >= 0xffe0 && codePoint <= 0xffe6) ||
    (codePoint >= 0x1f300 && codePoint <= 0x1f64f) ||
    (codePoint >= 0x1f900 && codePoint <= 0x1f9ff) ||
    (codePoint >= 0x20000 && codePoint <= 0x3fffd);
  return wide ? 2 : 1;
}

/** Replaces TABs with spaces up to the next multiple of 8 columns, as the real git does in log messages. */
export function expandTabs(line: string): string {
  if (!line.includes("\t")) return line;
  let out = "";
  let column = 0;
  for (const ch of line) {
    if (ch === "\t") {
      const spaces = TAB_WIDTH - (column % TAB_WIDTH);
      out += " ".repeat(spaces);
      column += spaces;
    } else {
      out += ch;
      column += charWidth(ch.codePointAt(0) ?? 0);
    }
  }
  return out;
}

/** A commit in the default (`medium`) format of `log` and `show`, ending with the message's last line. */
export function formatCommitMedium(oid: string, commit: Commit, abbreviator: Abbreviator): string {
  const author = parseIdent(commit.author);
  let header = `commit ${oid}\n`;
  if (commit.parents.length > 1) header += `Merge: ${commit.parents.map((p) => abbreviator.abbreviate(p)).join(" ")}\n`;
  header += `Author: ${author.name} <${author.email}>\nDate:   ${formatDefaultDate(author.timestamp, author.tz)}\n\n`;
  return header + messageLines(commit.message).map((line) => `    ${expandTabs(line)}\n`).join("");
}

/** A commit in the `--oneline` format. */
export function formatCommitOneline(oid: string, commit: Commit, abbreviator: Abbreviator): string {
  return `${abbreviator.abbreviate(oid)} ${commitSubject(commit)}\n`;
}
