import type { CheckoutProblems } from "../core/checkout/two-way.ts";
import type { CommandContext } from "./context.ts";

/** How the real git names the operation in its messages: by `checkout` or `merge`, and before you `switch branches` or `merge`. */
export interface CheckoutAction {
  by: string;
  before: string;
}

/** Reports why a checkout of another tree would lose local changes or untracked files. */
export function reportCheckoutProblems(ctx: CommandContext, problems: CheckoutProblems, action: CheckoutAction): void {
  const section = (paths: string[], what: string, advice: string): void => {
    if (paths.length === 0) return;
    ctx.stderr(`error: ${what}\n${paths.map((p) => `\t${p}\n`).join("")}${advice}\n`);
  };
  section(
    problems.localChanges,
    `Your local changes to the following files would be overwritten by ${action.by}:`,
    `Please commit your changes or stash them before you ${action.before}.`,
  );
  section(
    problems.untrackedOverwritten,
    `The following untracked working tree files would be overwritten by ${action.by}:`,
    `Please move or remove them before you ${action.before}.`,
  );
  section(
    problems.untrackedRemoved,
    `The following untracked working tree files would be removed by ${action.by}:`,
    `Please move or remove them before you ${action.before}.`,
  );
  ctx.stderr("Aborting\n");
}
