/** What a command receives from the entry point. */
export interface CommandContext {
  /** The arguments after the command name. */
  args: string[];
  cwd: string;
  env: NodeJS.ProcessEnv;
  stdout: (text: string | Buffer) => void;
  stderr: (text: string) => void;
}

/** A command returns its exit code, or throws an `ExitError`. */
export type CommandRun = (ctx: CommandContext) => number;
