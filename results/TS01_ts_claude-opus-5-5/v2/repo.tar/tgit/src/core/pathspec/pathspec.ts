import path from "node:path";
import { fatal } from "../../cli/errors.ts";
import { joinPath } from "../paths.ts";
import { hasWildcard, wildmatch } from "../worktree/wildmatch.ts";

export interface PathspecItem {
  /** The argument as given. */
  original: string;
  /** The path relative to the top of the working tree ("" for the whole tree). */
  path: string;
  wildcard: boolean;
}

/** Resolves pathspec arguments given relative to `prefix` (the current directory in the working tree). */
export function parsePathspecs(args: readonly string[], prefix: string, workTree: string): PathspecItem[] {
  return args.map((arg) => {
    const joined = path.isAbsolute(arg) ? path.relative(workTree, arg).split(path.sep).join("/") : joinPath(prefix, arg);
    let normalized = path.posix.normalize(joined === "" ? "." : joined);
    if (normalized === ".." || normalized.startsWith("../")) {
      throw fatal(`${arg}: '${arg}' is outside repository at '${workTree}'`);
    }
    if (normalized === ".") normalized = "";
    if (normalized.endsWith("/")) normalized = normalized.slice(0, -1);
    return { original: arg, path: normalized, wildcard: hasWildcard(normalized) };
  });
}

/** Whether a path is matched by a pathspec item: the same path, a path inside it, or a glob match. */
export function matchesItem(item: PathspecItem, filePath: string): boolean {
  if (item.path === "" || filePath === item.path || filePath.startsWith(`${item.path}/`)) return true;
  return item.wildcard && wildmatch(item.path, filePath);
}

export function matchesAny(items: readonly PathspecItem[], filePath: string): boolean {
  return items.some((item) => matchesItem(item, filePath));
}
