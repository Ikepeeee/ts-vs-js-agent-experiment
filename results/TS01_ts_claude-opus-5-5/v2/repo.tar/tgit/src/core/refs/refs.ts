import fs from "node:fs";
import path from "node:path";
import { fatal } from "../../cli/errors.ts";
import { comparePaths } from "../paths.ts";
import { isObjectId } from "../objects/store.ts";

export const HEADS_PREFIX = "refs/heads/";

/** HEAD either points at a branch (which may not exist yet) or holds a commit ID directly. */
export type Head = { kind: "branch"; ref: string } | { kind: "detached"; oid: string };

function readRefFile(gitDir: string, name: string): string | null {
  try {
    return fs.readFileSync(path.join(gitDir, name), "utf8").trim();
  } catch {
    return null;
  }
}

export function readHead(gitDir: string): Head {
  const content = readRefFile(gitDir, "HEAD") ?? "";
  if (content.startsWith("ref: ")) return { kind: "branch", ref: content.slice(5).trim() };
  return { kind: "detached", oid: content };
}

/** Resolves a ref (following symbolic refs) to an object ID, or null if it does not exist. */
export function readRef(gitDir: string, name: string): string | null {
  let current = name;
  for (let depth = 0; depth < 5; depth++) {
    const content = readRefFile(gitDir, current);
    if (content === null) return null;
    if (!content.startsWith("ref: ")) return isObjectId(content) ? content : null;
    current = content.slice(5).trim();
  }
  return null;
}

/** The commit HEAD points at, or null on an unborn branch. */
export function resolveHead(gitDir: string): string | null {
  return readRef(gitDir, "HEAD");
}

/** Moves the current branch (or a detached HEAD) to a commit. */
export function updateHead(gitDir: string, oid: string): void {
  const head = readHead(gitDir);
  writeRef(gitDir, head.kind === "branch" ? head.ref : "HEAD", oid);
}

/** Points HEAD at a branch. */
export function setHeadToBranch(gitDir: string, ref: string): void {
  fs.writeFileSync(path.join(gitDir, "HEAD"), `ref: ${ref}\n`);
}

/** Creates or updates a ref; fails like the real git if it conflicts with an existing ref's path. */
export function writeRef(gitDir: string, name: string, oid: string): void {
  const file = path.join(gitDir, name);
  const parts = name.split("/");
  for (let i = 1; i < parts.length; i++) {
    const prefix = parts.slice(0, i).join("/");
    if (fs.existsSync(path.join(gitDir, prefix)) && !fs.statSync(path.join(gitDir, prefix)).isDirectory()) {
      throw fatal(`cannot lock ref '${name}': '${prefix}' exists; cannot create '${name}'`);
    }
  }
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) {
    const inside = listRefs(gitDir, `${name}/`)[0]?.name ?? `${name}/`;
    throw fatal(`cannot lock ref '${name}': '${inside}' exists; cannot create '${name}'`);
  }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const lock = `${file}.lock`;
  fs.writeFileSync(lock, `${oid}\n`);
  fs.renameSync(lock, file);
}

/** Deletes a ref and any directories under `refs/` left empty. */
export function deleteRef(gitDir: string, name: string): void {
  fs.rmSync(path.join(gitDir, name), { force: true });
  let dir = path.dirname(name);
  while (dir.includes("/")) {
    try {
      fs.rmdirSync(path.join(gitDir, dir));
    } catch {
      return;
    }
    dir = path.dirname(dir);
  }
}

export interface RefEntry {
  name: string;
  oid: string;
}

/** Lists the refs whose names start with `prefix` (which ends in "/"), sorted by name. */
export function listRefs(gitDir: string, prefix: string): RefEntry[] {
  const refs: RefEntry[] = [];
  const walk = (dir: string): void => {
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(path.join(gitDir, dir), { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const name = `${dir}${entry.name}`;
      if (entry.isDirectory()) {
        walk(`${name}/`);
      } else if (!entry.name.endsWith(".lock")) {
        const oid = readRef(gitDir, name);
        if (oid) refs.push({ name, oid });
      }
    }
  };
  walk(prefix);
  return refs.sort((a, b) => comparePaths(a.name, b.name));
}

/** Checks a full ref name ("refs/heads/x") against the rules of `git check-ref-format`. */
export function isValidRefName(name: string): boolean {
  if (name === "@" || name.endsWith("/") || name.endsWith(".") || name.includes("..") || name.includes("@{")) return false;
  if ([...name].some((ch) => ch <= " " || ch === "\x7f") || /[~^:?*[\\]/.test(name)) return false;
  return name.split("/").every((part) => part !== "" && !part.startsWith(".") && !part.endsWith(".lock"));
}

/** Whether a name can be used as a branch name. */
export function isValidBranchName(name: string): boolean {
  return name !== "HEAD" && !name.startsWith("-") && isValidRefName(HEADS_PREFIX + name);
}
