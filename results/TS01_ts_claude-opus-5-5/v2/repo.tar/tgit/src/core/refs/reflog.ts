import fs from "node:fs";
import path from "node:path";

export interface ReflogEntry {
  oldOid: string;
  newOid: string;
  message: string;
}

/** Reads the reflog of a ref (e.g. "HEAD"), oldest entry first; empty if there is none. */
export function readReflog(gitDir: string, ref: string): ReflogEntry[] {
  let text: string;
  try {
    text = fs.readFileSync(path.join(gitDir, "logs", ref), "utf8");
  } catch {
    return [];
  }
  const entries: ReflogEntry[] = [];
  for (const line of text.split("\n")) {
    const match = /^([0-9a-f]{40}) ([0-9a-f]{40}) [^\t]*\t?(.*)$/.exec(line);
    if (match) entries.push({ oldOid: match[1] as string, newOid: match[2] as string, message: match[3] as string });
  }
  return entries;
}
