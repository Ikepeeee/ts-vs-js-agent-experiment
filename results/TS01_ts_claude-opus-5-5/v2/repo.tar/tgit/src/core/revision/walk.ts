import { parseIdent, readCommit, type Commit } from "../objects/commit.ts";

export interface WalkedCommit {
  oid: string;
  commit: Commit;
}

/**
 * Walks the history reachable from `starts`, newest committer date first, like the real git's
 * default revision walk (commits with equal dates come out in the order they were queued).
 */
export function* walkHistory(gitDir: string, starts: readonly string[]): Generator<WalkedCommit> {
  const queue: (WalkedCommit & { date: number })[] = [];
  const seen = new Set<string>();
  const enqueue = (oid: string): void => {
    if (seen.has(oid)) return;
    seen.add(oid);
    const commit = readCommit(gitDir, oid);
    if (!commit) throw new Error(`could not read commit ${oid}`);
    const date = parseIdent(commit.committer).timestamp;
    let at = 0;
    while (at < queue.length && (queue[at] as { date: number }).date >= date) at++;
    queue.splice(at, 0, { oid, commit, date });
  };
  for (const oid of starts) enqueue(oid);
  for (let next = queue.shift(); next; next = queue.shift()) {
    yield { oid: next.oid, commit: next.commit };
    for (const parent of next.commit.parents) enqueue(parent);
  }
}

/** Whether `ancestor` is reachable from `descendant` (a commit counts as its own ancestor). */
export function isAncestor(gitDir: string, ancestor: string, descendant: string): boolean {
  for (const { oid } of walkHistory(gitDir, [descendant])) {
    if (oid === ancestor) return true;
  }
  return false;
}
