import { listObjectIds } from "../objects/store.ts";

/** The real git's default minimum length for abbreviated object IDs. */
export const DEFAULT_ABBREV = 7;

/** Abbreviates object IDs to the shortest prefix (at least 7 characters) that no other object shares. */
export class Abbreviator {
  private readonly sorted: string[];

  constructor(gitDir: string) {
    this.sorted = listObjectIds(gitDir).sort();
  }

  abbreviate(oid: string): string {
    let length = DEFAULT_ABBREV;
    const at = lowerBound(this.sorted, oid);
    for (const neighbor of [this.sorted[at - 1], this.sorted[this.sorted[at] === oid ? at + 1 : at]]) {
      if (neighbor === undefined) continue;
      let common = 0;
      while (common < oid.length && oid[common] === neighbor[common]) common++;
      length = Math.max(length, common + 1);
    }
    return oid.slice(0, length);
  }

  /** The objects whose IDs start with a (lowercase) hex prefix. */
  withPrefix(prefix: string): string[] {
    const matches: string[] = [];
    for (let i = lowerBound(this.sorted, prefix); i < this.sorted.length && (this.sorted[i] as string).startsWith(prefix); i++) {
      matches.push(this.sorted[i] as string);
    }
    return matches;
  }
}

function lowerBound(sorted: readonly string[], value: string): number {
  let lo = 0;
  let hi = sorted.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if ((sorted[mid] as string) < value) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
