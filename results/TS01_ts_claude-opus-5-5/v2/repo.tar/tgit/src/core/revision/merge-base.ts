// The best common ancestors of commits, found the way the real git's `get_merge_bases` finds them
// (without a commit-graph): the same commits, in the same order.
import { parseIdent, readCommit } from "../objects/commit.ts";

const PARENT1 = 1;
const PARENT2 = 2;
const STALE = 4;
const RESULT = 8;

interface CommitInfo {
  parents: string[];
  date: number;
}

/**
 * Reads commits once each, for their parents and committer dates. Virtual commits (the merged
 * merge bases of a recursive merge) are given by their parents and have date 0, as in the real git.
 */
class CommitCache {
  private readonly gitDir: string;
  private readonly cache = new Map<string, CommitInfo>();

  constructor(gitDir: string, virtualCommits: ReadonlyMap<string, readonly string[]>) {
    this.gitDir = gitDir;
    for (const [id, parents] of virtualCommits) this.cache.set(id, { parents: [...parents], date: 0 });
  }

  get(oid: string): CommitInfo {
    let info = this.cache.get(oid);
    if (!info) {
      const commit = readCommit(this.gitDir, oid);
      if (!commit) throw new Error(`could not read commit ${oid}`);
      info = { parents: commit.parents, date: parseIdent(commit.committer).timestamp };
      this.cache.set(oid, info);
    }
    return info;
  }
}

/** Inserts a commit into a list ordered by date, newest first, after those with the same date. */
function insertByDate(list: string[], oid: string, commits: CommitCache): void {
  const date = commits.get(oid).date;
  let at = 0;
  while (at < list.length && commits.get(list[at] as string).date >= date) at++;
  list.splice(at, 0, oid);
}

/**
 * Walks down from `one` and `twos` newest first, marking which side reaches each commit; commits
 * reached from both sides are common ancestors, and their ancestors become stale. Returns the
 * common ancestors found and the flags of every commit visited (`paint_down_to_common`).
 */
function paintDownToCommon(one: string, twos: readonly string[], commits: CommitCache): { result: string[]; flags: Map<string, number> } {
  const flags = new Map<string, number>();
  const result: string[] = [];
  const flagsOf = (oid: string): number => flags.get(oid) ?? 0;
  flags.set(one, PARENT1);
  if (twos.length === 0) return { result: [one], flags };

  // A priority queue by date, newest first; commits with equal dates come out in the order queued.
  const queue: { oid: string; date: number; seq: number }[] = [];
  let seq = 0;
  const put = (oid: string): void => {
    const entry = { oid, date: commits.get(oid).date, seq: seq++ };
    let at = queue.length;
    while (at > 0 && (queue[at - 1] as { date: number }).date < entry.date) at--;
    queue.splice(at, 0, entry);
  };
  put(one);
  for (const two of twos) {
    flags.set(two, flagsOf(two) | PARENT2);
    put(two);
  }

  while (queue.some((entry) => !(flagsOf(entry.oid) & STALE))) {
    const oid = (queue.shift() as { oid: string }).oid;
    let current = flagsOf(oid) & (PARENT1 | PARENT2 | STALE);
    if (current === (PARENT1 | PARENT2)) {
      if (!(flagsOf(oid) & RESULT)) {
        flags.set(oid, flagsOf(oid) | RESULT);
        insertByDate(result, oid, commits);
      }
      current |= STALE;
    }
    for (const parent of commits.get(oid).parents) {
      if ((flagsOf(parent) & current) === current) continue;
      flags.set(parent, flagsOf(parent) | current);
      put(parent);
    }
  }
  return { result, flags };
}

/** Drops the commits that are ancestors of other commits in the list (`remove_redundant`). */
function removeRedundant(oids: readonly string[], commits: CommitCache): string[] {
  const redundant = new Array<boolean>(oids.length).fill(false);
  oids.forEach((oid, i) => {
    if (redundant[i]) return;
    const others = oids.map((other, j) => ({ other, j })).filter(({ j }) => j !== i && !redundant[j]);
    const { flags } = paintDownToCommon(
      oid,
      others.map(({ other }) => other),
      commits,
    );
    if ((flags.get(oid) ?? 0) & PARENT2) redundant[i] = true;
    for (const { other, j } of others) if ((flags.get(other) ?? 0) & PARENT1) redundant[j] = true;
  });
  return oids.filter((_, i) => !redundant[i]);
}

/**
 * The best common ancestors of `one` and any of `twos`, newest first; empty for unrelated
 * histories. `virtualCommits` maps the IDs of virtual commits to their parents.
 */
export function mergeBases(
  gitDir: string,
  one: string,
  twos: readonly string[],
  virtualCommits: ReadonlyMap<string, readonly string[]> = new Map(),
): string[] {
  if (twos.includes(one)) return [one];
  const commits = new CommitCache(gitDir, virtualCommits);
  const found = paintDownToCommon(one, twos, commits);
  const list: string[] = [];
  for (const oid of found.result) {
    if (!((found.flags.get(oid) ?? 0) & STALE)) insertByDate(list, oid, commits);
  }
  if (list.length <= 1) return list;
  const result: string[] = [];
  for (const oid of removeRedundant(list, commits)) insertByDate(result, oid, commits);
  return result;
}
