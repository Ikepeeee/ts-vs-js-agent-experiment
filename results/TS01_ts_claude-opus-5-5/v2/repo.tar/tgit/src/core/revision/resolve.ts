import { readCommit } from "../objects/commit.ts";
import { isObjectId, readObject } from "../objects/store.ts";
import { isValidRefName, readRef } from "../refs/refs.ts";
import { Abbreviator } from "./abbrev.ts";

/** The real git's minimum length for an abbreviated object ID. */
const MINIMUM_ABBREV = 4;

/** The full ref names tried for a short name, in the real git's order. */
export function refCandidates(name: string): string[] {
  const candidates = [`refs/${name}`, `refs/tags/${name}`, `refs/heads/${name}`, `refs/remotes/${name}`, `refs/remotes/${name}/HEAD`];
  // As-is, a name is tried only if it is a full ref or a root ref such as HEAD.
  if (name.startsWith("refs/") || /^[A-Z_]+$/.test(name)) candidates.unshift(name);
  return candidates.filter((candidate) => /^[A-Z_]+$/.test(candidate) || isValidRefName(candidate));
}

/** Resolves a ref name ("main", "heads/main", "refs/heads/main", "HEAD") to an object ID. */
export function resolveRefName(gitDir: string, name: string): string | null {
  for (const candidate of refCandidates(name)) {
    const oid = readRef(gitDir, candidate);
    if (oid) return oid;
  }
  return null;
}

function resolveBase(gitDir: string, name: string, commitsOnly: boolean): string | null {
  if (name === "@") name = "HEAD";
  if (/^[0-9a-fA-F]{40}$/.test(name)) return name.toLowerCase();
  if (name === "") return null;
  const fromRef = resolveRefName(gitDir, name);
  if (fromRef) return fromRef;
  if (name.length >= MINIMUM_ABBREV && /^[0-9a-fA-F]+$/.test(name)) {
    let matches = new Abbreviator(gitDir).withPrefix(name.toLowerCase());
    if (commitsOnly) matches = matches.filter((oid) => readObject(gitDir, oid)?.type === "commit");
    if (matches.length === 1) return matches[0] as string;
  }
  return null;
}

/**
 * Resolves a revision: a ref name, a full or abbreviated object ID, and any number of `~<n>` and
 * `^<n>` suffixes (as in "main~1^"). Returns null if it does not name an object.
 */
export function resolveRevision(gitDir: string, revision: string): string | null {
  const opStart = revision.search(/[~^]/);
  const base = opStart < 0 ? revision : revision.slice(0, opStart);
  let oid = resolveBase(gitDir, base, opStart >= 0);
  if (oid === null || opStart < 0) return oid;

  const ops = revision.slice(opStart);
  const opPattern = /([~^])(\d*)/y;
  let pos = 0;
  while (pos < ops.length) {
    opPattern.lastIndex = pos;
    const match = opPattern.exec(ops);
    if (!match) return null;
    pos = opPattern.lastIndex;
    const count = match[2] === "" ? 1 : Number(match[2]);
    const commit = readCommit(gitDir, oid);
    if (!commit) return null;
    if (match[1] === "^") {
      if (count === 0) continue;
      const parent = commit.parents[count - 1];
      if (parent === undefined) return null;
      oid = parent;
    } else {
      for (let i = 0; i < count; i++) {
        const parent: string | undefined = readCommit(gitDir, oid)?.parents[0];
        if (parent === undefined) return null;
        oid = parent;
      }
    }
  }
  return oid;
}

/** Resolves a revision that must name a commit. */
export function resolveCommit(gitDir: string, revision: string): string | null {
  const oid = resolveRevision(gitDir, revision);
  return oid !== null && isObjectId(oid) && readCommit(gitDir, oid) ? oid : null;
}
