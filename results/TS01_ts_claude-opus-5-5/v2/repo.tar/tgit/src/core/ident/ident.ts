import { fatal } from "../../cli/errors.ts";
import type { Ident } from "../objects/commit.ts";
import type { Repository } from "../repo/repository.ts";

export type IdentRole = "AUTHOR" | "COMMITTER";

/** The local timezone offset at a time, as "+hhmm". */
function localTimezone(timestamp: number): string {
  const offset = -new Date(timestamp * 1000).getTimezoneOffset();
  const abs = Math.abs(offset);
  return `${offset < 0 ? "-" : "+"}${String(Math.floor(abs / 60)).padStart(2, "0")}${String(abs % 60).padStart(2, "0")}`;
}

/** Parses the date formats accepted in GIT_AUTHOR_DATE: "<seconds> <tz>", "@<seconds>", and ISO 8601. */
export function parseDate(text: string): { timestamp: number; tz: string } | null {
  const raw = /^@?(\d+)(?: ([+-]\d{4}))?$/.exec(text.trim());
  if (raw) {
    const timestamp = Number(raw[1]);
    return { timestamp, tz: raw[2] ?? localTimezone(timestamp) };
  }
  const iso = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?: ?(Z|[+-]\d{2}:?\d{2}))?$/.exec(text.trim());
  if (!iso) return null;
  const [, year, month, day, hour, minute, second, zone] = iso;
  const utc = Date.UTC(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second)) / 1000;
  if (zone === undefined) {
    const tz = localTimezone(utc);
    return { timestamp: utc - offsetSeconds(tz), tz };
  }
  const tz = zone === "Z" ? "+0000" : zone.replace(":", "");
  return { timestamp: utc - offsetSeconds(tz), tz };
}

function offsetSeconds(tz: string): number {
  const sign = tz.startsWith("-") ? -1 : 1;
  return sign * (Number(tz.slice(1, 3)) * 3600 + Number(tz.slice(3, 5)) * 60);
}

/** The author or committer identity, from GIT_<ROLE>_NAME/EMAIL/DATE or `user.name`/`user.email`. */
export function identFor(role: IdentRole, repo: Repository, env: NodeJS.ProcessEnv): Ident {
  const name = env[`GIT_${role}_NAME`] ?? repo.config.get("user.name");
  const email = env[`GIT_${role}_EMAIL`] ?? repo.config.get("user.email");
  if (name === undefined || email === undefined || name.trim() === "") {
    throw fatal("unable to auto-detect name and email address; set user.name and user.email");
  }
  const dateText = env[`GIT_${role}_DATE`];
  let date: { timestamp: number; tz: string } | null;
  if (dateText === undefined) {
    const timestamp = Math.floor(Date.now() / 1000);
    date = { timestamp, tz: localTimezone(timestamp) };
  } else {
    date = parseDate(dateText);
    if (!date) throw fatal(`invalid date format: ${dateText}`);
  }
  return { name: name.trim(), email: email.trim(), ...date };
}
