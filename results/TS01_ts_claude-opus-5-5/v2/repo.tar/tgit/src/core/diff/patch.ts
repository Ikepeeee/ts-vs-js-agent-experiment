// The patch of one file in `git diff` format: the `diff --git` header lines, then the hunks.
import { quotePath } from "../../cli/quote.ts";
import { fileType } from "../objects/tree.ts";
import { formatHunks } from "./unified.ts";
import { DIFF_DEFAULTS, diffLines, isBinary } from "./xdiff.ts";

const NULL_ABBREV = "0000000";

/** One side of a file pair: its mode (e.g. "100644"), object ID, and content. */
export interface DiffBlob {
  mode: string;
  oid: string;
  data: Buffer;
}

/** A path that differs between two sides; a missing side means the file was added or deleted. */
export interface FilePair {
  path: string;
  old: DiffBlob | null;
  new: DiffBlob | null;
}

/** Formats a file pair as a patch. A change of file type is shown as a deletion and a creation. */
export function formatPatch(pair: FilePair, abbreviate: (oid: string) => string): Buffer {
  const { path, old, new: next } = pair;
  if (old && next && fileType(old.mode) !== fileType(next.mode)) {
    return Buffer.concat([formatPatch({ path, old, new: null }, abbreviate), formatPatch({ path, old: null, new: next }, abbreviate)]);
  }
  const a = quotePath(`a/${path}`);
  const b = quotePath(`b/${path}`);
  let header = `diff --git ${a} ${b}\n`;
  if (!old && next) header += `new file mode ${next.mode}\n`;
  else if (old && !next) header += `deleted file mode ${old.mode}\n`;
  else if (old && next && old.mode !== next.mode) header += `old mode ${old.mode}\nnew mode ${next.mode}\n`;
  if (old?.oid === next?.oid) return Buffer.from(header);

  header += `index ${old ? abbreviate(old.oid) : NULL_ABBREV}..${next ? abbreviate(next.oid) : NULL_ABBREV}`;
  header += old && next && old.mode === next.mode ? ` ${old.mode}\n` : "\n";
  const oldData = old?.data ?? Buffer.alloc(0);
  const newData = next?.data ?? Buffer.alloc(0);
  if (isBinary(oldData) || isBinary(newData)) {
    return Buffer.from(`${header}Binary files ${old ? a : "/dev/null"} and ${next ? b : "/dev/null"} differ\n`);
  }
  const hunks = formatHunks(diffLines(oldData, newData, DIFF_DEFAULTS));
  if (hunks.length === 0) return Buffer.from(header);
  // A TAB after a name with a space keeps the name apart from anything a tool appends.
  const tab = path.includes(" ") ? "\t" : "";
  header += `--- ${old ? a + tab : "/dev/null"}\n+++ ${next ? b + tab : "/dev/null"}\n`;
  return Buffer.concat([Buffer.from(header), hunks]);
}
