// A port of the Myers algorithm of xdiff (the library inside the real git), with its preparation step
// and heuristics, so that tgit picks the same diff as the real git where several are equally short.
import { setChanged, type DiffSide } from "./records.ts";

const MAX_EQLIMIT = 1024;
const SIMSCAN_WINDOW = 100;
const KPDIS_RUN = 4;
const MAX_COST_MIN = 256;
const HEUR_MIN_COST = 256;
const SNAKE_CNT = 20;
const K_HEUR = 4;
const LINE_MAX = 0x7fffffff;

/** xdiff's rough square root: a power of two near sqrt(n). */
export function bogosqrt(n: number): number {
  let i = 1;
  for (; n > 0; n >>= 2) i <<= 1;
  return i;
}

function countClasses(ha: Int32Array): Map<number, number> {
  const counts = new Map<number, number>();
  for (const cls of ha) counts.set(cls, (counts.get(cls) ?? 0) + 1);
  return counts;
}

/**
 * Decides whether a line that occurs many times in the other file is dropped from the comparison
 * (`xdl_clean_mmatch`): only when it sits in a run of lines that mostly have no match at all.
 */
function cleanMatch(dis: Uint8Array, i: number, s: number, e: number): boolean {
  if (i - s > SIMSCAN_WINDOW) s = i - SIMSCAN_WINDOW;
  if (e - i > SIMSCAN_WINDOW) e = i + SIMSCAN_WINDOW;
  let rdis0 = 0;
  let rpdis0 = 1;
  for (let r = 1; i - r >= s; r++) {
    const d = dis[i - r];
    if (d === 0) rdis0++;
    else if (d === 2) rpdis0++;
    else break;
  }
  if (rdis0 === 0) return false;
  let rdis1 = 0;
  let rpdis1 = 1;
  for (let r = 1; i + r <= e; r++) {
    const d = dis[i + r];
    if (d === 0) rdis1++;
    else if (d === 2) rpdis1++;
    else break;
  }
  if (rdis1 === 0) return false;
  rdis1 += rdis0;
  rpdis1 += rpdis0;
  return rpdis1 * KPDIS_RUN < rpdis1 + rdis1;
}

/** The lines that take part in the comparison after `xdl_trim_ends` and `xdl_cleanup_records`. */
interface Effective {
  ha: Int32Array;
  rindex: Int32Array;
}

function cleanupRecords(side: DiffSide, other: Map<number, number>, dstart: number, dend: number): Effective {
  const nrec = side.ha.length;
  const mlim = Math.min(bogosqrt(nrec), MAX_EQLIMIT);
  const dis = new Uint8Array(nrec + 1);
  for (let i = dstart; i <= dend; i++) {
    const nm = other.get(side.ha[i] ?? -1) ?? 0;
    dis[i] = nm === 0 ? 0 : nm >= mlim ? 2 : 1;
  }
  const ha: number[] = [];
  const rindex: number[] = [];
  for (let i = dstart; i <= dend; i++) {
    if (dis[i] === 1 || (dis[i] === 2 && !cleanMatch(dis, i, dstart, dend))) {
      rindex.push(i);
      ha.push(side.ha[i] ?? -1);
    } else {
      setChanged(side, i, true);
    }
  }
  return { ha: Int32Array.from(ha), rindex: Int32Array.from(rindex) };
}

interface Split {
  i1: number;
  i2: number;
  minLo: boolean;
  minHi: boolean;
}

/** The middle snake search of `xdl_split`, with xdiff's cost limits. */
function split(
  ha1: Int32Array,
  off1: number,
  lim1: number,
  ha2: Int32Array,
  off2: number,
  lim2: number,
  kvd: Int32Array,
  fbase: number,
  bbase: number,
  needMin: boolean,
  mxcost: number,
): Split {
  const dmin = off1 - lim2;
  const dmax = lim1 - off2;
  const fmid = off1 - off2;
  const bmid = lim1 - lim2;
  const odd = ((fmid - bmid) & 1) !== 0;
  let fmin = fmid;
  let fmax = fmid;
  let bmin = bmid;
  let bmax = bmid;
  const kf = (d: number): number => kvd[fbase + d] ?? 0;
  const kb = (d: number): number => kvd[bbase + d] ?? 0;
  kvd[fbase + fmid] = off1;
  kvd[bbase + bmid] = lim1;

  for (let ec = 1; ; ec++) {
    let gotSnake = false;

    if (fmin > dmin) kvd[fbase + --fmin - 1] = -1;
    else ++fmin;
    if (fmax < dmax) kvd[fbase + ++fmax + 1] = -1;
    else --fmax;

    for (let d = fmax; d >= fmin; d -= 2) {
      let i1 = kf(d - 1) >= kf(d + 1) ? kf(d - 1) + 1 : kf(d + 1);
      const prev1 = i1;
      let i2 = i1 - d;
      while (i1 < lim1 && i2 < lim2 && ha1[i1] === ha2[i2]) {
        i1++;
        i2++;
      }
      if (i1 - prev1 > SNAKE_CNT) gotSnake = true;
      kvd[fbase + d] = i1;
      if (odd && bmin <= d && d <= bmax && kb(d) <= i1) return { i1, i2, minLo: true, minHi: true };
    }

    if (bmin > dmin) kvd[bbase + --bmin - 1] = LINE_MAX;
    else ++bmin;
    if (bmax < dmax) kvd[bbase + ++bmax + 1] = LINE_MAX;
    else --bmax;

    for (let d = bmax; d >= bmin; d -= 2) {
      let i1 = kb(d - 1) < kb(d + 1) ? kb(d - 1) : kb(d + 1) - 1;
      const prev1 = i1;
      let i2 = i1 - d;
      while (i1 > off1 && i2 > off2 && ha1[i1 - 1] === ha2[i2 - 1]) {
        i1--;
        i2--;
      }
      if (prev1 - i1 > SNAKE_CNT) gotSnake = true;
      kvd[bbase + d] = i1;
      if (!odd && fmin <= d && d <= fmax && i1 <= kf(d)) return { i1, i2, minLo: true, minHi: true };
    }

    if (needMin) continue;

    // Past the heuristic trigger, accept a diagonal that got far enough along a long snake.
    if (gotSnake && ec > HEUR_MIN_COST) {
      let best = 0;
      let found: Split | null = null;
      for (let d = fmax; d >= fmin; d -= 2) {
        const dd = d > fmid ? d - fmid : fmid - d;
        const i1 = kf(d);
        const i2 = i1 - d;
        const v = i1 - off1 + (i2 - off2) - dd;
        if (v > K_HEUR * ec && v > best && off1 + SNAKE_CNT <= i1 && i1 < lim1 && off2 + SNAKE_CNT <= i2 && i2 < lim2) {
          for (let k = 1; ha1[i1 - k] === ha2[i2 - k]; k++) {
            if (k === SNAKE_CNT) {
              best = v;
              found = { i1, i2, minLo: true, minHi: false };
              break;
            }
          }
        }
      }
      if (found) return found;

      best = 0;
      for (let d = bmax; d >= bmin; d -= 2) {
        const dd = d > bmid ? d - bmid : bmid - d;
        const i1 = kb(d);
        const i2 = i1 - d;
        const v = lim1 - i1 + (lim2 - i2) - dd;
        if (v > K_HEUR * ec && v > best && off1 < i1 && i1 <= lim1 - SNAKE_CNT && off2 < i2 && i2 <= lim2 - SNAKE_CNT) {
          for (let k = 0; ha1[i1 + k] === ha2[i2 + k]; k++) {
            if (k === SNAKE_CNT - 1) {
              best = v;
              found = { i1, i2, minLo: false, minHi: true };
              break;
            }
          }
        }
      }
      if (found) return found;
    }

    // Enough is enough: take the furthest-reaching path found so far.
    if (ec >= mxcost) {
      let fbest = -1;
      let fbest1 = -1;
      for (let d = fmax; d >= fmin; d -= 2) {
        let i1 = Math.min(kf(d), lim1);
        let i2 = i1 - d;
        if (lim2 < i2) {
          i1 = lim2 + d;
          i2 = lim2;
        }
        if (fbest < i1 + i2) {
          fbest = i1 + i2;
          fbest1 = i1;
        }
      }
      let bbest = LINE_MAX;
      let bbest1 = LINE_MAX;
      for (let d = bmax; d >= bmin; d -= 2) {
        let i1 = Math.max(off1, kb(d));
        let i2 = i1 - d;
        if (i2 < off2) {
          i1 = off2 + d;
          i2 = off2;
        }
        if (i1 + i2 < bbest) {
          bbest = i1 + i2;
          bbest1 = i1;
        }
      }
      if (lim1 + lim2 - bbest < fbest - (off1 + off2)) return { i1: fbest1, i2: fbest - fbest1, minLo: true, minHi: false };
      return { i1: bbest1, i2: bbest - bbest1, minLo: false, minHi: true };
    }
  }
}

/**
 * Marks the changed lines of both sides with xdiff's Myers diff (`xdl_do_diff` without a special
 * algorithm): common ends are trimmed, lines without a match are set aside, and the rest is compared.
 */
export function myersDiff(side1: DiffSide, side2: DiffSide): void {
  const n1 = side1.ha.length;
  const n2 = side2.ha.length;
  const lim = Math.min(n1, n2);
  let start = 0;
  while (start < lim && side1.ha[start] === side2.ha[start]) start++;
  let tail = 0;
  while (tail < lim - start && side1.ha[n1 - 1 - tail] === side2.ha[n2 - 1 - tail]) tail++;

  const e1 = cleanupRecords(side1, countClasses(side2.ha), start, n1 - tail - 1);
  const e2 = cleanupRecords(side2, countClasses(side1.ha), start, n2 - tail - 1);

  const ndiags = e1.ha.length + e2.ha.length + 3;
  const kvd = new Int32Array(2 * ndiags + 2);
  const fbase = e2.ha.length + 1;
  const bbase = ndiags + e2.ha.length + 1;
  const mxcost = Math.max(bogosqrt(ndiags), MAX_COST_MIN);

  // xdl_recs_cmp, with an explicit stack: the boxes are independent of each other.
  const stack: [number, number, number, number, boolean][] = [[0, e1.ha.length, 0, e2.ha.length, false]];
  for (let box = stack.pop(); box; box = stack.pop()) {
    let [off1, lim1, off2, lim2] = box;
    const needMin = box[4];
    while (off1 < lim1 && off2 < lim2 && e1.ha[off1] === e2.ha[off2]) {
      off1++;
      off2++;
    }
    while (off1 < lim1 && off2 < lim2 && e1.ha[lim1 - 1] === e2.ha[lim2 - 1]) {
      lim1--;
      lim2--;
    }
    if (off1 === lim1) {
      for (; off2 < lim2; off2++) setChanged(side2, e2.rindex[off2] ?? 0, true);
    } else if (off2 === lim2) {
      for (; off1 < lim1; off1++) setChanged(side1, e1.rindex[off1] ?? 0, true);
    } else {
      const spl = split(e1.ha, off1, lim1, e2.ha, off2, lim2, kvd, fbase, bbase, needMin, mxcost);
      stack.push([spl.i1, lim1, spl.i2, lim2, spl.minHi]);
      stack.push([off1, spl.i1, off2, spl.i2, spl.minLo]);
    }
  }
}
