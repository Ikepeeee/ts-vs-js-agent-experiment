// A port of xdiff's `xdl_change_compact`: slides groups of changed lines to where the real git puts
// them, using the indent heuristic when asked to.
import { isChanged, setChanged, type DiffSide } from "./records.ts";

const MAX_INDENT = 200;
const MAX_BLANKS = 20;
const INDENT_HEURISTIC_MAX_SLIDING = 100;

const START_OF_FILE_PENALTY = 1;
const END_OF_FILE_PENALTY = 21;
const TOTAL_BLANK_WEIGHT = -30;
const POST_BLANK_WEIGHT = 6;
const RELATIVE_INDENT_PENALTY = -4;
const RELATIVE_INDENT_WITH_BLANK_PENALTY = 10;
const RELATIVE_OUTDENT_PENALTY = 24;
const RELATIVE_OUTDENT_WITH_BLANK_PENALTY = 17;
const RELATIVE_DEDENT_PENALTY = 23;
const RELATIVE_DEDENT_WITH_BLANK_PENALTY = 17;
const INDENT_WEIGHT = 60;

/** A run of changed lines: `start` is the first, `end` is one past the last. */
interface Group {
  start: number;
  end: number;
}

function groupInit(side: DiffSide): Group {
  const g = { start: 0, end: 0 };
  while (isChanged(side, g.end)) g.end++;
  return g;
}

function groupNext(side: DiffSide, g: Group): boolean {
  if (g.end === side.recs.length) return false;
  g.start = g.end + 1;
  for (g.end = g.start; isChanged(side, g.end); g.end++);
  return true;
}

function groupPrevious(side: DiffSide, g: Group): boolean {
  if (g.start === 0) return false;
  g.end = g.start - 1;
  for (g.start = g.end; isChanged(side, g.start - 1); g.start--);
  return true;
}

function groupSlideDown(side: DiffSide, g: Group): boolean {
  if (g.end < side.recs.length && side.ha[g.start] === side.ha[g.end]) {
    setChanged(side, g.start++, false);
    setChanged(side, g.end++, true);
    while (isChanged(side, g.end)) g.end++;
    return true;
  }
  return false;
}

function groupSlideUp(side: DiffSide, g: Group): boolean {
  if (g.start > 0 && side.ha[g.start - 1] === side.ha[g.end - 1]) {
    setChanged(side, --g.start, true);
    setChanged(side, --g.end, false);
    while (isChanged(side, g.start - 1)) g.start--;
    return true;
  }
  return false;
}

/** The indentation width of a line (tabs to multiples of 8), or -1 for a line of only whitespace. */
function getIndent(rec: Buffer): number {
  let ret = 0;
  for (const c of rec) {
    // isspace: space, \t, \n, \v, \f, \r
    if (c !== 32 && (c < 9 || c > 13)) return ret;
    if (c === 32) ret += 1;
    else if (c === 9) ret += 8 - (ret % 8);
    if (ret >= MAX_INDENT) return MAX_INDENT;
  }
  return -1;
}

interface SplitMeasurement {
  endOfFile: boolean;
  indent: number;
  preBlank: number;
  preIndent: number;
  postBlank: number;
  postIndent: number;
}

function measureSplit(side: DiffSide, split: number): SplitMeasurement {
  const nrec = side.recs.length;
  const indentAt = (i: number): number => getIndent(side.recs[i] ?? Buffer.alloc(0));
  const m: SplitMeasurement = { endOfFile: false, indent: -1, preBlank: 0, preIndent: -1, postBlank: 0, postIndent: -1 };
  if (split >= nrec) m.endOfFile = true;
  else m.indent = indentAt(split);

  for (let i = split - 1; i >= 0; i--) {
    m.preIndent = indentAt(i);
    if (m.preIndent !== -1) break;
    m.preBlank += 1;
    if (m.preBlank === MAX_BLANKS) {
      m.preIndent = 0;
      break;
    }
  }
  for (let i = split + 1; i < nrec; i++) {
    m.postIndent = indentAt(i);
    if (m.postIndent !== -1) break;
    m.postBlank += 1;
    if (m.postBlank === MAX_BLANKS) {
      m.postIndent = 0;
      break;
    }
  }
  return m;
}

interface SplitScore {
  effectiveIndent: number;
  penalty: number;
}

function scoreAddSplit(m: SplitMeasurement, s: SplitScore): void {
  if (m.preIndent === -1 && m.preBlank === 0) s.penalty += START_OF_FILE_PENALTY;
  if (m.endOfFile) s.penalty += END_OF_FILE_PENALTY;

  const postBlank = m.indent === -1 ? 1 + m.postBlank : 0;
  const totalBlank = m.preBlank + postBlank;
  s.penalty += TOTAL_BLANK_WEIGHT * totalBlank;
  s.penalty += POST_BLANK_WEIGHT * postBlank;

  const indent = m.indent !== -1 ? m.indent : m.postIndent;
  const anyBlanks = totalBlank !== 0;
  s.effectiveIndent += indent;

  if (indent === -1 || m.preIndent === -1) {
    // No additional adjustments needed.
  } else if (indent > m.preIndent) {
    s.penalty += anyBlanks ? RELATIVE_INDENT_WITH_BLANK_PENALTY : RELATIVE_INDENT_PENALTY;
  } else if (indent === m.preIndent) {
    // No additional adjustments needed.
  } else if (m.postIndent !== -1 && m.postIndent > indent) {
    s.penalty += anyBlanks ? RELATIVE_OUTDENT_WITH_BLANK_PENALTY : RELATIVE_OUTDENT_PENALTY;
  } else {
    s.penalty += anyBlanks ? RELATIVE_DEDENT_WITH_BLANK_PENALTY : RELATIVE_DEDENT_PENALTY;
  }
}

function scoreCmp(s1: SplitScore, s2: SplitScore): number {
  const cmpIndents = Number(s1.effectiveIndent > s2.effectiveIndent) - Number(s1.effectiveIndent < s2.effectiveIndent);
  return INDENT_WEIGHT * cmpIndents + (s1.penalty - s2.penalty);
}

function bug(what: string): never {
  throw new Error(`xdiff compaction: ${what}`);
}

/**
 * Moves each group of changed lines in `side` as far up and down as equal lines allow, merging
 * groups that meet, then settles it: aligned with a change in `other` if possible, otherwise where
 * the indent heuristic scores best (if enabled), otherwise as low as possible.
 */
export function changeCompact(side: DiffSide, other: DiffSide, indentHeuristic: boolean): void {
  const g = groupInit(side);
  const go = groupInit(other);

  for (;;) {
    if (g.end !== g.start) {
      let groupsize: number;
      let earliestEnd: number;
      let endMatchingOther: number;
      do {
        groupsize = g.end - g.start;
        endMatchingOther = -1;

        while (groupSlideUp(side, g)) if (!groupPrevious(other, go)) bug("group sync broken sliding up");
        earliestEnd = g.end;
        if (go.end > go.start) endMatchingOther = g.end;

        for (;;) {
          if (!groupSlideDown(side, g)) break;
          if (!groupNext(other, go)) bug("group sync broken sliding down");
          if (go.end > go.start) endMatchingOther = g.end;
        }
      } while (groupsize !== g.end - g.start);

      if (g.end === earliestEnd) {
        // No shifting was possible.
      } else if (endMatchingOther !== -1) {
        while (go.end === go.start) {
          if (!groupSlideUp(side, g)) bug("match disappeared");
          if (!groupPrevious(other, go)) bug("group sync broken sliding to match");
        }
      } else if (indentHeuristic) {
        let shift = earliestEnd;
        if (g.end - groupsize - 1 > shift) shift = g.end - groupsize - 1;
        if (g.end - INDENT_HEURISTIC_MAX_SLIDING > shift) shift = g.end - INDENT_HEURISTIC_MAX_SLIDING;
        let bestShift = -1;
        let bestScore: SplitScore = { effectiveIndent: 0, penalty: 0 };
        for (; shift <= g.end; shift++) {
          const score: SplitScore = { effectiveIndent: 0, penalty: 0 };
          scoreAddSplit(measureSplit(side, shift), score);
          scoreAddSplit(measureSplit(side, shift - groupsize), score);
          if (bestShift === -1 || scoreCmp(score, bestScore) <= 0) {
            bestScore = score;
            bestShift = shift;
          }
        }
        while (g.end > bestShift) {
          if (!groupSlideUp(side, g)) bug("best shift unreached");
          if (!groupPrevious(other, go)) bug("group sync broken sliding to blank line");
        }
      }
    }
    if (!groupNext(side, g)) break;
    if (!groupNext(other, go)) bug("group sync broken moving to next group");
  }
}
