// A port of xdiff's histogram diff (`xhistogram.c`), the algorithm the real git's merges use.
import { myersDiff } from "./myers.ts";
import { makeSide, setChanged, type DiffSide } from "./records.ts";

const MAX_CHAIN_LENGTH = 64;

interface Region {
  begin1: number;
  end1: number;
  begin2: number;
  end2: number;
}

/** Occurrences of one line in the first file's range: how many, and the first one (1-based). */
interface Occurrences {
  ptr: number;
  cnt: number;
}

/**
 * Finds the longest run of common lines built around the lines that occur least often (`find_lcs`).
 * Returns null when every common line occurs too often, in which case the caller falls back to Myers.
 */
function findLcs(side1: DiffSide, side2: DiffSide, line1: number, count1: number, line2: number, count2: number): Region | null {
  const ha1 = (line: number): number => side1.ha[line - 1] ?? -1;
  const ha2 = (line: number): number => side2.ha[line - 1] ?? -1;
  const end1 = line1 + count1 - 1;
  const end2 = line2 + count2 - 1;

  // scanA: chains of equal lines, from the last line up, so that each chain starts at its first line.
  const records = new Map<number, Occurrences>();
  const lineMap: Occurrences[] = [];
  const nextPtrs = new Int32Array(count1);
  for (let ptr = end1; ptr >= line1; ptr--) {
    const cls = ha1(ptr);
    let rec = records.get(cls);
    if (rec) {
      nextPtrs[ptr - line1] = rec.ptr;
      rec.ptr = ptr;
      rec.cnt++;
    } else {
      rec = { ptr, cnt: 1 };
      records.set(cls, rec);
    }
    lineMap[ptr - line1] = rec;
  }
  const nextPtr = (ptr: number): number => nextPtrs[ptr - line1] ?? 0;
  const cntAt = (ptr: number): number => lineMap[ptr - line1]?.cnt ?? 0;

  const lcs: Region = { begin1: 0, end1: 0, begin2: 0, end2: 0 };
  let cnt = MAX_CHAIN_LENGTH + 1;
  let hasCommon = false;

  // try_lcs for each line of the second range.
  for (let bPtr = line2; bPtr <= end2; ) {
    let bNext = bPtr + 1;
    const rec = records.get(ha2(bPtr));
    if (rec) {
      if (rec.cnt > cnt) {
        hasCommon = true;
      } else {
        hasCommon = true;
        let as = rec.ptr;
        for (;;) {
          let np = nextPtr(as);
          let bs = bPtr;
          let ae = as;
          let be = bs;
          let rc = rec.cnt;
          while (line1 < as && line2 < bs && ha1(as - 1) === ha2(bs - 1)) {
            as--;
            bs--;
            if (1 < rc) rc = Math.min(rc, cntAt(as));
          }
          while (ae < end1 && be < end2 && ha1(ae + 1) === ha2(be + 1)) {
            ae++;
            be++;
            if (1 < rc) rc = Math.min(rc, cntAt(ae));
          }
          if (bNext <= be) bNext = be + 1;
          if (lcs.end1 - lcs.begin1 < ae - as || rc < cnt) {
            lcs.begin1 = as;
            lcs.begin2 = bs;
            lcs.end1 = ae;
            lcs.end2 = be;
            cnt = rc;
          }
          if (np === 0) break;
          while (np <= ae) {
            np = nextPtr(np);
            if (np === 0) break;
          }
          if (np === 0) break;
          as = np;
        }
      }
    }
    bPtr = bNext;
  }
  return hasCommon && MAX_CHAIN_LENGTH < cnt ? null : lcs;
}

/** Diffs a range with Myers, as if the ranges were whole files (`xdl_fall_back_diff`). */
function fallBack(side1: DiffSide, side2: DiffSide, line1: number, count1: number, line2: number, count2: number): void {
  const sub1 = makeSide(side1.recs.slice(line1 - 1, line1 - 1 + count1), side1.ha.slice(line1 - 1, line1 - 1 + count1));
  const sub2 = makeSide(side2.recs.slice(line2 - 1, line2 - 1 + count2), side2.ha.slice(line2 - 1, line2 - 1 + count2));
  myersDiff(sub1, sub2);
  side1.rchg.set(sub1.rchg.subarray(1, count1 + 1), line1);
  side2.rchg.set(sub2.rchg.subarray(1, count2 + 1), line2);
}

/** Marks the changed lines of both sides with xdiff's histogram diff. */
export function histogramDiff(side1: DiffSide, side2: DiffSide): void {
  const stack: [number, number, number, number][] = [[1, side1.ha.length, 1, side2.ha.length]];
  for (let range = stack.pop(); range; range = stack.pop()) {
    const [line1, count1, line2, count2] = range;
    if (count1 <= 0 && count2 <= 0) continue;
    if (count1 === 0) {
      for (let i = 0; i < count2; i++) setChanged(side2, line2 - 1 + i, true);
      continue;
    }
    if (count2 === 0) {
      for (let i = 0; i < count1; i++) setChanged(side1, line1 - 1 + i, true);
      continue;
    }
    const lcs = findLcs(side1, side2, line1, count1, line2, count2);
    if (!lcs) {
      fallBack(side1, side2, line1, count1, line2, count2);
    } else if (lcs.begin1 === 0 && lcs.begin2 === 0) {
      for (let i = 0; i < count1; i++) setChanged(side1, line1 - 1 + i, true);
      for (let i = 0; i < count2; i++) setChanged(side2, line2 - 1 + i, true);
    } else {
      stack.push([lcs.end1 + 1, line1 + count1 - 1 - lcs.end1, lcs.end2 + 1, line2 + count2 - 1 - lcs.end2]);
      stack.push([line1, lcs.begin1 - line1, line2, lcs.begin2 - line2]);
    }
  }
}
