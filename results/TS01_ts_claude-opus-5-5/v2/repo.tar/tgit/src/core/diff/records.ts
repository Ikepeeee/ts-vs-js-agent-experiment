/**
 * One side of a line diff, laid out like xdiff's `xdfile_t`: the lines ("records", each including its
 * newline), a class number per line (equal lines share a class), and the "changed" flags the algorithms set.
 */
export interface DiffSide {
  recs: Buffer[];
  ha: Int32Array;
  /** Changed flags, shifted by one so that index -1 and nrec can be read as unchanged sentinels. */
  rchg: Uint8Array;
}

/** Splits content into lines that keep their trailing newline; a last line without one is kept too. */
export function splitRecords(data: Buffer): Buffer[] {
  const recs: Buffer[] = [];
  let start = 0;
  while (start < data.length) {
    const nl = data.indexOf(10, start);
    const end = nl < 0 ? data.length : nl + 1;
    recs.push(data.subarray(start, end));
    start = end;
  }
  return recs;
}

/** Numbers distinct lines across the files given to it, so that algorithms can compare integers. */
export class Classifier {
  private readonly classes = new Map<string, number>();

  classify(recs: Buffer[]): Int32Array {
    const ha = new Int32Array(recs.length);
    recs.forEach((rec, i) => {
      const key = rec.toString("latin1");
      let cls = this.classes.get(key);
      if (cls === undefined) {
        cls = this.classes.size;
        this.classes.set(key, cls);
      }
      ha[i] = cls;
    });
    return ha;
  }
}

export function makeSide(recs: Buffer[], ha: Int32Array): DiffSide {
  return { recs, ha, rchg: new Uint8Array(recs.length + 2) };
}

export function isChanged(side: DiffSide, i: number): boolean {
  return side.rchg[i + 1] === 1;
}

export function setChanged(side: DiffSide, i: number, changed: boolean): void {
  side.rchg[i + 1] = changed ? 1 : 0;
}
