// Line diffs computed the way the real git's xdiff library does (`xdl_do_diff`, `xdl_change_compact`,
// `xdl_build_script`).
import { changeCompact } from "./compact.ts";
import { histogramDiff } from "./histogram.ts";
import { myersDiff } from "./myers.ts";
import { Classifier, isChanged, makeSide, splitRecords, type DiffSide } from "./records.ts";

export interface DiffAlgorithmOptions {
  /** Myers is the default of `git diff`; merges always use histogram. */
  algorithm: "myers" | "histogram";
  indentHeuristic: boolean;
}

/** The default of `git diff` and `git show`. */
export const DIFF_DEFAULTS: DiffAlgorithmOptions = { algorithm: "myers", indentHeuristic: true };

/** What merges (merge-ort) use. */
export const MERGE_DEFAULTS: DiffAlgorithmOptions = { algorithm: "histogram", indentHeuristic: false };

/** A change: `chg1` lines at `i1` in the old file are replaced by `chg2` lines at `i2` in the new file. */
export interface Change {
  i1: number;
  i2: number;
  chg1: number;
  chg2: number;
}

export interface LineDiff {
  /** The lines of the old and the new file, each with its newline if it has one. */
  lines1: Buffer[];
  lines2: Buffer[];
  /** The changes in order. */
  changes: Change[];
}

/** Collects the runs of changed lines into an edit script (`xdl_build_script`). */
function buildScript(side1: DiffSide, side2: DiffSide): Change[] {
  const changes: Change[] = [];
  let i1 = side1.recs.length;
  let i2 = side2.recs.length;
  for (; i1 >= 0 || i2 >= 0; i1--, i2--) {
    if (isChanged(side1, i1 - 1) || isChanged(side2, i2 - 1)) {
      const l1 = i1;
      const l2 = i2;
      while (isChanged(side1, i1 - 1)) i1--;
      while (isChanged(side2, i2 - 1)) i2--;
      changes.push({ i1, i2, chg1: l1 - i1, chg2: l2 - i2 });
    }
  }
  return changes.reverse();
}

/** Diffs two lists of lines. */
export function diffRecords(recs1: Buffer[], recs2: Buffer[], options: DiffAlgorithmOptions): LineDiff {
  const classifier = new Classifier();
  const side1 = makeSide(recs1, classifier.classify(recs1));
  const side2 = makeSide(recs2, classifier.classify(recs2));
  if (options.algorithm === "histogram") histogramDiff(side1, side2);
  else myersDiff(side1, side2);
  changeCompact(side1, side2, options.indentHeuristic);
  changeCompact(side2, side1, options.indentHeuristic);
  return { lines1: recs1, lines2: recs2, changes: buildScript(side1, side2) };
}

/** Diffs the lines of two files. */
export function diffLines(a: Buffer, b: Buffer, options: DiffAlgorithmOptions): LineDiff {
  return diffRecords(splitRecords(a), splitRecords(b), options);
}

/** Whether the real git treats content as binary: it has a NUL byte within the first 8000 bytes. */
export function isBinary(data: Buffer): boolean {
  return data.subarray(0, 8000).includes(0);
}
