import { readObject } from "../objects/store.ts";
import type { FileEntry } from "../objects/tree.ts";
import { comparePaths } from "../paths.ts";
import { diffFiles } from "../status/changes.ts";
import type { DiffBlob, FilePair } from "./patch.ts";

/** The content of a blob; a missing object is an error. */
export function readBlob(gitDir: string, oid: string): Buffer {
  const object = readObject(gitDir, oid);
  if (!object || object.type !== "blob") throw new Error(`missing blob ${oid}`);
  return object.data;
}

/** A file of a tree or the index, with its content. */
export function blobSide(gitDir: string, file: FileEntry): DiffBlob {
  return { mode: file.mode, oid: file.oid, data: readBlob(gitDir, file.oid) };
}

/** The pairs of files that differ between two sets of files, in path order. */
export function filePairs(gitDir: string, from: Map<string, FileEntry>, to: Map<string, FileEntry>): FilePair[] {
  return [...diffFiles(from, to).keys()].sort(comparePaths).map((filePath) => {
    const old = from.get(filePath);
    const next = to.get(filePath);
    return { path: filePath, old: old ? blobSide(gitDir, old) : null, new: next ? blobSide(gitDir, next) : null };
  });
}
