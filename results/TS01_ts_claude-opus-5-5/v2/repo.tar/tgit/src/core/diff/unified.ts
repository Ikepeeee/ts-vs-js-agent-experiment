// The hunks of a unified diff, emitted like xdiff's `xdl_emit_diff` with the real git's defaults:
// 3 lines of context, no inter-hunk context, and function names after the hunk header.
import type { Change, LineDiff } from "./xdiff.ts";

const CONTEXT = 3;
const FUNC_LINE_SIZE = 80;
const HUNK_HEADER_SIZE = 128;
const NO_NEWLINE = Buffer.from("\n\\ No newline at end of file\n");

function isSpace(c: number): boolean {
  return c === 32 || (c >= 9 && c <= 13);
}

function isAlpha(c: number): boolean {
  return (c >= 65 && c <= 90) || (c >= 97 && c <= 122);
}

/**
 * The default function name rule (`def_ff`): a line starting with a letter, `_`, or `$`, cut to
 * 80 bytes, without trailing whitespace. Returns null for other lines.
 */
function funcName(rec: Buffer): Buffer | null {
  const c = rec[0];
  if (c === undefined || !(isAlpha(c) || c === 95 || c === 36)) return null;
  let len = Math.min(rec.length, FUNC_LINE_SIZE);
  while (len > 0 && isSpace(rec[len - 1] ?? 0)) len--;
  return rec.subarray(0, len);
}

/** Groups changes into hunks: changes at most twice the context apart share a hunk. */
function hunkGroups(changes: Change[]): Change[][] {
  const groups: Change[][] = [];
  for (const change of changes) {
    const group = groups.at(-1);
    const last = group?.at(-1);
    if (group && last && change.i1 - (last.i1 + last.chg1) <= 2 * CONTEXT) group.push(change);
    else groups.push([change]);
  }
  return groups;
}

function range(start: number, count: number): string {
  const first = count === 0 ? start - 1 : start;
  return count === 1 ? `${first}` : `${first},${count}`;
}

/** Writes a line with its prefix, marking a missing newline at the end of the file like the real git. */
export function pushRecord(out: Buffer[], prefix: string, rec: Buffer): void {
  out.push(Buffer.from(prefix), rec);
  if (rec.length > 0 && rec[rec.length - 1] !== 10) out.push(NO_NEWLINE);
}

/** The hunks of a line diff (everything after the `+++` line). */
export function formatHunks(diff: LineDiff): Buffer {
  const { lines1, lines2 } = diff;
  const out: Buffer[] = [];
  let funcLine: Buffer = Buffer.alloc(0);
  let funcLinePrev = -1;

  for (const group of hunkGroups(diff.changes)) {
    const first = group[0];
    const last = group.at(-1);
    if (!first || !last) continue;
    const s1 = Math.max(first.i1 - CONTEXT, 0);
    let s2 = Math.max(first.i2 - CONTEXT, 0);
    const lctx = Math.min(CONTEXT, lines1.length - (last.i1 + last.chg1), lines2.length - (last.i2 + last.chg2));
    const e1 = last.i1 + last.chg1 + lctx;
    const e2 = last.i2 + last.chg2 + lctx;

    // Search upwards from the line before the hunk, down to where the previous search started.
    for (let l = s1 - 1; l !== funcLinePrev && l >= 0; l--) {
      const name = funcName(lines1[l] ?? Buffer.alloc(0));
      if (name) {
        funcLine = name;
        break;
      }
    }
    funcLinePrev = s1 - 1;

    let header = `@@ -${range(s1 + 1, e1 - s1)} +${range(s2 + 1, e2 - s2)} @@`;
    let headerBytes = Buffer.from(header);
    if (funcLine.length > 0) {
      const room = HUNK_HEADER_SIZE - headerBytes.length - 2;
      header += " ";
      headerBytes = Buffer.concat([Buffer.from(header), funcLine.subarray(0, room)]);
    }
    out.push(headerBytes, Buffer.from("\n"));

    for (; s2 < first.i2; s2++) pushRecord(out, " ", lines2[s2] ?? Buffer.alloc(0));
    let prev: Change | null = null;
    for (const change of group) {
      if (prev) {
        for (let i = prev.i2 + prev.chg2; i < change.i2; i++) pushRecord(out, " ", lines2[i] ?? Buffer.alloc(0));
      }
      for (let i = change.i1; i < change.i1 + change.chg1; i++) pushRecord(out, "-", lines1[i] ?? Buffer.alloc(0));
      for (let i = change.i2; i < change.i2 + change.chg2; i++) pushRecord(out, "+", lines2[i] ?? Buffer.alloc(0));
      prev = change;
    }
    for (let i = last.i2 + last.chg2; i < e2; i++) pushRecord(out, " ", lines2[i] ?? Buffer.alloc(0));
  }
  return Buffer.concat(out);
}
