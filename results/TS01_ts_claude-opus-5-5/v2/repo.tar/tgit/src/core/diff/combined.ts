// The dense combined diff (`--cc`) of the real git's combine-diff.c, used for merge commits and for
// unmerged paths in the working tree: the result is compared with each parent at once.
import { quotePath } from "../../cli/quote.ts";
import { DIFF_DEFAULTS, diffLines, isBinary } from "./xdiff.ts";

const CONTEXT = 3;
const FUNC_NAME_WIDTH = 40;
const TRIM_BLOCK = 1024;
const NULL_ABBREV = "0000000";

export interface CombinedParent {
  /** The mode as a number, 0 if the parent does not have the path. */
  mode: number;
  oid: string;
  data: Buffer;
  /** Whether the parent lacks the path (the merge added it as far as this parent is concerned). */
  added: boolean;
}

export interface CombinedPath {
  path: string;
  /** The mode of the result, 0 if the result does not have the path. */
  mode: number;
  /** The result's object ID, or null when it is a working tree file (shown as 0000000). */
  oid: string | null;
  data: Buffer;
  parents: CombinedParent[];
}

/** A line some parents had where the result does not. */
interface LostLine {
  text: Buffer;
  parentMap: number;
}

/** A line of the result ("surviving line"), plus a virtual line after the last one. */
interface SLine {
  text: Buffer | null;
  /** Bit n: the line was added relative to parent n. Higher bits mark lines to show. */
  flag: number;
  lost: LostLine[];
  /** Lines removed from the parent being processed, before they are coalesced into `lost`. */
  plost: LostLine[];
  /** For each parent, its line number where a hunk starting at this line would start. */
  pLno: number[];
}

/**
 * Drops the common tail of two files in blocks of 1024 bytes, keeping whole lines, as the real git
 * does before a diff without context (`trim_common_tail`).
 */
function trimCommonTail(a: Buffer, b: Buffer): [Buffer, Buffer] {
  const smaller = Math.min(a.length, b.length);
  let trimmed = 0;
  while (TRIM_BLOCK + trimmed <= smaller) {
    const blockA = a.subarray(a.length - trimmed - TRIM_BLOCK, a.length - trimmed);
    const blockB = b.subarray(b.length - trimmed - TRIM_BLOCK, b.length - trimmed);
    if (!blockA.equals(blockB)) break;
    trimmed += TRIM_BLOCK;
  }
  const start = a.length - trimmed;
  let recovered = 0;
  while (recovered < trimmed) {
    if (a[start + recovered++] === 10) break;
  }
  const cut = trimmed - recovered;
  return [a.subarray(0, a.length - cut), b.subarray(0, b.length - cut)];
}

/**
 * Merges the lines lost from a new parent into the lines lost from earlier parents, matching
 * equal lines along a longest common subsequence (`coalesce_lines`).
 */
function coalesceLines(base: LostLine[], added: LostLine[], parent: number): LostLine[] {
  if (added.length === 0) return base;
  if (base.length === 0) return added;
  const MATCH = 1;
  const NEW = 2;
  const BASE = 3;
  const width = added.length + 1;
  const lcs = new Int32Array((base.length + 1) * width);
  const directions = new Uint8Array((base.length + 1) * width);
  for (let i = 0; i <= base.length; i++) directions[i * width] = BASE;
  for (let j = 1; j <= added.length; j++) directions[j] = NEW;
  for (let i = 1; i <= base.length; i++) {
    for (let j = 1; j <= added.length; j++) {
      const at = i * width + j;
      const left = lcs[at - 1] ?? 0;
      const up = lcs[at - width] ?? 0;
      if (base[i - 1]?.text.equals(added[j - 1]?.text ?? Buffer.alloc(0))) {
        lcs[at] = (lcs[at - width - 1] ?? 0) + 1;
        directions[at] = MATCH;
      } else if (left >= up) {
        lcs[at] = left;
        directions[at] = NEW;
      } else {
        lcs[at] = up;
        directions[at] = BASE;
      }
    }
  }
  // Walk back from the end, collecting the merged list in reverse.
  const merged: LostLine[] = [];
  let i = base.length;
  let j = added.length;
  while (i !== 0 || j !== 0) {
    const direction = directions[i * width + j];
    if (direction === MATCH) {
      const line = base[--i] as LostLine;
      line.parentMap |= 1 << parent;
      merged.push(line);
      j--;
    } else if (direction === NEW) {
      merged.push(added[--j] as LostLine);
    } else {
      merged.push(base[--i] as LostLine);
    }
  }
  return merged.reverse();
}

/** Records the differences between one parent and the result (`combine_diff`). */
function combineWithParent(slines: SLine[], cnt: number, result: Buffer, parent: Buffer, n: number): void {
  const nmask = 1 << n;
  const [a, b] = trimCommonTail(parent, result);
  const diff = diffLines(a, b, DIFF_DEFAULTS);
  for (const change of diff.changes) {
    // Removed lines hang on the line after them in the result; for a change that also adds
    // lines, on its first added line.
    const nb = change.chg2 > 0 ? change.i2 + 1 : change.i2;
    const bucket = slines[change.chg2 === 0 ? nb : nb - 1] as SLine;
    for (let k = 0; k < change.chg1; k++) {
      let text = diff.lines1[change.i1 + k] ?? Buffer.alloc(0);
      if (text.at(-1) === 10) text = text.subarray(0, -1);
      bucket.plost.push({ text, parentMap: nmask });
    }
    for (let k = 0; k < change.chg2; k++) (slines[nb - 1 + k] as SLine).flag |= nmask;
  }

  let pLno = 1;
  for (let lno = 0; lno <= cnt; lno++) {
    const sl = slines[lno] as SLine;
    sl.pLno[n] = pLno;
    if (sl.plost.length > 0) {
      sl.lost = coalesceLines(sl.lost, sl.plost, n);
      sl.plost = [];
    }
    for (const ll of sl.lost) if (ll.parentMap & nmask) pLno++;
    if (lno < cnt && !(sl.flag & nmask)) pLno++;
  }
  (slines[cnt + 1] as SLine).pLno[n] = pLno;
}

/** Shares the results of an earlier parent with the same content (`reuse_combine_diff`). */
function reuseParent(slines: SLine[], cnt: number, i: number, j: number): void {
  const imask = 1 << i;
  const jmask = 1 << j;
  for (let lno = 0; lno <= cnt + 1; lno++) {
    const sl = slines[lno] as SLine;
    sl.pLno[i] = sl.pLno[j] ?? 0;
    if (lno > cnt) break;
    for (const ll of sl.lost) if (ll.parentMap & jmask) ll.parentMap |= imask;
    if (sl.flag & jmask) sl.flag |= imask;
  }
}

function findNext(slines: SLine[], mark: number, i: number, cnt: number, lookForUninteresting: boolean): number {
  while (i <= cnt) {
    const marked = ((slines[i] as SLine).flag & mark) !== 0;
    if (lookForUninteresting ? !marked : marked) return i;
    i++;
  }
  return i;
}

/** A last line that is interesting only for its deletions does not count for trailing context. */
function adjustHunkTail(slines: SLine[], allMask: number, hunkBegin: number, i: number): number {
  if (hunkBegin + 1 <= i && !((slines[i - 1] as SLine).flag & allMask)) return i - 1;
  return i;
}

/** Marks context lines around interesting ones, joining groups that are close (`give_context`). */
function giveContext(slines: SLine[], cnt: number, numParent: number): boolean {
  const allMask = (1 << numParent) - 1;
  const mark = 1 << numParent;
  const noPreDelete = 2 << numParent;
  let i = findNext(slines, mark, 0, cnt, false);
  if (cnt < i) return false;

  while (i <= cnt) {
    let j = CONTEXT < i ? i - CONTEXT : 0;
    while (j < i) {
      const sl = slines[j++] as SLine;
      if (!(sl.flag & mark)) sl.flag |= noPreDelete;
      sl.flag |= mark;
    }
    for (;;) {
      j = findNext(slines, mark, i, cnt, true);
      if (cnt < j) return true;
      let k = findNext(slines, mark, j, cnt, false);
      j = adjustHunkTail(slines, allMask, i, j);
      if (k < j + CONTEXT) {
        while (j < k) (slines[j++] as SLine).flag |= mark;
        i = k;
        continue;
      }
      i = k;
      k = Math.min(j + CONTEXT, cnt + 1);
      while (j < k) (slines[j++] as SLine).flag |= mark;
      break;
    }
  }
  return true;
}

/**
 * Marks the lines to show: with the dense format, a hunk is dropped when the result matches one of
 * only two versions of it (`make_hunks`). Returns whether anything is shown.
 */
function makeHunks(slines: SLine[], cnt: number, numParent: number): boolean {
  const allMask = (1 << numParent) - 1;
  const mark = 1 << numParent;
  for (let i = 0; i <= cnt; i++) {
    const sl = slines[i] as SLine;
    if (sl.flag & allMask || sl.lost.length > 0) sl.flag |= mark;
    else sl.flag &= ~mark;
  }

  let i = 0;
  while (i <= cnt) {
    while (i <= cnt && !((slines[i] as SLine).flag & mark)) i++;
    if (cnt < i) break;
    const hunkBegin = i;
    let j: number;
    for (j = i + 1; j <= cnt; j++) {
      if ((slines[j] as SLine).flag & mark) continue;
      // Look beyond the end for an interesting line within the context span.
      let la = adjustHunkTail(slines, allMask, hunkBegin, j);
      la = Math.min(la + CONTEXT, cnt + 1);
      let contin = false;
      while (la && j <= --la) {
        if ((slines[la] as SLine).flag & mark) {
          contin = true;
          break;
        }
      }
      if (!contin) break;
      j = la;
    }
    const hunkEnd = j;

    // Interesting only if there are more than two versions, or the result matches no parent.
    let sameDiff = 0;
    let hasInteresting = false;
    for (j = i; j < hunkEnd && !hasInteresting; j++) {
      const sl = slines[j] as SLine;
      const thisDiff = sl.flag & allMask;
      if (thisDiff) {
        if (!sameDiff) sameDiff = thisDiff;
        else if (sameDiff !== thisDiff) {
          hasInteresting = true;
          break;
        }
      }
      for (const ll of sl.lost) {
        if (hasInteresting) break;
        if (!sameDiff) sameDiff = ll.parentMap;
        else if (sameDiff !== ll.parentMap) hasInteresting = true;
      }
    }
    if (!hasInteresting && sameDiff !== allMask) {
      for (j = hunkBegin; j < hunkEnd; j++) (slines[j] as SLine).flag &= ~mark;
    }
    i = hunkEnd;
  }
  return giveContext(slines, cnt, numParent);
}

function isSpace(c: number): boolean {
  return c === 32 || (c >= 9 && c <= 13);
}

function isFuncLine(text: Buffer | null): boolean {
  const c = text?.[0];
  return c !== undefined && ((c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 95 || c === 36);
}

/** A line followed by a newline; a CR at its end stays at the end. */
function pushLine(out: Buffer[], prefix: string, text: Buffer): void {
  out.push(Buffer.from(prefix), text, Buffer.from("\n"));
}

/** Writes the hunks (`dump_sline`). */
function dumpSlines(out: Buffer[], slines: SLine[], cnt: number, numParent: number): void {
  const mark = 1 << numParent;
  const noPreDelete = 2 << numParent;
  let lno = 0;
  for (;;) {
    let funcLine: Buffer | null = null;
    while (lno <= cnt && !((slines[lno] as SLine).flag & mark)) {
      const text = (slines[lno] as SLine).text;
      if (isFuncLine(text)) funcLine = text;
      lno++;
    }
    if (cnt < lno) break;
    let hunkEnd = lno + 1;
    while (hunkEnd <= cnt && (slines[hunkEnd] as SLine).flag & mark) hunkEnd++;
    let rlines = hunkEnd - lno;
    if (cnt < hunkEnd) rlines--;

    const marker = "@".repeat(numParent + 1);
    let header = marker;
    for (let n = 0; n < numParent; n++) {
      const l0 = (slines[lno] as SLine).pLno[n] ?? 0;
      const l1 = (slines[hunkEnd] as SLine).pLno[n] ?? 0;
      header += ` -${l0},${l1 - l0}`;
    }
    header += ` +${lno + 1},${rlines} ${marker}`;
    out.push(Buffer.from(header));
    if (funcLine) {
      // Like the real git: up to 40 bytes, without the last non-space character.
      let commentEnd = 0;
      for (let i = 0; i < FUNC_NAME_WIDTH && i < funcLine.length; i++) {
        const c = funcLine[i] ?? 0;
        if (c === 0 || c === 10) break;
        if (!isSpace(c)) commentEnd = i;
      }
      if (commentEnd) out.push(Buffer.from(" "), funcLine.subarray(0, commentEnd));
    }
    out.push(Buffer.from("\n"));

    while (lno < hunkEnd) {
      const sl = slines[lno++] as SLine;
      if (!(sl.flag & noPreDelete)) {
        for (const ll of sl.lost) {
          let prefix = "";
          for (let n = 0; n < numParent; n++) prefix += ll.parentMap & (1 << n) ? "-" : " ";
          pushLine(out, prefix, ll.text);
        }
      }
      if (cnt < lno) break;
      let prefix = "";
      for (let n = 0; n < numParent; n++) prefix += sl.flag & (1 << n) ? "+" : " ";
      pushLine(out, prefix, sl.text ?? Buffer.alloc(0));
    }
  }
}

function octalMode(mode: number): string {
  return mode.toString(8).padStart(6, "0");
}

/** The header lines (`show_combined_header`); the file header is the `---` and `+++` lines. */
function formatHeader(item: CombinedPath, abbreviate: (oid: string) => string, modeDiffers: boolean, fileHeader: boolean): string {
  const abbrev = (oid: string | null): string => (oid === null || /^0+$/.test(oid) ? NULL_ABBREV : abbreviate(oid));
  let header = `diff --cc ${quotePath(item.path)}\n`;
  header += `index ${item.parents.map((p) => abbrev(p.oid)).join(",")}..${abbrev(item.oid)}\n`;
  const deleted = item.mode === 0;
  const added = !deleted && item.parents.every((p) => p.added);
  if (modeDiffers) {
    if (added) {
      header += `new file mode ${octalMode(item.mode)}\n`;
    } else {
      header += `${deleted ? "deleted file " : ""}mode ${item.parents.map((p) => octalMode(p.mode)).join(",")}`;
      header += deleted ? "\n" : `..${octalMode(item.mode)}\n`;
    }
  }
  if (!fileHeader) return header;
  header += `--- ${added ? "/dev/null" : quotePath(`a/${item.path}`)}\n`;
  header += `+++ ${deleted ? "/dev/null" : quotePath(`b/${item.path}`)}\n`;
  return header;
}

/**
 * The dense combined diff of one path (`show_patch_diff`), or an empty buffer if it has nothing to
 * show. For a working tree file (`workingTree`), the header is always shown, and a missing file
 * (mode 0) shows no hunks.
 */
export function formatCombinedDiff(item: CombinedPath, abbreviate: (oid: string) => string, workingTree: boolean): Buffer {
  const numParent = item.parents.length;
  const modeDiffers = item.parents.some((p) => p.mode !== item.mode);
  if (isBinary(item.data) || item.parents.some((p) => isBinary(p.data))) {
    return Buffer.from(`${formatHeader(item, abbreviate, modeDiffers, false)}Binary files differ\n`);
  }

  const result = item.data;
  const resultDeleted = workingTree && item.mode === 0;
  const texts: Buffer[] = [];
  for (let start = 0; start < result.length; ) {
    const nl = result.indexOf(10, start);
    const end = nl < 0 ? result.length : nl;
    texts.push(result.subarray(start, end));
    start = end + 1;
  }
  const cnt = texts.length;
  const slines: SLine[] = [];
  for (let i = 0; i < cnt + 2; i++) {
    slines.push({ text: texts[i] ?? null, flag: 0, lost: [], plost: [], pLno: new Array<number>(numParent).fill(0) });
  }

  item.parents.forEach((parent, i) => {
    const j = item.parents.findIndex((other) => other.oid === parent.oid);
    if (j < i) reuseParent(slines, cnt, i, j);
    else if (!resultDeleted) combineWithParent(slines, cnt, result, parent.data, i);
  });

  const showHunks = makeHunks(slines, cnt, numParent);
  if (!showHunks && !modeDiffers && !workingTree) return Buffer.alloc(0);
  const out: Buffer[] = [Buffer.from(formatHeader(item, abbreviate, modeDiffers, true))];
  if (!resultDeleted) dumpSlines(out, slines, cnt, numParent);
  return Buffer.concat(out);
}
