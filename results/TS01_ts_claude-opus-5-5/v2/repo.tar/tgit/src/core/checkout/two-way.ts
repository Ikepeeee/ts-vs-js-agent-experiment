import path from "node:path";
import type { Index } from "../index/index-file.ts";
import { readObject } from "../objects/store.ts";
import type { FileEntry } from "../objects/tree.ts";
import { comparePaths } from "../paths.ts";
import type { Repository } from "../repo/repository.ts";
import { treeMode } from "../status/changes.ts";
import { hashWorktreeFile, lstatOrNull, removeWorktreeFile, statData, writeWorktreeFile } from "../worktree/files.ts";
import type { IgnoreRules } from "../worktree/ignore.ts";

/** Why a checkout cannot proceed, grouped like the real git's error messages. */
export interface CheckoutProblems {
  /** Tracked files whose local changes would be lost. */
  localChanges: string[];
  /** Untracked files that the checkout would overwrite. */
  untrackedOverwritten: string[];
  /** Untracked files that the checkout would remove. */
  untrackedRemoved: string[];
}

interface Plan {
  remove: string[];
  write: [string, FileEntry][];
}

function same(a: FileEntry | undefined, b: FileEntry | undefined): boolean {
  return a !== undefined && b !== undefined && a.mode === b.mode && a.oid === b.oid;
}

/**
 * Moves the index and the working tree from the `from` tree to the `to` tree, keeping local
 * changes that do not conflict, with the rules of the real git's two-way merge (`twoway_merge`).
 * If anything would be lost, nothing is changed and the problems are returned.
 */
export function switchTrees(
  repo: Repository,
  index: Index,
  ignore: IgnoreRules,
  from: Map<string, FileEntry>,
  to: Map<string, FileEntry>,
): CheckoutProblems | null {
  const filemode = repo.config.getBool("core.filemode", true);
  const problems: CheckoutProblems = { localChanges: [], untrackedOverwritten: [], untrackedRemoved: [] };
  const plan: Plan = { remove: [], write: [] };

  // The working tree file must match the index (or be missing) before the checkout replaces it.
  const isUpToDate = (filePath: string, staged: FileEntry): boolean => {
    const file = hashWorktreeFile(repo.gitDir, path.join(repo.workTree, filePath), { filemode, write: false });
    return file === null || same({ mode: treeMode(file.mode), oid: file.oid }, staged);
  };
  // An untracked file that is not ignored must not be overwritten or removed.
  const isAbsent = (filePath: string): boolean =>
    lstatOrNull(path.join(repo.workTree, filePath)) === null || ignore.isIgnored(filePath, false);

  const paths = new Set([...index.list().map((e) => e.path), ...from.keys(), ...to.keys()]);
  for (const filePath of [...paths].sort(comparePaths)) {
    const entry = index.get(filePath);
    const staged = entry && { mode: treeMode(entry.mode), oid: entry.oid };
    const old = from.get(filePath);
    const next = to.get(filePath);

    if (!staged) {
      if (next && old) {
        if (!same(old, next)) problems.localChanges.push(filePath);
      } else if (next) {
        if (isAbsent(filePath)) plan.write.push([filePath, next]);
        else problems.untrackedOverwritten.push(filePath);
      } else if (old && !isAbsent(filePath)) {
        problems.untrackedRemoved.push(filePath);
      }
      continue;
    }
    const keep = old ? next !== undefined && (same(old, next) || same(staged, next)) : !next || same(staged, next);
    if (keep) continue;
    if (!old || !same(staged, old) || !isUpToDate(filePath, staged)) {
      problems.localChanges.push(filePath);
    } else if (next) {
      plan.write.push([filePath, next]);
    } else {
      plan.remove.push(filePath);
    }
  }

  if (problems.localChanges.length + problems.untrackedOverwritten.length + problems.untrackedRemoved.length > 0) return problems;
  for (const filePath of plan.remove) {
    index.delete(filePath);
    removeWorktreeFile(repo.workTree, filePath);
  }
  for (const [filePath, file] of plan.write) {
    const blob = readObject(repo.gitDir, file.oid);
    if (!blob) throw new Error(`missing blob ${file.oid}`);
    const absPath = path.join(repo.workTree, filePath);
    const mode = Number.parseInt(file.mode, 8);
    writeWorktreeFile(absPath, mode, blob.data);
    const st = lstatOrNull(absPath);
    if (st) index.set({ path: filePath, oid: file.oid, mode, stat: statData(st) });
  }
  return null;
}
