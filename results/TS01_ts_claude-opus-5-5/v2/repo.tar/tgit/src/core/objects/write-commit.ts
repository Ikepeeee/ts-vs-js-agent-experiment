import { identFor } from "../ident/ident.ts";
import type { Repository } from "../repo/repository.ts";
import { formatIdent, serializeCommit } from "./commit.ts";
import { writeObject } from "./store.ts";

/** Writes a commit by the author and committer configured for the repository and environment. */
export function writeCommit(repo: Repository, env: NodeJS.ProcessEnv, tree: string, parents: string[], message: string): string {
  return writeObject(
    repo.gitDir,
    "commit",
    serializeCommit({
      tree,
      parents,
      author: formatIdent(identFor("AUTHOR", repo, env)),
      committer: formatIdent(identFor("COMMITTER", repo, env)),
      message,
    }),
  );
}
