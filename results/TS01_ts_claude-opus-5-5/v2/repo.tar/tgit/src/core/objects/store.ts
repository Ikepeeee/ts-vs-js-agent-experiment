import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

export type ObjectType = "blob" | "tree" | "commit" | "tag";

export interface GitObject {
  type: ObjectType;
  data: Buffer;
}

const OBJECT_TYPES: readonly string[] = ["blob", "tree", "commit", "tag"];

export function isObjectId(text: string): boolean {
  return /^[0-9a-f]{40}$/.test(text);
}

function encode(type: ObjectType, data: Buffer): Buffer {
  return Buffer.concat([Buffer.from(`${type} ${data.length}\0`), data]);
}

/** The object ID (SHA-1) of an object, without writing it. */
export function hashObject(type: ObjectType, data: Buffer): string {
  return createHash("sha1").update(encode(type, data)).digest("hex");
}

function objectPath(gitDir: string, oid: string): string {
  return path.join(gitDir, "objects", oid.slice(0, 2), oid.slice(2));
}

/** Writes a loose object unless it already exists, and returns its ID. */
export function writeObject(gitDir: string, type: ObjectType, data: Buffer): string {
  const raw = encode(type, data);
  const oid = createHash("sha1").update(raw).digest("hex");
  const file = objectPath(gitDir, oid);
  if (fs.existsSync(file)) return oid;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = path.join(path.dirname(file), `tmp_obj_${process.pid}_${oid.slice(2, 10)}`);
  fs.writeFileSync(temp, zlib.deflateSync(raw), { mode: 0o444 });
  fs.renameSync(temp, file);
  return oid;
}

export function hasObject(gitDir: string, oid: string): boolean {
  return isObjectId(oid) && fs.existsSync(objectPath(gitDir, oid));
}

export const EMPTY_TREE_ID = "4b825dc642cb6eb9a060e54bf8d69288fbee4904";

/** Reads a loose object, or returns null if it does not exist. */
export function readObject(gitDir: string, oid: string): GitObject | null {
  if (!isObjectId(oid)) return null;
  let compressed: Buffer;
  try {
    compressed = fs.readFileSync(objectPath(gitDir, oid));
  } catch {
    // Like the real git, the empty tree is known even when it is not stored.
    return oid === EMPTY_TREE_ID ? { type: "tree", data: Buffer.alloc(0) } : null;
  }
  const raw = zlib.inflateSync(compressed);
  const space = raw.indexOf(0x20);
  const nul = raw.indexOf(0);
  const type = raw.subarray(0, space).toString();
  if (space < 0 || nul < space || !OBJECT_TYPES.includes(type)) throw new Error(`corrupt object ${oid}`);
  return { type: type as ObjectType, data: raw.subarray(nul + 1) };
}

/** The IDs of all loose objects in the repository. */
export function listObjectIds(gitDir: string): string[] {
  const ids: string[] = [];
  const objectsDir = path.join(gitDir, "objects");
  for (const dir of fs.readdirSync(objectsDir)) {
    if (!/^[0-9a-f]{2}$/.test(dir)) continue;
    for (const name of fs.readdirSync(path.join(objectsDir, dir))) {
      if (/^[0-9a-f]{38}$/.test(name)) ids.push(dir + name);
    }
  }
  return ids;
}
