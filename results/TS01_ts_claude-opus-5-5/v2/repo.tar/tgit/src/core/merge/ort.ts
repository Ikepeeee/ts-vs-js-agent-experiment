// Merging trees the way the real git's default strategy (`merge-ort`) does, without rename
// detection: path by path, with a content merge where both sides changed a file, and with the
// merge bases merged first (recursively) when there is more than one.
import { readBlob } from "../diff/file-pairs.ts";
import { isBinary } from "../diff/xdiff.ts";
import { writeObject } from "../objects/store.ts";
import { MODE_SYMLINK, fileType, writeTreeFromFiles, type FileEntry } from "../objects/tree.ts";
import { comparePaths } from "../paths.ts";
import { mergeBases } from "../revision/merge-base.ts";
import { commitFiles } from "../status/changes.ts";
import { mergeContents } from "./xmerge.ts";

/** The names of the two sides, used in conflict markers and messages. */
export interface MergeLabels {
  ours: string;
  theirs: string;
}

/** A path the merge could not resolve, with its base, our, and their versions (index stages 1 to 3). */
export interface PathConflict {
  path: string;
  stages: [FileEntry | undefined, FileEntry | undefined, FileEntry | undefined];
}

export interface TreeMerge {
  /** The merged tree, written to the object store; conflicted files hold their tentative result. */
  tree: string;
  files: Map<string, FileEntry>;
  /** Conflicted paths, sorted. */
  conflicts: PathConflict[];
  /** What the real git reports on standard output (`Auto-merging ...`, `CONFLICT ...`). */
  messages: string[];
  /** What it reports on standard error. */
  warnings: string[];
}

const DEFAULT_MARKER_SIZE = 7;
const INNER_LABELS: MergeLabels = { ours: "Temporary merge branch 1", theirs: "Temporary merge branch 2" };

function same(a: FileEntry | undefined, b: FileEntry | undefined): boolean {
  return a !== undefined && b !== undefined && a.mode === b.mode && a.oid === b.oid;
}

/** One merge of three trees; `depth` is greater than 0 when merging merge bases. */
class TreeMerger {
  private readonly gitDir: string;
  private readonly labels: MergeLabels;
  private readonly depth: number;
  readonly files = new Map<string, FileEntry>();
  readonly conflicts: PathConflict[] = [];
  readonly messages: string[] = [];
  readonly warnings: string[] = [];

  constructor(gitDir: string, labels: MergeLabels, depth: number) {
    this.gitDir = gitDir;
    this.labels = labels;
    this.depth = depth;
  }

  private message(text: string): void {
    if (this.depth === 0) this.messages.push(text);
  }

  /** Records the result of a path, and the path as conflicted unless `clean` (`process_entry`). */
  private resolve(filePath: string, result: FileEntry | undefined, clean: boolean, stages: PathConflict["stages"]): void {
    if (result) this.files.set(filePath, result);
    if (!clean) this.conflicts.push({ path: filePath, stages });
  }

  mergePath(filePath: string, base: FileEntry | undefined, ours: FileEntry | undefined, theirs: FileEntry | undefined): void {
    const stages: PathConflict["stages"] = [base, ours, theirs];
    if (base && same(ours, base) && same(theirs, base)) return this.resolve(filePath, base, true, stages);
    if (ours && theirs) {
      if (same(ours, theirs)) return this.resolve(filePath, ours, true, stages);
      if (base && same(ours, base)) return this.resolve(filePath, theirs, true, stages);
      if (base && same(theirs, base)) return this.resolve(filePath, ours, true, stages);
      if (fileType(ours.mode) !== fileType(theirs.mode)) {
        // The real git moves both versions aside to new names; tgit keeps ours and reports a conflict.
        this.message(`CONFLICT (distinct types): ${filePath} had different types on each side.`);
        return this.resolve(filePath, ours, false, stages);
      }
      const merged = this.mergeContent(filePath, base, ours, theirs);
      if (!merged.clean) {
        this.message(`CONFLICT (${base ? "content" : "add/add"}): Merge conflict in ${filePath}`);
      }
      return this.resolve(filePath, merged.result, merged.clean, stages);
    }
    if (base && (ours || theirs)) {
      // Deleted on one side: fine if the other side left it unchanged, a conflict otherwise.
      const kept = (ours ?? theirs) as FileEntry;
      if (same(kept, base)) return this.resolve(filePath, undefined, true, stages);
      const [modifiedIn, deletedIn] = ours ? [this.labels.ours, this.labels.theirs] : [this.labels.theirs, this.labels.ours];
      this.message(
        `CONFLICT (modify/delete): ${filePath} deleted in ${deletedIn} and modified in ${modifiedIn}.  ` +
          `Version ${modifiedIn} of ${filePath} left in tree.`,
      );
      return this.resolve(filePath, this.depth > 0 ? base : kept, false, stages);
    }
    // Added on one side, or deleted on both.
    this.resolve(filePath, ours ?? theirs, true, stages);
  }

  /** Merges the modes and contents of two versions of a file of the same type (`handle_content_merge`). */
  private mergeContent(filePath: string, base: FileEntry | undefined, ours: FileEntry, theirs: FileEntry): { result: FileEntry | undefined; clean: boolean } {
    let clean = true;
    let mode = theirs.mode;
    if (ours.mode !== theirs.mode && ours.mode !== base?.mode) {
      mode = ours.mode;
      clean = theirs.mode === base?.mode;
    }
    if (ours.oid === theirs.oid || ours.oid === base?.oid) return { result: { mode, oid: theirs.oid }, clean };
    if (theirs.oid === base?.oid) return { result: { mode, oid: ours.oid }, clean };

    if (fileType(ours.mode) === fileType(MODE_SYMLINK)) {
      // Symbolic links are not merged: ours wins, or the base when merging merge bases.
      if (this.depth > 0) return { result: base, clean: false };
      return { result: { mode, oid: ours.oid }, clean: false };
    }
    this.message(`Auto-merging ${filePath}`);
    const twoWay = !base || fileType(base.mode) !== fileType(ours.mode);
    const baseData = twoWay || !base ? Buffer.alloc(0) : readBlob(this.gitDir, base.oid);
    const ourData = readBlob(this.gitDir, ours.oid);
    const theirData = readBlob(this.gitDir, theirs.oid);
    if (isBinary(baseData) || isBinary(ourData) || isBinary(theirData)) {
      // Binary files are not merged: ours wins, or the base when merging merge bases.
      if (this.depth > 0) return { result: { mode, oid: writeObject(this.gitDir, "blob", baseData) }, clean };
      this.warnings.push(`warning: Cannot merge binary files: ${filePath} (${this.labels.ours} vs. ${this.labels.theirs})`);
      return { result: { mode, oid: ours.oid }, clean: false };
    }
    const merged = mergeContents(baseData, ourData, theirData, {
      ours: this.labels.ours,
      theirs: this.labels.theirs,
      markerSize: DEFAULT_MARKER_SIZE + this.depth * 2,
    });
    const oid = writeObject(this.gitDir, "blob", merged.data);
    return { result: { mode, oid }, clean: clean && merged.conflicts === 0 };
  }
}

/** Merges the changes from `base` to `ours` and from `base` to `theirs`, and writes the merged tree. */
export function mergeTrees(
  gitDir: string,
  base: Map<string, FileEntry>,
  ours: Map<string, FileEntry>,
  theirs: Map<string, FileEntry>,
  labels: MergeLabels,
  depth = 0,
): TreeMerge {
  const merger = new TreeMerger(gitDir, labels, depth);
  const paths = [...new Set([...base.keys(), ...ours.keys(), ...theirs.keys()])].sort(comparePaths);
  for (const filePath of paths) merger.mergePath(filePath, base.get(filePath), ours.get(filePath), theirs.get(filePath));
  const tree = writeTreeFromFiles(gitDir, merger.files);
  return { tree, files: merger.files, conflicts: merger.conflicts, messages: merger.messages, warnings: merger.warnings };
}

/** The commits of a recursive merge, including the virtual commits made by merging merge bases. */
class CommitGraph {
  readonly gitDir: string;
  readonly virtualParents = new Map<string, string[]>();
  private readonly virtualFiles = new Map<string, Map<string, FileEntry>>();

  constructor(gitDir: string) {
    this.gitDir = gitDir;
  }

  files(id: string): Map<string, FileEntry> {
    return this.virtualFiles.get(id) ?? commitFiles(this.gitDir, id);
  }

  addVirtual(parents: string[], files: Map<string, FileEntry>): string {
    const id = `virtual-${this.virtualParents.size + 1}`;
    this.virtualParents.set(id, parents);
    this.virtualFiles.set(id, files);
    return id;
  }
}

/**
 * Merges two commits given their merge bases, newest first (`merge_ort_internal`): the bases are
 * merged into one, oldest first, and that is the base of the final merge.
 */
function mergeRecursive(graph: CommitGraph, ours: string, theirs: string, bases: string[], labels: MergeLabels, depth: number): TreeMerge {
  const [first, ...rest] = [...bases].reverse();
  let merged = first;
  for (const next of rest) {
    const prev = merged as string;
    const innerBases = mergeBases(graph.gitDir, prev, [next], graph.virtualParents);
    const inner = mergeRecursive(graph, prev, next, innerBases, INNER_LABELS, depth + 1);
    merged = graph.addVirtual([prev, next], inner.files);
  }
  const baseFiles = merged === undefined ? new Map<string, FileEntry>() : graph.files(merged);
  return mergeTrees(graph.gitDir, baseFiles, graph.files(ours), graph.files(theirs), labels, depth);
}

/** Merges commit `theirs` into commit `ours`, given their merge bases (newest first, as `mergeBases` returns them). */
export function mergeCommits(gitDir: string, ours: string, theirs: string, bases: string[], labels: MergeLabels): TreeMerge {
  return mergeRecursive(new CommitGraph(gitDir), ours, theirs, bases, labels, 0);
}
