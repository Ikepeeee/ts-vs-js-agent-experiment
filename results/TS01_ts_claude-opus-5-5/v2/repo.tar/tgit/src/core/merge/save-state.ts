// Saving local changes before a merge, as the real git does with `git stash create`: the objects it
// writes stay in the repository whatever the outcome of the merge.
import path from "node:path";
import type { Index } from "../index/index-file.ts";
import { commitSubject, readCommit } from "../objects/commit.ts";
import { writeTreeFromFiles, type FileEntry } from "../objects/tree.ts";
import { writeCommit } from "../objects/write-commit.ts";
import { HEADS_PREFIX, readHead } from "../refs/refs.ts";
import type { Repository } from "../repo/repository.ts";
import { Abbreviator } from "../revision/abbrev.ts";
import { commitFiles, diffFiles, indexFiles, treeMode, worktreeFiles } from "../status/changes.ts";
import { hashWorktreeFile } from "../worktree/files.ts";

/**
 * Writes the index and the working tree's tracked files as stash commits, if either differs from
 * HEAD. Returns the stash commit, or null if there was nothing to save.
 */
export function saveLocalChanges(repo: Repository, env: NodeJS.ProcessEnv, index: Index, head: string): string | null {
  const staged = indexFiles(index);
  const headFiles = commitFiles(repo.gitDir, head);
  if (diffFiles(headFiles, staged).size === 0 && diffFiles(staged, worktreeFiles(repo, index)).size === 0) return null;

  const headCommit = readCommit(repo.gitDir, head);
  const headInfo = readHead(repo.gitDir);
  const branch = headInfo.kind === "branch" ? headInfo.ref.slice(HEADS_PREFIX.length) : "(no branch)";
  const description = `${branch}: ${new Abbreviator(repo.gitDir).abbreviate(head)} ${headCommit ? commitSubject(headCommit) : ""}`;

  const indexTree = writeTreeFromFiles(repo.gitDir, staged);
  const indexCommit = writeCommit(repo, env, indexTree, [head], `index on ${description}\n`);

  // The working tree's version of every tracked file, with its blob written.
  const filemode = repo.config.getBool("core.filemode", true);
  const worktree = new Map<string, FileEntry>();
  for (const entry of index.list()) {
    const absPath = path.join(repo.workTree, entry.path);
    const file = hashWorktreeFile(repo.gitDir, absPath, { filemode, previousMode: entry.mode, write: true });
    if (file) worktree.set(entry.path, { mode: treeMode(file.mode), oid: file.oid });
  }
  const worktreeTree = writeTreeFromFiles(repo.gitDir, worktree);
  return writeCommit(repo, env, worktreeTree, [head, indexCommit], `WIP on ${description}`);
}
