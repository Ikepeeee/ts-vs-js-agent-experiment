// The files that record a merge in progress: MERGE_HEAD (the commit being merged), MERGE_MSG (the
// prepared commit message), and MERGE_MODE.
import fs from "node:fs";
import path from "node:path";

const STATE_FILES = ["MERGE_HEAD", "MERGE_MSG", "MERGE_MODE"];

/** The commit being merged, or null if no merge is in progress. */
export function readMergeHead(gitDir: string): string | null {
  try {
    return fs.readFileSync(path.join(gitDir, "MERGE_HEAD"), "utf8").trim().split("\n")[0] ?? null;
  } catch {
    return null;
  }
}

/** The prepared message of the merge in progress, or null if there is none. */
export function readMergeMessage(gitDir: string): string | null {
  try {
    return fs.readFileSync(path.join(gitDir, "MERGE_MSG"), "utf8");
  } catch {
    return null;
  }
}

/** Records a merge left to be concluded by `commit`. */
export function writeMergeState(gitDir: string, theirs: string, message: string): void {
  fs.writeFileSync(path.join(gitDir, "MERGE_HEAD"), `${theirs}\n`);
  fs.writeFileSync(path.join(gitDir, "MERGE_MODE"), "");
  fs.writeFileSync(path.join(gitDir, "MERGE_MSG"), message);
}

export function clearMergeState(gitDir: string): void {
  for (const name of STATE_FILES) fs.rmSync(path.join(gitDir, name), { force: true });
}
