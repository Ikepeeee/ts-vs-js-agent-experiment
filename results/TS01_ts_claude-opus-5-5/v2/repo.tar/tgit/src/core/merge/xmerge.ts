// Three-way merge of file contents, ported from the real git's xdiff (`xdl_merge` in xmerge.c) with the
// settings merges use: level "zealous", the "merge" conflict style, and the histogram diff.
import { splitRecords } from "../diff/records.ts";
import { MERGE_DEFAULTS, diffRecords, type Change } from "../diff/xdiff.ts";

/** The labels and marker size of conflict hunks: `<<<<<<< ours`, `=======`, `>>>>>>> theirs`. */
export interface ConflictLabels {
  ours: string;
  theirs: string;
  markerSize: number;
}

export interface ContentMerge {
  data: Buffer;
  /** The number of conflict hunks; 0 if the merge is clean. */
  conflicts: number;
}

/** Where a merge hunk comes from (`xdmerge_t.mode`). */
const CONFLICT = 0;
const SIDE1 = 1;
const SIDE2 = 2;
const IDENTICAL = 4;

/** A region of the merge: lines `i0..` of the base, `i1..` of side 1 and `i2..` of side 2. */
interface MergeHunk {
  mode: number;
  i0: number;
  chg0: number;
  i1: number;
  chg1: number;
  i2: number;
  chg2: number;
}

/** Appends a hunk, joining it with the previous one if they overlap (`xdl_append_merge`). */
function appendHunk(hunks: MergeHunk[], hunk: MergeHunk): void {
  const last = hunks.at(-1);
  if (last && (hunk.i1 <= last.i1 + last.chg1 || hunk.i2 <= last.i2 + last.chg2)) {
    if (hunk.mode !== last.mode) last.mode = CONFLICT;
    last.chg0 = hunk.i0 + hunk.chg0 - last.i0;
    last.chg1 = hunk.i1 + hunk.chg1 - last.i1;
    last.chg2 = hunk.i2 + hunk.chg2 - last.i2;
  } else {
    hunks.push(hunk);
  }
}

function sameLines(lines1: Buffer[], i1: number, lines2: Buffer[], i2: number, count: number): boolean {
  for (let k = 0; k < count; k++) {
    if (!(lines1[i1 + k] as Buffer).equals(lines2[i2 + k] as Buffer)) return false;
  }
  return true;
}

/** Walks both edit scripts together into merge hunks (the first half of `xdl_do_merge`). */
function collectHunks(changes1: Change[], changes2: Change[], lines1: Buffer[], lines2: Buffer[], baseCount: number): MergeHunk[] {
  const hunks: MergeHunk[] = [];
  let k1 = 0;
  let k2 = 0;
  while (k1 < changes1.length && k2 < changes2.length) {
    const x1 = changes1[k1] as Change;
    const x2 = changes2[k2] as Change;
    if (x1.i1 + x1.chg1 < x2.i1) {
      appendHunk(hunks, { mode: SIDE1, i0: x1.i1, chg0: x1.chg1, i1: x1.i2, chg1: x1.chg2, i2: x2.i2 - x2.i1 + x1.i1, chg2: x1.chg1 });
      k1++;
      continue;
    }
    if (x2.i1 + x2.chg1 < x1.i1) {
      appendHunk(hunks, { mode: SIDE2, i0: x2.i1, chg0: x2.chg1, i1: x1.i2 - x1.i1 + x2.i1, chg1: x2.chg1, i2: x2.i2, chg2: x2.chg2 });
      k2++;
      continue;
    }
    const identical = x1.i1 === x2.i1 && x1.chg1 === x2.chg1 && x1.chg2 === x2.chg2 && sameLines(lines1, x1.i2, lines2, x2.i2, x1.chg2);
    if (!identical) {
      // Overlapping changes: a conflict covering both, in the coordinates of each side.
      const off = x1.i1 - x2.i1;
      const ffo = off + x1.chg1 - x2.chg1;
      let i0 = x1.i1;
      let i1 = x1.i2;
      let i2 = x2.i2;
      if (off > 0) {
        i0 -= off;
        i1 -= off;
      } else {
        i2 += off;
      }
      let chg0 = x1.i1 + x1.chg1 - i0;
      let chg1 = x1.i2 + x1.chg2 - i1;
      let chg2 = x2.i2 + x2.chg2 - i2;
      if (ffo < 0) {
        chg0 -= ffo;
        chg1 -= ffo;
      } else {
        chg2 += ffo;
      }
      appendHunk(hunks, { mode: CONFLICT, i0, chg0, i1, chg1, i2, chg2 });
    }
    const end1 = x1.i1 + x1.chg1;
    const end2 = x2.i1 + x2.chg1;
    if (end1 >= end2) k2++;
    if (end2 >= end1) k1++;
  }
  for (const x1 of changes1.slice(k1)) {
    const i2 = x1.i1 + lines2.length - baseCount;
    appendHunk(hunks, { mode: SIDE1, i0: x1.i1, chg0: x1.chg1, i1: x1.i2, chg1: x1.chg2, i2, chg2: x1.chg1 });
  }
  for (const x2 of changes2.slice(k2)) {
    const i1 = x2.i1 + lines1.length - baseCount;
    appendHunk(hunks, { mode: SIDE2, i0: x2.i1, chg0: x2.chg1, i1, chg1: x2.chg1, i2: x2.i2, chg2: x2.chg2 });
  }
  return hunks;
}

/**
 * Diffs the two sides of each conflict, so that lines both sides agree on move out of it; a
 * conflict may split into several (`xdl_refine_conflicts`).
 */
function refineConflicts(hunks: MergeHunk[], lines1: Buffer[], lines2: Buffer[]): MergeHunk[] {
  const refined: MergeHunk[] = [];
  for (const hunk of hunks) {
    if (hunk.mode !== CONFLICT || hunk.chg1 === 0 || hunk.chg2 === 0) {
      refined.push(hunk);
      continue;
    }
    const sub1 = lines1.slice(hunk.i1, hunk.i1 + hunk.chg1);
    const sub2 = lines2.slice(hunk.i2, hunk.i2 + hunk.chg2);
    const { changes } = diffRecords(sub1, sub2, MERGE_DEFAULTS);
    if (changes.length === 0) {
      refined.push({ ...hunk, mode: IDENTICAL });
      continue;
    }
    for (const change of changes) {
      refined.push({ ...hunk, i1: hunk.i1 + change.i1, chg1: change.chg1, i2: hunk.i2 + change.i2, chg2: change.chg2 });
    }
  }
  return refined;
}

/** Joins conflicts separated by at most 3 lines (`xdl_simplify_non_conflicts`). */
function simplifyNonConflicts(hunks: MergeHunk[]): MergeHunk[] {
  const result: MergeHunk[] = [];
  for (const hunk of hunks) {
    const last = result.at(-1);
    if (last && last.mode === CONFLICT && hunk.mode === CONFLICT && hunk.i1 - (last.i1 + last.chg1) <= 3) {
      last.chg1 = hunk.i1 + hunk.chg1 - last.i1;
      last.chg2 = hunk.i2 + hunk.chg2 - last.i2;
    } else {
      result.push({ ...hunk });
    }
  }
  return result;
}

/** Whether line `i` of a file ends with CRLF; -1 if the file cannot tell (`is_eol_crlf`). */
function eolIsCrlf(lines: Buffer[], i: number): number {
  const endsWithCrlf = (line: Buffer): number => (line.length > 1 && line[line.length - 2] === 0x0d ? 1 : 0);
  if (i < lines.length - 1) return endsWithCrlf(lines[i] as Buffer);
  if (lines.length === 0) return -1;
  const line = lines[i] as Buffer;
  if (line.length > 0 && line[line.length - 1] === 0x0a) return endsWithCrlf(line);
  if (i === 0) return -1;
  return endsWithCrlf(lines[i - 1] as Buffer);
}

/** Whether the lines added around a conflict should end with CRLF (`is_cr_needed`). */
function needsCr(base: Buffer[], lines1: Buffer[], lines2: Buffer[], hunk: MergeHunk): boolean {
  let crlf = eolIsCrlf(lines1, hunk.i1 ? hunk.i1 - 1 : 0);
  if (crlf) crlf = eolIsCrlf(lines2, hunk.i2 ? hunk.i2 - 1 : 0);
  if (crlf) crlf = eolIsCrlf(base, 0);
  return crlf > 0;
}

/** Copies lines; with `addNewline`, the last one gets a newline if it lacks one (`xdl_recs_copy`). */
function copyLines(out: Buffer[], lines: Buffer[], start: number, count: number, addNewline: boolean, cr: boolean): void {
  if (count < 1) return;
  out.push(...lines.slice(start, start + count));
  const last = lines[start + count - 1] as Buffer;
  if (addNewline && (last.length === 0 || last[last.length - 1] !== 0x0a)) out.push(Buffer.from(cr ? "\r\n" : "\n"));
}

/** Writes the merged file (`xdl_fill_merge_buffer` with `fill_conflict_hunk`). */
function fillMergeBuffer(hunks: MergeHunk[], base: Buffer[], lines1: Buffer[], lines2: Buffer[], labels: ConflictLabels): Buffer {
  const out: Buffer[] = [];
  const marker = (ch: string, label: string, cr: boolean): Buffer =>
    Buffer.from(`${ch.repeat(labels.markerSize)}${label ? ` ${label}` : ""}${cr ? "\r" : ""}\n`);
  let i = 0;
  for (const hunk of hunks) {
    if (hunk.mode === IDENTICAL) continue;
    copyLines(out, lines1, i, hunk.i1 - i, false, false);
    if (hunk.mode === CONFLICT) {
      const cr = needsCr(base, lines1, lines2, hunk);
      out.push(marker("<", labels.ours, cr));
      copyLines(out, lines1, hunk.i1, hunk.chg1, true, cr);
      out.push(marker("=", "", cr));
      copyLines(out, lines2, hunk.i2, hunk.chg2, true, cr);
      out.push(marker(">", labels.theirs, cr));
    } else if (hunk.mode === SIDE1) {
      copyLines(out, lines1, hunk.i1, hunk.chg1, false, false);
    } else {
      copyLines(out, lines2, hunk.i2, hunk.chg2, false, false);
    }
    i = hunk.i1 + hunk.chg1;
  }
  copyLines(out, lines1, i, lines1.length - i, false, false);
  return Buffer.concat(out);
}

/** Merges the changes from `base` to `ours` and from `base` to `theirs`. */
export function mergeContents(base: Buffer, ours: Buffer, theirs: Buffer, labels: ConflictLabels): ContentMerge {
  const baseLines = splitRecords(base);
  const diff1 = diffRecords(baseLines, splitRecords(ours), MERGE_DEFAULTS);
  const diff2 = diffRecords(baseLines, splitRecords(theirs), MERGE_DEFAULTS);
  if (diff1.changes.length === 0) return { data: theirs, conflicts: 0 };
  if (diff2.changes.length === 0) return { data: ours, conflicts: 0 };

  const collected = collectHunks(diff1.changes, diff2.changes, diff1.lines2, diff2.lines2, baseLines.length);
  const hunks = simplifyNonConflicts(refineConflicts(collected, diff1.lines2, diff2.lines2));
  return {
    data: fillMergeBuffer(hunks, baseLines, diff1.lines2, diff2.lines2, labels),
    conflicts: hunks.filter((hunk) => hunk.mode === CONFLICT).length,
  };
}
