/** Compares paths bytewise in UTF-8, the order the real git uses for the index and trees. */
export function comparePaths(a: string, b: string): number {
  return Buffer.compare(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
}

/** Joins a directory prefix ("" for the top) and a relative path with "/". */
export function joinPath(prefix: string, name: string): string {
  return prefix === "" ? name : `${prefix}/${name}`;
}
