import fs from "node:fs";
import path from "node:path";

/**
 * Configuration values read from the user's and the repository's config files.
 * Keys are normalized to "section.key" or "section.subsection.key", with the section and the key
 * lowercased, as the real git does. Later files override earlier ones.
 */
export class Config {
  private readonly values = new Map<string, string[]>();

  /** The last value of a key; a key given without "= value" has the value "true". */
  get(key: string): string | undefined {
    return this.values.get(normalizeKey(key))?.at(-1);
  }

  getBool(key: string, defaultValue: boolean): boolean {
    const value = this.get(key);
    if (value === undefined) return defaultValue;
    const lower = value.toLowerCase();
    if (["true", "yes", "on", "1"].includes(lower)) return true;
    if (["false", "no", "off", "0", ""].includes(lower)) return false;
    return defaultValue;
  }

  /** Adds the entries of a config file; a missing file is ignored. */
  addFile(file: string): void {
    let text: string;
    try {
      text = fs.readFileSync(file, "utf8");
    } catch {
      return;
    }
    for (const [key, value] of parseConfig(text)) {
      const values = this.values.get(key) ?? [];
      values.push(value);
      this.values.set(key, values);
    }
  }
}

function normalizeKey(key: string): string {
  const first = key.indexOf(".");
  const last = key.lastIndexOf(".");
  if (first < 0) return key.toLowerCase();
  const section = key.slice(0, first).toLowerCase();
  const name = key.slice(last + 1).toLowerCase();
  return first === last ? `${section}.${name}` : `${section}.${key.slice(first + 1, last)}.${name}`;
}

/** Parses the text of a config file into (normalized key, value) pairs. */
export function parseConfig(text: string): [string, string][] {
  const entries: [string, string][] = [];
  let section = "";
  const lines = text.split("\n");
  for (let i = 0; i < lines.length; i++) {
    let line = (lines[i] as string).trim();
    if (line === "" || line.startsWith("#") || line.startsWith(";")) continue;
    if (line.startsWith("[")) {
      const header = /^\[\s*([A-Za-z0-9.-]+)(?:\s+"((?:[^"\\]|\\.)*)")?\s*\]/.exec(line);
      if (!header) continue;
      const name = (header[1] as string).toLowerCase();
      section = header[2] === undefined ? name : `${name}.${header[2].replace(/\\(.)/g, "$1")}`;
      line = line.slice(header[0].length).trim();
      if (line === "" || line.startsWith("#") || line.startsWith(";")) continue;
    }
    const key = /^([A-Za-z][A-Za-z0-9-]*)\s*(=?)/.exec(line);
    if (!key || section === "") continue;
    const name = `${section}.${(key[1] as string).toLowerCase()}`;
    if (key[2] !== "=") {
      entries.push([name, "true"]);
      continue;
    }
    let raw = line.slice(key[0].length);
    // A backslash at the end of a line continues the value on the next line.
    while (raw.endsWith("\\") && i + 1 < lines.length) raw = raw.slice(0, -1) + (lines[++i] as string);
    entries.push([name, parseValue(raw)]);
  }
  return entries;
}

function parseValue(raw: string): string {
  let value = "";
  let quoted = false;
  let pendingSpace = "";
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i] as string;
    if (!quoted && (ch === "#" || ch === ";")) break;
    if (!quoted && /\s/.test(ch)) {
      if (value !== "") pendingSpace += ch;
      continue;
    }
    value += pendingSpace;
    pendingSpace = "";
    if (ch === '"') {
      quoted = !quoted;
    } else if (ch === "\\") {
      const next = raw[++i] ?? "";
      value += next === "n" ? "\n" : next === "t" ? "\t" : next === "b" ? "\b" : next;
    } else {
      value += ch;
    }
  }
  return value;
}

/** The user's global config file. */
export function globalConfigPath(env: NodeJS.ProcessEnv): string | null {
  return env.HOME ? path.join(env.HOME, ".gitconfig") : null;
}

/** Loads the global config, and the repository's config when `gitDir` is given. */
export function loadConfig(env: NodeJS.ProcessEnv, gitDir: string | null): Config {
  const config = new Config();
  const global = globalConfigPath(env);
  if (global) config.addFile(global);
  if (gitDir) config.addFile(path.join(gitDir, "config"));
  return config;
}
