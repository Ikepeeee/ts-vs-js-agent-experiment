import fs from "node:fs";
import path from "node:path";
import type { IndexEntry, StatData } from "../index/index-file.ts";
import { hashObject, writeObject } from "../objects/store.ts";

export const INDEX_MODE_FILE = 0o100644;
export const INDEX_MODE_EXECUTABLE = 0o100755;
export const INDEX_MODE_SYMLINK = 0o120000;

export function lstatOrNull(absPath: string): fs.BigIntStats | null {
  try {
    return fs.lstatSync(absPath, { bigint: true });
  } catch {
    return null;
  }
}

export function statData(st: fs.BigIntStats): StatData {
  const low32 = (n: bigint): number => Number(n & 0xffffffffn);
  return {
    ctimeSec: low32(st.ctimeNs / 1_000_000_000n),
    ctimeNsec: Number(st.ctimeNs % 1_000_000_000n),
    mtimeSec: low32(st.mtimeNs / 1_000_000_000n),
    mtimeNsec: Number(st.mtimeNs % 1_000_000_000n),
    dev: low32(st.dev),
    ino: low32(st.ino),
    uid: low32(st.uid),
    gid: low32(st.gid),
    size: low32(st.size),
  };
}

/**
 * The index mode for a file in the working tree, or null if it is not a regular file or a symlink.
 * Without `core.filemode`, a regular file keeps the executable bit recorded in `previousMode`.
 */
export function modeOf(st: fs.BigIntStats, filemode: boolean, previousMode?: number): number | null {
  if (st.isSymbolicLink()) return INDEX_MODE_SYMLINK;
  if (!st.isFile()) return null;
  if (!filemode) return previousMode === INDEX_MODE_EXECUTABLE ? INDEX_MODE_EXECUTABLE : INDEX_MODE_FILE;
  return (st.mode & 0o100n) !== 0n ? INDEX_MODE_EXECUTABLE : INDEX_MODE_FILE;
}

/** The blob content of a working tree file: the file's bytes, or a symlink's target. */
export function readContent(absPath: string, mode: number): Buffer {
  return mode === INDEX_MODE_SYMLINK ? Buffer.from(fs.readlinkSync(absPath, "utf8"), "utf8") : fs.readFileSync(absPath);
}

/** A working tree file as an index entry would record it. */
export interface WorktreeFile {
  mode: number;
  oid: string;
  stat: fs.BigIntStats;
}

/**
 * Reads a working tree file and computes its blob ID; with `write`, also stores the blob.
 * Returns null if the path is missing or is not a regular file or a symlink.
 */
export function hashWorktreeFile(
  gitDir: string,
  absPath: string,
  options: { filemode: boolean; previousMode?: number; write: boolean },
): WorktreeFile | null {
  const st = lstatOrNull(absPath);
  if (!st) return null;
  const mode = modeOf(st, options.filemode, options.previousMode);
  if (mode === null) return null;
  const content = readContent(absPath, mode);
  const oid = options.write ? writeObject(gitDir, "blob", content) : hashObject("blob", content);
  return { mode, oid, stat: st };
}

export function toIndexEntry(filePath: string, file: WorktreeFile): IndexEntry {
  return { path: filePath, oid: file.oid, mode: file.mode, stat: statData(file.stat) };
}

/** Writes a blob to the working tree as a regular file, an executable, or a symlink. */
export function writeWorktreeFile(absPath: string, mode: number, content: Buffer): void {
  fs.mkdirSync(path.dirname(absPath), { recursive: true });
  const existing = lstatOrNull(absPath);
  if (existing) fs.rmSync(absPath, { recursive: true, force: true });
  if (mode === INDEX_MODE_SYMLINK) {
    fs.symlinkSync(content.toString("utf8"), absPath);
  } else {
    fs.writeFileSync(absPath, content, { mode: mode === INDEX_MODE_EXECUTABLE ? 0o777 : 0o666 });
  }
}

/** Removes a file from the working tree, then any parent directories left empty (up to the top). */
export function removeWorktreeFile(workTree: string, filePath: string): void {
  fs.rmSync(path.join(workTree, filePath), { force: true });
  let dir = path.dirname(filePath);
  while (dir !== "." && dir !== "") {
    try {
      fs.rmdirSync(path.join(workTree, dir));
    } catch {
      return;
    }
    dir = path.dirname(dir);
  }
}
