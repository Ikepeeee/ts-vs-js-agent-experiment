import fs from "node:fs";
import path from "node:path";
import type { Repository } from "../repo/repository.ts";
import { wildmatch } from "./wildmatch.ts";

interface Pattern {
  pattern: string;
  negative: boolean;
  /** A trailing "/": matches directories only. */
  mustBeDir: boolean;
  /** No "/" in the pattern: matches the last path component at any depth. */
  basenameOnly: boolean;
}

function trimTrailingSpaces(line: string): string {
  let end = line.length;
  while (end > 0 && line[end - 1] === " " && line[end - 2] !== "\\") end--;
  return line.slice(0, end);
}

export function parsePatterns(text: string): Pattern[] {
  const patterns: Pattern[] = [];
  for (const rawLine of text.split("\n")) {
    let line = trimTrailingSpaces(rawLine);
    if (line === "" || line.startsWith("#")) continue;
    const negative = line.startsWith("!");
    if (negative) line = line.slice(1);
    const mustBeDir = line.endsWith("/");
    if (mustBeDir) line = line.slice(0, -1);
    const basenameOnly = !line.includes("/");
    if (line.startsWith("/")) line = line.slice(1);
    if (line === "") continue;
    patterns.push({ pattern: line, negative, mustBeDir, basenameOnly });
  }
  return patterns;
}

function readPatterns(file: string): Pattern[] {
  try {
    return parsePatterns(fs.readFileSync(file, "utf8"));
  } catch {
    return [];
  }
}

/** The last pattern in a list that matches the path, or undefined. */
function lastMatch(patterns: readonly Pattern[], filePath: string, isDir: boolean): Pattern | undefined {
  const basename = filePath.slice(filePath.lastIndexOf("/") + 1);
  for (let i = patterns.length - 1; i >= 0; i--) {
    const p = patterns[i] as Pattern;
    if (p.mustBeDir && !isDir) continue;
    const subject = p.basenameOnly ? basename : filePath;
    if (wildmatch(p.pattern, subject, { pathname: true })) return p;
  }
  return undefined;
}

/**
 * Ignore rules from the `.gitignore` at the top of the working tree, which take precedence over
 * `.git/info/exclude`. A path inside an ignored directory is ignored too.
 */
export class IgnoreRules {
  private readonly groups: Pattern[][];

  constructor(groups: Pattern[][]) {
    this.groups = groups;
  }

  static load(repo: Repository): IgnoreRules {
    return new IgnoreRules([
      readPatterns(path.join(repo.workTree, ".gitignore")),
      readPatterns(path.join(repo.gitDir, "info", "exclude")),
    ]);
  }

  /** Whether the path itself matches, without looking at its parent directories. */
  matches(filePath: string, isDir: boolean): boolean {
    for (const group of this.groups) {
      const match = lastMatch(group, filePath, isDir);
      if (match) return !match.negative;
    }
    return false;
  }

  /** Whether the path or one of its parent directories is ignored. */
  isIgnored(filePath: string, isDir: boolean): boolean {
    for (let slash = filePath.indexOf("/"); slash >= 0; slash = filePath.indexOf("/", slash + 1)) {
      if (this.matches(filePath.slice(0, slash), true)) return true;
    }
    return this.matches(filePath, isDir);
  }
}
