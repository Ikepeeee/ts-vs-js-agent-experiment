// A port of the real git's wildmatch(), which matches gitignore patterns and pathspecs.

const MATCH = 0;
const NOMATCH = 1;
const ABORT_ALL = -1;
const ABORT_TO_STARSTAR = -2;

const CLASSES: Record<string, (c: string) => boolean> = {
  alnum: (c) => /[A-Za-z0-9]/.test(c),
  alpha: (c) => /[A-Za-z]/.test(c),
  blank: (c) => c === " " || c === "\t",
  cntrl: (c) => c.charCodeAt(0) < 0x20 || c.charCodeAt(0) === 0x7f,
  digit: (c) => /[0-9]/.test(c),
  graph: (c) => c.charCodeAt(0) > 0x20 && c.charCodeAt(0) < 0x7f,
  lower: (c) => /[a-z]/.test(c),
  print: (c) => c.charCodeAt(0) >= 0x20 && c.charCodeAt(0) < 0x7f,
  punct: (c) => /[!-/:-@[-`{-~]/.test(c),
  space: (c) => /[ \t\n\r\v\f]/.test(c),
  upper: (c) => /[A-Z]/.test(c),
  xdigit: (c) => /[0-9A-Fa-f]/.test(c),
};

function isGlobSpecial(c: string | undefined): boolean {
  return c === "*" || c === "?" || c === "[" || c === "\\";
}

function doWild(p: string, pi: number, text: string, ti: number, pathname: boolean): number {
  for (; pi < p.length; pi++, ti++) {
    let pCh = p[pi] as string;
    const tCh = text[ti];
    if (tCh === undefined && pCh !== "*") return ABORT_ALL;
    switch (pCh) {
      case "\\":
        pCh = p[++pi] ?? "";
        if (tCh !== pCh) return NOMATCH;
        continue;
      case "?":
        if (pathname && tCh === "/") return NOMATCH;
        continue;
      case "*": {
        let matchSlash: boolean;
        if (p[++pi] === "*") {
          const prevP = pi - 2;
          while (p[++pi] === "*");
          if ((prevP < 0 || p[prevP] === "/") && (pi >= p.length || p[pi] === "/" || (p[pi] === "\\" && p[pi + 1] === "/"))) {
            if (p[pi] === "/" && doWild(p, pi + 1, text, ti, pathname) === MATCH) return MATCH;
            matchSlash = true;
          } else {
            matchSlash = false;
          }
        } else {
          matchSlash = !pathname;
        }
        if (pi >= p.length) {
          if (!matchSlash && text.indexOf("/", ti) >= 0) return NOMATCH;
          return MATCH;
        }
        if (!matchSlash && p[pi] === "/") {
          const slash = text.indexOf("/", ti);
          if (slash < 0) return NOMATCH;
          ti = slash;
          // The slash itself is consumed by the loop.
          break;
        }
        for (;;) {
          if (ti >= text.length) break;
          if (!isGlobSpecial(p[pi])) {
            const literal = p[pi];
            while (ti < text.length && (matchSlash || text[ti] !== "/")) {
              if (text[ti] === literal) break;
              ti++;
            }
            if (text[ti] !== literal) return matchSlash ? ABORT_ALL : ABORT_TO_STARSTAR;
          }
          const matched = doWild(p, pi, text, ti, pathname);
          if (matched !== NOMATCH) {
            if (!matchSlash || matched !== ABORT_TO_STARSTAR) return matched;
          } else if (!matchSlash && text[ti] === "/") {
            return ABORT_TO_STARSTAR;
          }
          ti++;
        }
        return ABORT_ALL;
      }
      case "[": {
        const t = tCh as string;
        pCh = p[++pi] ?? "";
        if (pCh === "^") pCh = "!";
        const negated = pCh === "!";
        if (negated) pCh = p[++pi] ?? "";
        let prevCh = "";
        let matched = false;
        do {
          if (pCh === "") return ABORT_ALL;
          if (pCh === "\\") {
            pCh = p[++pi] ?? "";
            if (pCh === "") return ABORT_ALL;
            if (t === pCh) matched = true;
          } else if (pCh === "-" && prevCh !== "" && pi + 1 < p.length && p[pi + 1] !== "]") {
            pCh = p[++pi] as string;
            if (pCh === "\\") {
              pCh = p[++pi] ?? "";
              if (pCh === "") return ABORT_ALL;
            }
            if (t <= pCh && t >= prevCh) matched = true;
            pCh = "";
          } else if (pCh === "[" && p[pi + 1] === ":") {
            const start = pi + 2;
            const end = p.indexOf("]", start);
            if (end < 0) return ABORT_ALL;
            if (end - start < 1 || p[end - 1] !== ":") {
              // Not a "[:class:]": treat "[" as a normal character of the set.
              if (t === "[") matched = true;
            } else {
              const test = CLASSES[p.slice(start, end - 1)];
              if (!test) return ABORT_ALL;
              if (test(t)) matched = true;
              pi = end;
              pCh = "";
            }
          } else if (t === pCh) {
            matched = true;
          }
          prevCh = pCh;
          pCh = p[++pi] ?? "";
        } while (pCh !== "]");
        if (matched === negated || (pathname && t === "/")) return NOMATCH;
        continue;
      }
      default:
        if (tCh !== pCh) return NOMATCH;
        continue;
    }
  }
  return ti < text.length ? NOMATCH : MATCH;
}

/** Matches `text` against a glob `pattern`. With `pathname`, wildcards other than "**" do not match "/". */
export function wildmatch(pattern: string, text: string, options: { pathname?: boolean } = {}): boolean {
  return doWild(pattern, 0, text, 0, options.pathname === true) === MATCH;
}

/** Whether a string contains glob special characters. */
export function hasWildcard(pattern: string): boolean {
  return /[*?[\\]/.test(pattern);
}
