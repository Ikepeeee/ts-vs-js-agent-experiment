import fs from "node:fs";
import path from "node:path";
import type { Index } from "../index/index-file.ts";
import { joinPath } from "../paths.ts";
import type { Repository } from "../repo/repository.ts";
import type { IgnoreRules } from "./ignore.ts";

export interface WorktreeScan {
  /** Untracked, not ignored files (and directories ending in "/" when they are collapsed). */
  untracked: string[];
  /** Ignored paths met while scanning; the contents of an ignored directory are not visited. */
  ignored: string[];
}

function readDir(absDir: string): fs.Dirent[] {
  try {
    return fs.readdirSync(absDir, { withFileTypes: true });
  } catch {
    return [];
  }
}

/**
 * Finds the files that are neither tracked nor ignored. With `collapseDirectories` (as `git status`
 * shows them), a directory without tracked files is reported once as "dir/", and only if it
 * contains at least one untracked file.
 */
export function scanWorktree(
  repo: Repository,
  index: Index,
  ignore: IgnoreRules,
  options: { collapseDirectories: boolean },
): WorktreeScan {
  const trackedDirs = index.directories();
  const result: WorktreeScan = { untracked: [], ignored: [] };

  const hasUntrackedContent = (dir: string): boolean =>
    readDir(path.join(repo.workTree, dir)).some((entry) => {
      if (entry.name === ".git") return false;
      const child = joinPath(dir, entry.name);
      if (entry.isDirectory()) return !ignore.matches(child, true) && hasUntrackedContent(child);
      return (entry.isFile() || entry.isSymbolicLink()) && !ignore.matches(child, false);
    });

  const walk = (dir: string): void => {
    for (const entry of readDir(path.join(repo.workTree, dir))) {
      if (entry.name === ".git") continue;
      const child = joinPath(dir, entry.name);
      const isDir = entry.isDirectory();
      if (!isDir && (index.has(child) || !(entry.isFile() || entry.isSymbolicLink()))) continue;
      if (ignore.matches(child, isDir)) {
        result.ignored.push(child);
      } else if (!isDir) {
        result.untracked.push(child);
      } else if (trackedDirs.has(child) || !options.collapseDirectories) {
        walk(child);
      } else if (hasUntrackedContent(child)) {
        result.untracked.push(`${child}/`);
      }
    }
  };
  walk("");
  return result;
}
