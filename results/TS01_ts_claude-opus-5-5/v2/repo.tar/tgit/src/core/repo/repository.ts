import fs from "node:fs";
import path from "node:path";
import { fatal } from "../../cli/errors.ts";
import { loadConfig, type Config } from "../config/config.ts";

/** A non-bare repository: its `.git` directory and the working tree that contains it. */
export interface Repository {
  gitDir: string;
  workTree: string;
  config: Config;
}

export function isGitDirectory(dir: string): boolean {
  try {
    return fs.statSync(path.join(dir, "HEAD")).isFile() && fs.statSync(path.join(dir, "objects")).isDirectory();
  } catch {
    return false;
  }
}

/** Searches from `cwd` upward for a directory containing `.git`, as the real git does. */
export function discoverRepository(cwd: string, env: NodeJS.ProcessEnv): Repository | null {
  let dir = path.resolve(cwd);
  for (;;) {
    const gitDir = path.join(dir, ".git");
    if (isGitDirectory(gitDir)) return { gitDir, workTree: dir, config: loadConfig(env, gitDir) };
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

export function requireRepository(cwd: string, env: NodeJS.ProcessEnv): Repository {
  const repo = discoverRepository(cwd, env);
  if (!repo) throw fatal("not a git repository (or any of the parent directories): .git");
  return repo;
}

/** The current directory relative to the top of the working tree, with "/" separators ("" at the top). */
export function worktreePrefix(repo: Repository, cwd: string): string {
  const relative = path.relative(repo.workTree, path.resolve(cwd));
  return relative.split(path.sep).join("/");
}
