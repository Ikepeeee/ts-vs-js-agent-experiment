import { ExitError } from "./cli/errors.ts";
import type { CommandContext } from "./cli/context.ts";
import { commands } from "./commands/registry.ts";

function main(argv: string[]): number {
  const [name, ...args] = argv;
  if (name === undefined) {
    process.stderr.write("usage: tgit <command> [<args>]\n");
    return 1;
  }
  const run = commands.get(name);
  if (!run) {
    process.stderr.write(`tgit: '${name}' is not a git command. See 'tgit --help'.\n`);
    return 1;
  }
  const ctx: CommandContext = {
    args,
    cwd: process.cwd(),
    env: process.env,
    stdout: (text) => process.stdout.write(text),
    stderr: (text) => process.stderr.write(text),
  };
  try {
    return run(ctx);
  } catch (error) {
    if (error instanceof ExitError) {
      process.stderr.write(`${error.message}\n`);
      return error.code;
    }
    throw error;
  }
}

process.exitCode = main(process.argv.slice(2));
