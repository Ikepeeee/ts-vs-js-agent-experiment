// Runs the differential tests: every scenario under scenarios/, then random command sequences.
// Usage: node test/difftest/difftest.ts [--versions v1,v2] [--seeds 1,2,3] [--count 100]
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { parseArgs } from "node:util";

const here = import.meta.dirname;
const root = path.resolve(here, "../..");
const tools = path.join(here, "tools");
const tgit = `node ${path.join(root, "src", "main.ts")}`;

const { values } = parseArgs({
  options: {
    versions: { type: "string", default: "v1,v2" },
    seeds: { type: "string", default: "1,2,3" },
    count: { type: "string", default: "100" },
  },
});

function run(script: string, args: string[]): boolean {
  const result = spawnSync(process.execPath, [path.join(tools, script), ...args], { stdio: "inherit" });
  return result.status === 0;
}

let ok = run("run.mjs", ["--tgit", tgit, path.join(here, "scenarios")]);
const out = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-random-"));
try {
  for (const version of values.versions.split(",")) {
    for (const seed of values.seeds.split(",")) {
      const dir = path.join(out, version, seed);
      ok = run("gen.mjs", ["--version", version, "--seed", seed, "--count", values.count, "--out", dir]) && ok;
      ok = run("run.mjs", ["--tgit", tgit, dir]) && ok;
    }
  }
} finally {
  fs.rmSync(out, { recursive: true, force: true });
}
process.exitCode = ok ? 0 : 1;
