import assert from "node:assert/strict";
import { test } from "node:test";
import { ExitError } from "../../src/cli/errors.ts";
import { lastValue, parseOptions } from "../../src/cli/options.ts";

const defs = [
  { name: "quiet", short: "q", long: "quiet" },
  { name: "branch", short: "b", long: "initial-branch", takesValue: true },
];

test("parses short, clustered, and long options in any position", () => {
  const parsed = parseOptions(["dir", "-qbmain", "--initial-branch=dev", "-b", "x"], defs);
  assert.deepEqual(parsed.positionals, ["dir"]);
  assert.ok(parsed.options.has("quiet"));
  assert.deepEqual(parsed.options.get("branch"), ["main", "dev", "x"]);
  assert.equal(lastValue(parsed, "branch"), "x");
});

test("treats everything after -- as positionals", () => {
  const parsed = parseOptions(["--", "-x.txt", "--quiet"], defs);
  assert.deepEqual(parsed.positionals, ["-x.txt", "--quiet"]);
  assert.equal(parsed.options.size, 0);
});

test("rejects unknown options and missing values with exit code 129", () => {
  for (const args of [["-z"], ["--bogus"], ["-b"], ["--quiet=1"]]) {
    assert.throws(() => parseOptions(args, defs), (e: unknown) => e instanceof ExitError && e.code === 129);
  }
});
