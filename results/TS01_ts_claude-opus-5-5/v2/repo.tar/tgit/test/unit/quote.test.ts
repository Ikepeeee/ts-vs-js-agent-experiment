import assert from "node:assert/strict";
import { test } from "node:test";
import { quotePath } from "../../src/cli/quote.ts";

test("leaves plain paths alone", () => {
  assert.equal(quotePath("d/c.txt"), "d/c.txt");
  assert.equal(quotePath("sp ace.txt"), "sp ace.txt");
  assert.equal(quotePath("-x.txt"), "-x.txt");
});

test("quotes non-ASCII bytes as octal escapes", () => {
  assert.equal(quotePath("日本.txt"), '"\\346\\227\\245\\346\\234\\254.txt"');
});

test("quotes control characters, quotes, and backslashes", () => {
  assert.equal(quotePath("a\tb"), '"a\\tb"');
  assert.equal(quotePath('a"b'), '"a\\"b"');
  assert.equal(quotePath("a\\b"), '"a\\\\b"');
  assert.equal(quotePath("a\x01b"), '"a\\001b"');
});

test("quotes spaces only when asked", () => {
  assert.equal(quotePath("sp ace.txt", { quoteSpace: true }), '"sp ace.txt"');
  assert.equal(quotePath("plain", { quoteSpace: true }), "plain");
});
