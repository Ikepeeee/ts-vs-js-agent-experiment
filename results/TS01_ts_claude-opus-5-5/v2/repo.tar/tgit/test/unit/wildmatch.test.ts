import assert from "node:assert/strict";
import { test } from "node:test";
import { hasWildcard, wildmatch } from "../../src/core/worktree/wildmatch.ts";

test("matches stars, question marks, and brackets", () => {
  assert.ok(wildmatch("*.log", "app.log"));
  assert.ok(!wildmatch("*.log", "app.txt"));
  assert.ok(wildmatch("a?c", "abc"));
  assert.ok(wildmatch("[a-c]x", "bx"));
  assert.ok(!wildmatch("[!a-c]x", "bx"));
  assert.ok(wildmatch("[[:digit:]]*", "1abc"));
  assert.ok(wildmatch("\\*", "*"));
});

test("a star crosses slashes only without the pathname flag", () => {
  assert.ok(wildmatch("*.txt", "d/c.txt"));
  assert.ok(!wildmatch("*.txt", "d/c.txt", { pathname: true }));
  assert.ok(wildmatch("d/*", "d/c.txt", { pathname: true }));
  assert.ok(wildmatch("**/f.txt", "d/e/f.txt", { pathname: true }));
  assert.ok(wildmatch("d/**", "d/e/f.txt", { pathname: true }));
  assert.ok(wildmatch("a/**/b", "a/b", { pathname: true }));
});

test("detects wildcards", () => {
  assert.ok(hasWildcard("*.txt"));
  assert.ok(hasWildcard("a[b]"));
  assert.ok(!hasWildcard("plain/path.txt"));
});
