import assert from "node:assert/strict";
import { test } from "node:test";
import { parseConfig } from "../../src/core/config/config.ts";

test("parses sections, subsections, and values", () => {
  const text = '[core]\n\tfilemode = false\n[Init]\n  defaultBranch = main ; comment\n[remote "Origin"]\n\turl = "a b"\n\tflag\n';
  assert.deepEqual(parseConfig(text), [
    ["core.filemode", "false"],
    ["init.defaultbranch", "main"],
    ["remote.Origin.url", "a b"],
    ["remote.Origin.flag", "true"],
  ]);
});

test("handles escapes, comments, and line continuations", () => {
  const text = '# comment\n[user]\n\tname = "Al \\"Ice\\"" # trailing\n\temail = a\\\n@b\n';
  assert.deepEqual(parseConfig(text), [
    ["user.name", 'Al "Ice"'],
    ["user.email", "a@b"],
  ]);
});
