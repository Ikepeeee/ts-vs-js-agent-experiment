import assert from "node:assert/strict";
import { test } from "node:test";
import { formatDefaultDate } from "../../src/cli/date.ts";
import { cleanupMessage } from "../../src/core/objects/commit.ts";
import { parseDate } from "../../src/core/ident/ident.ts";

test("cleans up commit messages like the real git's whitespace mode", () => {
  assert.equal(cleanupMessage("\n\nsubject  \n\n\n\nbody\t\n# kept\n\n"), "subject\n\nbody\n# kept\n");
  assert.equal(cleanupMessage(" \n\n"), "");
});

test("formats dates in the author's timezone", () => {
  assert.equal(formatDefaultDate(1700000000, "+0000"), "Tue Nov 14 22:13:20 2023 +0000");
  assert.equal(formatDefaultDate(1700000000, "-0700"), "Tue Nov 14 15:13:20 2023 -0700");
  assert.equal(formatDefaultDate(1700000000, "+0530"), "Wed Nov 15 03:43:20 2023 +0530");
  assert.equal(formatDefaultDate(0, "+0000"), "Thu Jan 1 00:00:00 1970 +0000");
});

test("parses the date formats of GIT_AUTHOR_DATE", () => {
  assert.deepEqual(parseDate("1700000000 +0900"), { timestamp: 1700000000, tz: "+0900" });
  assert.deepEqual(parseDate("2023-11-14T22:13:20+01:00"), { timestamp: 1699996400, tz: "+0100" });
  assert.equal(parseDate("yesterday"), null);
});
