import assert from "node:assert/strict";
import { test } from "node:test";
import { IgnoreRules, parsePatterns } from "../../src/core/worktree/ignore.ts";

const rules = (text: string): IgnoreRules => new IgnoreRules([parsePatterns(text)]);

test("skips comments and blank lines", () => {
  assert.deepEqual(parsePatterns("# comment\n\n  \n*.log\n"), [{ pattern: "*.log", negative: false, mustBeDir: false, basenameOnly: true }]);
});

test("matches basenames at any depth and anchored paths from the top", () => {
  const ignore = rules("*.log\n/top.txt\nd/e.txt\n");
  assert.ok(ignore.isIgnored("app.log", false));
  assert.ok(ignore.isIgnored("d/x.log", false));
  assert.ok(ignore.isIgnored("top.txt", false));
  assert.ok(!ignore.isIgnored("d/top.txt", false));
  assert.ok(ignore.isIgnored("d/e.txt", false));
  assert.ok(!ignore.isIgnored("x/d/e.txt", false));
});

test("directory patterns match directories and everything inside them", () => {
  const ignore = rules("build/\n");
  assert.ok(ignore.matches("build", true));
  assert.ok(!ignore.matches("build", false));
  assert.ok(ignore.isIgnored("build/out.txt", false));
  assert.ok(ignore.isIgnored("src/build/out.txt", false));
});

test("the last matching pattern wins, and negation re-includes", () => {
  const ignore = rules("*.txt\n!keep.txt\n");
  assert.ok(ignore.isIgnored("a.txt", false));
  assert.ok(!ignore.isIgnored("keep.txt", false));
});
