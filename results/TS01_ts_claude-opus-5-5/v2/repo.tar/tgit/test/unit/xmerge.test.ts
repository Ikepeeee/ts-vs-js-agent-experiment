import assert from "node:assert/strict";
import { test } from "node:test";
import { mergeContents } from "../../src/core/merge/xmerge.ts";

// Expected results come from the real git's `git merge-file -p -L HEAD -L base -L topic`.
function merge(base: string, ours: string, theirs: string): { text: string; conflicts: number } {
  const result = mergeContents(Buffer.from(base), Buffer.from(ours), Buffer.from(theirs), { ours: "HEAD", theirs: "topic", markerSize: 7 });
  return { text: result.data.toString(), conflicts: result.conflicts };
}

test("merges changes to different lines cleanly", () => {
  assert.deepEqual(merge("1\n2\n3\n4\n5\n6\n7\n", "one\n2\n3\n4\n5\n6\n7\n", "1\n2\n3\n4\n5\n6\nseven\n"), {
    text: "one\n2\n3\n4\n5\n6\nseven\n",
    conflicts: 0,
  });
});

test("marks changes to the same lines as a conflict", () => {
  assert.deepEqual(merge("1\n2\n3\n", "1\nours\n3\n", "1\ntheirs\n3\n"), {
    text: "1\n<<<<<<< HEAD\nours\n=======\ntheirs\n>>>>>>> topic\n3\n",
    conflicts: 1,
  });
});

test("joins conflicts separated by at most three common lines", () => {
  assert.deepEqual(merge("a\nb\nc\n", "x\nsame\ny\n", "z\nsame\nw\n"), {
    text: "<<<<<<< HEAD\nx\nsame\ny\n=======\nz\nsame\nw\n>>>>>>> topic\n",
    conflicts: 1,
  });
});

test("ends each side of a conflict with a newline", () => {
  assert.equal(merge("a\nb", "a\nours", "a\ntheirs").text, "a\n<<<<<<< HEAD\nours\n=======\ntheirs\n>>>>>>> topic\n");
});

test("uses CRLF for conflict markers in CRLF files", () => {
  assert.equal(merge("a\r\nb\r\n", "a\r\nours\r\n", "a\r\ntheirs\r\n").text, "a\r\n<<<<<<< HEAD\r\nours\r\n=======\r\ntheirs\r\n>>>>>>> topic\r\n");
});
