import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { test } from "node:test";
import { EMPTY_STAT, Index, readIndex, writeIndex } from "../../src/core/index/index-file.ts";

test("writes and reads the index, keeping entries in byte order", () => {
  const gitDir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-unit-"));
  try {
    const index = new Index();
    const oid = "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391";
    for (const p of ["日本.txt", "b.txt", "a/b.txt", "a.txt", "sp ace.txt"]) index.set({ path: p, oid, mode: 0o100644, stat: { ...EMPTY_STAT, size: 3 } });
    index.set({ path: "run.sh", oid, mode: 0o100755, stat: EMPTY_STAT });
    writeIndex(gitDir, index);
    const read = readIndex(gitDir);
    assert.deepEqual(
      read.list().map((e) => e.path),
      ["a.txt", "a/b.txt", "b.txt", "run.sh", "sp ace.txt", "日本.txt"],
    );
    assert.equal(read.get("run.sh")?.mode, 0o100755);
    assert.equal(read.get("a.txt")?.stat.size, 3);
    assert.equal(read.changed, false);
    assert.deepEqual([...read.directories()], ["a"]);
  } finally {
    fs.rmSync(gitDir, { recursive: true, force: true });
  }
});

test("a missing index is empty", () => {
  assert.equal(readIndex(path.join(os.tmpdir(), "tgit-no-such-dir")).size, 0);
});

test("writes and reads conflict stages, and resolves them with a stage 0 entry", () => {
  const gitDir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-unit-"));
  try {
    const index = new Index();
    const oid = "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391";
    index.set({ path: "a.txt", oid, mode: 0o100644, stat: EMPTY_STAT });
    index.set({ path: "c.txt", oid, mode: 0o100644, stat: EMPTY_STAT });
    index.setConflict("b.txt", [3, 2].map((stage) => ({ path: "b.txt", oid, mode: 0o100644, stat: EMPTY_STAT, stage })));
    writeIndex(gitDir, index);
    const read = readIndex(gitDir);
    assert.deepEqual(read.unmergedPaths(), ["b.txt"]);
    assert.deepEqual(
      read.allEntries().map((e) => `${e.path} ${e.stage ?? 0}`),
      ["a.txt 0", "b.txt 2", "b.txt 3", "c.txt 0"],
    );
    assert.equal(read.size, 4);
    read.set({ path: "b.txt", oid, mode: 0o100644, stat: EMPTY_STAT });
    assert.deepEqual(read.unmergedPaths(), []);
    assert.deepEqual(read.paths(), ["a.txt", "b.txt", "c.txt"]);
  } finally {
    fs.rmSync(gitDir, { recursive: true, force: true });
  }
});
