import assert from "node:assert/strict";
import { test } from "node:test";
import { formatHunks } from "../../src/core/diff/unified.ts";
import { DIFF_DEFAULTS, MERGE_DEFAULTS, diffLines, isBinary } from "../../src/core/diff/xdiff.ts";

// The expected hunks were produced by `git diff --no-index` (with `--histogram` for the histogram case).
const hunks = (a: string, b: string, options = DIFF_DEFAULTS): string =>
  formatHunks(diffLines(Buffer.from(a), Buffer.from(b), options)).toString();

test("the indent heuristic places an inserted block like the real git", () => {
  const a = "def a():\n    x = 1\n\ndef b():\n    y = 2\n";
  const b = "def a():\n    x = 1\n\ndef c():\n    z = 3\n\ndef b():\n    y = 2\n";
  assert.equal(hunks(a, b), "@@ -1,5 +1,8 @@\n def a():\n     x = 1\n \n+def c():\n+    z = 3\n+\n def b():\n     y = 2\n");
});

test("a last line without a newline is marked", () => {
  assert.equal(hunks("a\nb\nc", "a\nB\nc"), "@@ -1,3 +1,3 @@\n a\n-b\n+B\n c\n\\ No newline at end of file\n");
});

test("empty sides use the line before them in the header", () => {
  assert.equal(hunks("", "x\n"), "@@ -0,0 +1 @@\n+x\n");
  assert.equal(hunks("x\n", ""), "@@ -1 +0,0 @@\n-x\n");
});

test("function names come from the nearest line above the hunk that starts with a letter", () => {
  const a = "int main()\n{\n" + "\tx;\n".repeat(6) + "\ty;\n";
  const b = "int main()\n{\n" + "\tx;\n".repeat(6) + "\tz;\n";
  assert.equal(hunks(a, b), "@@ -6,4 +6,4 @@ int main()\n \tx;\n \tx;\n \tx;\n-\ty;\n+\tz;\n");
});

test("histogram diff anchors on the rarest line", () => {
  assert.equal(hunks("x\nx\nx\n", "x\ny\nx\nx\n", MERGE_DEFAULTS), "@@ -1,3 +1,4 @@\n-x\n+x\n+y\n x\n x\n");
});

test("binary content has a NUL byte in its first 8000 bytes", () => {
  assert.equal(isBinary(Buffer.from([1, 0, 2])), true);
  assert.equal(isBinary(Buffer.concat([Buffer.alloc(8000, 1), Buffer.from([0])])), false);
});
