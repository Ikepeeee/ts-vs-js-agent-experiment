import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { test } from "node:test";
import { formatIdent, parseCommit, parseIdent, serializeCommit } from "../../src/core/objects/commit.ts";
import { hashObject, readObject, writeObject } from "../../src/core/objects/store.ts";
import { parseTree, serializeTree } from "../../src/core/objects/tree.ts";

test("hashes objects like the real git", () => {
  assert.equal(hashObject("blob", Buffer.from("")), "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391");
  assert.equal(hashObject("blob", Buffer.from("a\n")), "78981922613b2afb6025042ff6bd878ac1994e85");
  assert.equal(hashObject("tree", Buffer.alloc(0)), "4b825dc642cb6eb9a060e54bf8d69288fbee4904");
});

test("writes and reads loose objects", () => {
  const gitDir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-unit-"));
  try {
    fs.mkdirSync(path.join(gitDir, "objects"));
    const oid = writeObject(gitDir, "blob", Buffer.from([0, 1, 2, 255]));
    assert.deepEqual(readObject(gitDir, oid), { type: "blob", data: Buffer.from([0, 1, 2, 255]) });
    assert.equal(readObject(gitDir, "0".repeat(40)), null);
  } finally {
    fs.rmSync(gitDir, { recursive: true, force: true });
  }
});

test("orders tree entries with directories sorted as if they ended in a slash", () => {
  const oid = "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391";
  const entries = [
    { mode: "100644", name: "a.txt", oid },
    { mode: "40000", name: "a", oid },
    { mode: "100644", name: "a-b", oid },
  ];
  const parsed = parseTree(serializeTree(entries));
  assert.deepEqual(
    parsed.map((e) => e.name),
    ["a-b", "a.txt", "a"],
  );
  assert.equal(parsed[2]?.mode, "40000");
});

test("round-trips commits and identities", () => {
  const commit = {
    tree: "4b825dc642cb6eb9a060e54bf8d69288fbee4904",
    parents: ["78981922613b2afb6025042ff6bd878ac1994e85"],
    author: "Alice Author <alice@example.com> 1700000000 +0000",
    committer: "Carol Committer <carol@example.com> 1700000000 -0130",
    message: "subject\n\nbody\n",
  };
  assert.deepEqual(parseCommit(serializeCommit(commit)), commit);
  const ident = parseIdent(commit.committer);
  assert.deepEqual(ident, { name: "Carol Committer", email: "carol@example.com", timestamp: 1700000000, tz: "-0130" });
  assert.equal(formatIdent(ident), commit.committer);
});
