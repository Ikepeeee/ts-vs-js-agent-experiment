// Random text files for the fuzz tests: few distinct lines, blank lines, and indentation, so that
// the diff algorithms meet repeated lines, sliders, and indent heuristics.

export function rng(seed: number): () => number {
  let h = seed >>> 0;
  return () => {
    h = (h + 0x6d2b79f5) | 0;
    let t = Math.imul(h ^ (h >>> 15), 1 | h);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const WORDS = ["a", "b", "c", "x", "}", "{", "", "int f()", "  return", "\treturn", "    if (x)", "foo", "bar", "baz"];

function randomLine(rand: () => number, vocabulary: number): string {
  if (rand() < 0.1) return `line ${Math.floor(rand() * 1000)}`;
  return WORDS[Math.floor(rand() * Math.min(vocabulary, WORDS.length))] ?? "";
}

function randomLines(rand: () => number, count: number, vocabulary: number): string[] {
  return Array.from({ length: count }, () => randomLine(rand, vocabulary));
}

function join(rand: () => number, lines: string[]): Buffer {
  if (lines.length === 0) return Buffer.alloc(0);
  return Buffer.from(lines.join("\n") + (rand() < 0.1 ? "" : "\n"));
}

function lengthFor(rand: () => number): number {
  const r = rand();
  if (r < 0.05) return 0;
  if (r < 0.85) return Math.floor(rand() * 40);
  if (r < 0.97) return 100 + Math.floor(rand() * 400);
  return 1000 + Math.floor(rand() * 3000);
}

export function randomFile(rand: () => number): Buffer {
  return join(rand, randomLines(rand, lengthFor(rand), 2 + Math.floor(rand() * WORDS.length)));
}

/** A modified copy of a file: lines inserted, deleted, replaced, and blocks moved. */
export function mutate(rand: () => number, data: Buffer): Buffer {
  const text = data.toString();
  const lines = text === "" ? [] : text.replace(/\n$/, "").split("\n");
  const edits = 1 + Math.floor(rand() * (lines.length > 200 ? 60 : 6));
  for (let e = 0; e < edits; e++) {
    const at = Math.floor(rand() * (lines.length + 1));
    const r = rand();
    if (r < 0.3) lines.splice(at, 0, ...randomLines(rand, 1 + Math.floor(rand() * 4), 8));
    else if (r < 0.6) lines.splice(at, 1 + Math.floor(rand() * 4));
    else if (r < 0.9) lines.splice(at, 1, ...randomLines(rand, 1 + Math.floor(rand() * 3), 8));
    else {
      const block = lines.splice(at, 1 + Math.floor(rand() * 10));
      lines.splice(Math.floor(rand() * (lines.length + 1)), 0, ...block);
    }
  }
  return join(rand, lines);
}
