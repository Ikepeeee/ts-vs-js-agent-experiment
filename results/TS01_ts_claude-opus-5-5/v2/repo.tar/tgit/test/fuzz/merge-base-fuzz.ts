// Compares tgit's merge bases (all of them, in order) with `git merge-base --all` on random
// histories built with `git fast-import`, with criss-cross merges and equal or skewed dates.
// Usage: node test/fuzz/merge-base-fuzz.ts [--count 50] [--seed 1]
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { parseArgs } from "node:util";
import { mergeBases } from "../../src/core/revision/merge-base.ts";
import { rng } from "./random-text.ts";

const { values } = parseArgs({
  options: {
    count: { type: "string", default: "50" },
    seed: { type: "string", default: "1" },
  },
});
const rand = rng(Number(values.seed));
const below = (n: number): number => Math.floor(rand() * n);
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-merge-base-fuzz-"));
const env = { ...process.env, HOME: dir, GIT_CONFIG_NOSYSTEM: "1", LANG: "C", LC_ALL: "C", TZ: "UTC" };
const git = (args: string[], input?: Buffer): string => {
  const result = spawnSync("git", args, { cwd: dir, env, input, maxBuffer: 1 << 30 });
  if (result.status !== 0 && result.status !== 1) throw new Error(`git ${args.join(" ")}: ${result.stderr.toString()}`);
  return result.stdout.toString();
};

git(["init", "-q"]);
const histories: number[][] = [];
let text = "";
let mark = 0;
for (let n = 0; n < Number(values.count); n++) {
  const marks: number[] = [];
  const size = 5 + below(30);
  for (let i = 0; i < size; i++) {
    // A few roots, and merges of up to three earlier commits.
    const parents = i === 0 || rand() < 0.05 ? [] : [...new Set(Array.from({ length: 1 + below(rand() < 0.3 ? 3 : 1) }, () => marks[below(marks.length)] as number))];
    const date = 1700000000 + (rand() < 0.2 ? below(5) : i * 10 + below(rand() < 0.2 ? 100 : 5));
    text += `commit refs/heads/h${n}-${i}\nmark :${++mark}\ncommitter C <c@example.com> ${date} +0000\ndata 2\n${i}\n`;
    parents.forEach((parent, j) => (text += `${j === 0 ? "from" : "merge"} :${parent}\n`));
    if (parents.length === 0) text += "deleteall\n";
    text += "\n";
    marks.push(mark);
  }
  histories.push(marks);
}
const marksFile = path.join(dir, "marks");
git(["fast-import", "--quiet", `--export-marks=${marksFile}`], Buffer.from(text));
// tgit reads loose objects only.
const packDir = path.join(dir, ".git", "objects", "pack");
for (const name of fs.readdirSync(packDir).filter((f) => f.endsWith(".pack"))) {
  const pack = fs.readFileSync(path.join(packDir, name));
  for (const f of fs.readdirSync(packDir)) fs.rmSync(path.join(packDir, f));
  git(["unpack-objects", "-q"], pack);
}
const oids = new Map(
  fs
    .readFileSync(marksFile, "utf8")
    .trim()
    .split("\n")
    .map((line) => [Number(line.slice(1, line.indexOf(" "))), line.slice(line.indexOf(" ") + 1)] as const),
);

let failures = 0;
let checked = 0;
for (const marks of histories) {
  for (let k = 0; k < 10; k++) {
    const one = oids.get(marks[below(marks.length)] as number) as string;
    const two = oids.get(marks[below(marks.length)] as number) as string;
    const expected = git(["merge-base", "--all", one, two]);
    const actual = mergeBases(path.join(dir, ".git"), one, [two]).map((oid) => `${oid}\n`).join("");
    checked++;
    if (expected !== actual) {
      failures++;
      console.log(`mismatch for ${one} ${two} in ${dir}:\nexpected:\n${expected}actual:\n${actual}`);
      if (failures >= 5) break;
    }
  }
}
if (failures === 0) fs.rmSync(dir, { recursive: true, force: true });
console.log(failures === 0 ? `all ${checked} matched` : `${failures} mismatches`);
process.exitCode = failures === 0 ? 0 : 1;
