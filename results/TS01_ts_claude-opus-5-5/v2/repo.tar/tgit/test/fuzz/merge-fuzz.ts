// Compares tgit's merge of two commits (merged tree, conflicted stages) with the real git's
// `merge-tree --write-tree`, which runs the same merge-ort code, on random histories with
// criss-cross merges, built with `git fast-import`.
// Usage: node test/fuzz/merge-fuzz.ts [--count 200] [--seed 1]
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { parseArgs } from "node:util";
import { mergeCommits } from "../../src/core/merge/ort.ts";
import { mergeBases } from "../../src/core/revision/merge-base.ts";
import { mutate, randomFile, rng } from "./random-text.ts";

const { values } = parseArgs({
  options: {
    count: { type: "string", default: "200" },
    seed: { type: "string", default: "1" },
  },
});
const rand = rng(Number(values.seed));
const pick = <T>(items: T[]): T => items[Math.floor(rand() * items.length)] as T;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-merge-fuzz-"));
const gitDir = path.join(dir, ".git");
const env = { ...process.env, HOME: dir, GIT_CONFIG_NOSYSTEM: "1", LANG: "C", LC_ALL: "C", TZ: "UTC" };
const git = (args: string[], input?: Buffer): { status: number | null; stdout: string } => {
  const result = spawnSync("git", args, { cwd: dir, env, input, maxBuffer: 1 << 30 });
  if (result.status !== 0 && result.status !== 1) throw new Error(`git ${args.join(" ")}: ${result.stderr.toString()}`);
  return { status: result.status, stdout: result.stdout.toString() };
};

const PATHS = ["a.txt", "b.txt", "d/c.txt", "d/e/f.txt", "z.bin"];
interface File {
  mode: string;
  data: Buffer;
}
type Files = Map<string, File>;

function randomContent(filePath: string): Buffer {
  if (filePath.endsWith(".bin") && rand() < 0.5) return Buffer.from([0, Math.floor(rand() * 4), 1]);
  return randomFile(rand);
}

/** A commit's files: its parent's with a few paths changed, added, deleted, or given a new mode. */
function change(files: Files): Files {
  const next = new Map(files);
  for (let n = 0; n < 1 + Math.floor(rand() * 3); n++) {
    const filePath = pick(PATHS);
    const old = next.get(filePath);
    const r = rand();
    if (!old) next.set(filePath, { mode: "100644", data: randomContent(filePath) });
    else if (r < 0.1) next.delete(filePath);
    else if (r < 0.2) next.set(filePath, { ...old, mode: old.mode === "100644" ? "100755" : "100644" });
    else next.set(filePath, { ...old, data: filePath.endsWith(".bin") ? randomContent(filePath) : mutate(rand, old.data) });
  }
  return next;
}

/** A merge commit's files: for each path, one parent's version or a change of it. */
function resolution(a: Files, b: Files): Files {
  const next: Files = new Map();
  for (const filePath of PATHS) {
    const version = rand() < 0.5 ? a.get(filePath) : b.get(filePath);
    if (version) next.set(filePath, rand() < 0.2 ? { ...version, data: mutate(rand, version.data) } : version);
  }
  return next;
}

git(["init", "-q"]);
const stream: Buffer[] = [];
let mark = 0;
let date = 1700000000;
const commit = (ref: string, files: Files, parents: number[]): number => {
  const blobs = [...files].map(([filePath, file]) => {
    stream.push(Buffer.from(`blob\nmark :${++mark}\ndata ${file.data.length}\n`), file.data, Buffer.from("\n"));
    return `M ${file.mode} :${mark} ${filePath}\n`;
  });
  date += 1 + Math.floor(rand() * 3) - (rand() < 0.1 ? 5 : 0);
  let text = `commit ${ref}\nmark :${++mark}\ncommitter C <c@example.com> ${date} +0000\ndata 2\nm\n`;
  parents.forEach((parent, i) => (text += `${i === 0 ? "from" : "merge"} :${parent}\n`));
  stream.push(Buffer.from(`${text}deleteall\n${blobs.join("")}\n`));
  return mark;
};

const cases: [number, number][] = [];
for (let n = 0; n < Number(values.count); n++) {
  const commits: { mark: number; files: Files }[] = [];
  const add = (files: Files, parents: number[]): void => {
    commits.push({ mark: commit(`refs/heads/c${n}-${commits.length}`, files, parents), files });
  };
  const rootFiles: Files = new Map();
  for (const filePath of PATHS) if (rand() < 0.6) rootFiles.set(filePath, { mode: "100644", data: randomContent(filePath) });
  add(rootFiles, []);
  if (rand() < 0.4) {
    // A criss-cross: two branches merged into each other, then changed again.
    const x = commits.length;
    for (let k = 0; k < 2 + Math.floor(rand() * 2); k++) add(change((commits[0] as (typeof commits)[number]).files), [(commits[0] as (typeof commits)[number]).mark]);
    const tips = commits.slice(x);
    for (const a of tips) for (const b of tips) if (a !== b) add(resolution(a.files, b.files), [a.mark, b.mark]);
  }
  for (let i = 0; i < 2 + Math.floor(rand() * 7); i++) {
    const parent = pick(commits);
    if (rand() < 0.3 && commits.length > 2) {
      const other = pick(commits);
      if (other !== parent) {
        add(resolution(parent.files, other.files), [parent.mark, other.mark]);
        continue;
      }
    }
    add(change(parent.files), [parent.mark]);
  }
  cases.push([pick(commits).mark, pick(commits).mark]);
}
const marksFile = path.join(dir, "marks");
spawnSync("git", ["fast-import", "--quiet", `--export-marks=${marksFile}`], { cwd: dir, env, input: Buffer.concat(stream) });
// tgit reads loose objects only.
const packDir = path.join(gitDir, "objects", "pack");
for (const name of fs.readdirSync(packDir).filter((f) => f.endsWith(".pack"))) {
  const pack = fs.readFileSync(path.join(packDir, name));
  for (const f of fs.readdirSync(packDir)) fs.rmSync(path.join(packDir, f));
  git(["unpack-objects", "-q"], pack);
}
const oids = new Map(
  fs
    .readFileSync(marksFile, "utf8")
    .trim()
    .split("\n")
    .map((line) => [Number(line.slice(1, line.indexOf(" "))), line.slice(line.indexOf(" ") + 1)] as const),
);

let failures = 0;
let multipleBases = 0;
let conflicted = 0;
for (const [m1, m2] of cases) {
  const ours = oids.get(m1) as string;
  const theirs = oids.get(m2) as string;
  git(["update-ref", "refs/heads/A", ours]);
  git(["update-ref", "refs/heads/B", theirs]);
  const real = git(["merge-tree", "--write-tree", "A", "B"]);
  const expected = real.stdout.split("\n\n")[0] as string;
  const bases = mergeBases(gitDir, ours, [theirs]);
  if (bases.length > 1) multipleBases++;
  if (real.status === 1) conflicted++;
  const result = mergeCommits(gitDir, ours, theirs, bases, { ours: "A", theirs: "B" });
  const stageLines = result.conflicts.flatMap((conflict) =>
    conflict.stages.flatMap((entry, i) => (entry ? [`${entry.mode} ${entry.oid} ${i + 1}\t${conflict.path}`] : [])),
  );
  const actual = [result.tree, ...stageLines].join("\n");
  if (actual !== expected.trimEnd() || (real.status === 1) !== result.conflicts.length > 0) {
    failures++;
    console.log(`mismatch merging ${ours} ${theirs} in ${dir}:\nexpected:\n${real.stdout}\nactual:\n${actual}\n`);
    if (failures >= 5) break;
  }
}
if (failures === 0) fs.rmSync(dir, { recursive: true, force: true });
console.log(failures === 0 ? `all ${cases.length} matched (${conflicted} with conflicts, ${multipleBases} with several merge bases)` : `${failures} mismatches`);
process.exitCode = failures === 0 ? 0 : 1;
