// Compares tgit's `show` of merge commits (the dense combined diff) with the real git's, on random
// merges built with `git fast-import`.
// Usage: node test/fuzz/combined-fuzz.ts [--count 300] [--seed 1]
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { parseArgs } from "node:util";
import { mutate, randomFile, rng } from "./random-text.ts";

const { values } = parseArgs({
  options: {
    count: { type: "string", default: "300" },
    seed: { type: "string", default: "1" },
  },
});
const rand = rng(Number(values.seed));
const pick = <T>(items: T[]): T => items[Math.floor(rand() * items.length)] as T;
const tgit = path.resolve(import.meta.dirname, "../../src/main.ts");
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-combined-fuzz-"));
const env = { ...process.env, HOME: dir, GIT_CONFIG_NOSYSTEM: "1", LANG: "C", LC_ALL: "C", TZ: "UTC" };
const git = (args: string[], input?: Buffer): Buffer => {
  const result = spawnSync("git", args, { cwd: dir, env, input, maxBuffer: 1 << 30 });
  if (result.status !== 0) throw new Error(`git ${args.join(" ")}: ${result.stderr.toString()}`);
  return result.stdout;
};

/** A result built from both sides: runs of lines taken alternately, as a resolution might. */
function interleave(a: Buffer, b: Buffer): Buffer {
  const la = a.toString().split("\n");
  const lb = b.toString().split("\n");
  const out: string[] = [];
  for (let i = 0; i < Math.max(la.length, lb.length); i += 3) out.push(...(rand() < 0.5 ? la : lb).slice(i, i + 3));
  return Buffer.from(out.join("\n"));
}

function resultFor(base: Buffer, sides: Buffer[]): Buffer | null {
  const r = rand();
  if (r < 0.05) return null;
  if (r < 0.35) return mutate(rand, pick(sides));
  if (r < 0.6) return interleave(pick(sides), pick(sides));
  if (r < 0.75) return mutate(rand, base);
  if (r < 0.85) return pick(sides);
  return interleave(mutate(rand, pick(sides)), pick(sides));
}

git(["init", "-q"]);
const stream: Buffer[] = [];
let mark = 0;
const blob = (data: Buffer): number => {
  stream.push(Buffer.from(`blob\nmark :${++mark}\ndata ${data.length}\n`), data, Buffer.from("\n"));
  return mark;
};
const commit = (files: Map<string, Buffer>, parents: number[]): number => {
  const marks = [...files].map(([name, data]) => [name, blob(data)] as const);
  let text = `commit refs/heads/c${mark}\nmark :${++mark}\nauthor A <a@example.com> 1700000000 +0000\n`;
  text += `committer C <c@example.com> 1700000000 +0000\ndata 2\nm\n`;
  parents.forEach((parent, i) => (text += `${i === 0 ? "from" : "merge"} :${parent}\n`));
  text += "deleteall\n";
  for (const [name, m] of marks) text += `M ${pick(["100644", "100644", "100644", "100755"])} :${m} ${name}\n`;
  stream.push(Buffer.from(`${text}\n`));
  return mark;
};

const merges: number[] = [];
for (let n = 0; n < Number(values.count); n++) {
  const numParents = rand() < 0.1 ? 3 : 2;
  const names = ["f.txt", "g.c", "sp ace.txt"].slice(0, 1 + Math.floor(rand() * 3));
  const parentFiles = Array.from({ length: numParents }, () => new Map<string, Buffer>());
  const resultFiles = new Map<string, Buffer>();
  for (const name of names) {
    const base = randomFile(rand);
    const sides = parentFiles.map(() => (rand() < 0.15 ? base : mutate(rand, base)));
    sides.forEach((side, i) => {
      if (rand() > 0.05) parentFiles[i]?.set(name, side);
    });
    const result = resultFor(base, sides);
    if (result) resultFiles.set(name, result);
  }
  const parents = parentFiles.map((files) => commit(files, []));
  merges.push(commit(resultFiles, parents));
}
const marksFile = path.join(dir, "marks");
git(["fast-import", "--quiet", `--export-marks=${marksFile}`], Buffer.concat(stream));
// tgit reads loose objects only.
const packDir = path.join(dir, ".git", "objects", "pack");
for (const name of fs.readdirSync(packDir).filter((f) => f.endsWith(".pack"))) {
  const pack = fs.readFileSync(path.join(packDir, name));
  for (const f of fs.readdirSync(packDir)) fs.rmSync(path.join(packDir, f));
  git(["unpack-objects", "-q"], pack);
}
const oids = new Map(
  fs
    .readFileSync(marksFile, "utf8")
    .trim()
    .split("\n")
    .map((line) => [Number(line.slice(1, line.indexOf(" "))), line.slice(line.indexOf(" ") + 1)] as const),
);

let failures = 0;
for (const m of merges) {
  const oid = oids.get(m) as string;
  const expected = git(["show", oid]);
  const actual = spawnSync(process.execPath, [tgit, "show", oid], { cwd: dir, env, maxBuffer: 1 << 30 });
  if (actual.status !== 0 || !expected.equals(actual.stdout)) {
    failures++;
    console.log(`mismatch for ${oid} in ${dir}`);
    fs.writeFileSync(path.join(dir, `expected-${oid}`), expected);
    fs.writeFileSync(path.join(dir, `actual-${oid}`), actual.stdout);
    if (failures >= 5) break;
  }
}
if (failures === 0) fs.rmSync(dir, { recursive: true, force: true });
console.log(failures === 0 ? `all ${merges.length} matched` : `${failures} mismatches`);
process.exitCode = failures === 0 ? 0 : 1;
