// Compares tgit's line diff with the real git's on random file pairs, using `git diff --no-index`.
// Usage: node test/fuzz/diff-fuzz.ts [--count 500] [--seed 1] [--algorithm myers|histogram]
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { parseArgs } from "node:util";
import { formatHunks } from "../../src/core/diff/unified.ts";
import { DIFF_DEFAULTS, MERGE_DEFAULTS, diffLines } from "../../src/core/diff/xdiff.ts";
import { randomFile, mutate, rng } from "./random-text.ts";

const { values } = parseArgs({
  options: {
    count: { type: "string", default: "500" },
    seed: { type: "string", default: "1" },
    algorithm: { type: "string", default: "myers" },
  },
});
const histogram = values.algorithm === "histogram";
const options = histogram ? MERGE_DEFAULTS : DIFF_DEFAULTS;
const flags = histogram ? ["--histogram", "--no-indent-heuristic"] : [];

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-diff-fuzz-"));
const env = { ...process.env, HOME: dir, GIT_CONFIG_NOSYSTEM: "1", LANG: "C", LC_ALL: "C" };
const rand = rng(Number(values.seed));
let failures = 0;
for (let n = 0; n < Number(values.count); n++) {
  const a = randomFile(rand);
  // Sometimes unrelated files, so that large edit costs reach the heuristics and cost limits.
  const b = rand() < 0.1 ? randomFile(rand) : mutate(rand, a);
  const fa = path.join(dir, "a");
  const fb = path.join(dir, "b");
  fs.writeFileSync(fa, a);
  fs.writeFileSync(fb, b);
  const git = spawnSync("git", ["diff", "--no-index", ...flags, "a", "b"], { cwd: dir, env });
  const out = git.stdout;
  const at = out.indexOf("\n@@ ");
  const expected = at < 0 ? Buffer.alloc(0) : out.subarray(at + 1);
  const actual = formatHunks(diffLines(a, b, options));
  if (!expected.equals(actual)) {
    failures++;
    const keep = path.join(os.tmpdir(), `tgit-diff-fail-${values.seed}-${n}`);
    fs.mkdirSync(keep, { recursive: true });
    fs.writeFileSync(path.join(keep, "a"), a);
    fs.writeFileSync(path.join(keep, "b"), b);
    fs.writeFileSync(path.join(keep, "expected"), expected);
    fs.writeFileSync(path.join(keep, "actual"), actual);
    console.log(`mismatch #${n}: ${keep}`);
    if (failures >= 5) break;
  }
}
fs.rmSync(dir, { recursive: true, force: true });
console.log(failures === 0 ? "all matched" : `${failures} mismatches`);
process.exitCode = failures === 0 ? 0 : 1;
