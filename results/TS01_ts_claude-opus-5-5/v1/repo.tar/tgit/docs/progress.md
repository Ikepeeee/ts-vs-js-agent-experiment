# Progress

## v0.1.0

Implemented `docs/spec-v1.md`:

- Command dispatch and repository discovery (searching upward from the current directory for `.git`).
- `init` (directory argument, `-b`/`--initial-branch`, `-q`, reinitialization).
- Loose blob, tree, and commit objects; `hash-object` (`-w`) and `cat-file` (`-t`, `-s`, `-p`).
- The index (version 2; versions 2 and 3 are read), the root `.gitignore` and `.git/info/exclude`.
- `add` (paths, directories, globs, `.`, `-A`), `ls-files` (`-s`), `status --porcelain`.
- `commit` (`-m`, repeatable, and `-a`), with identities and dates from `GIT_AUTHOR_*`/`GIT_COMMITTER_*`
  (falling back to `user.name`/`user.email`).
- `rev-parse` (ref names, full and abbreviated IDs, `~<n>`, `^<n>`), `log` (default, `--oneline`, `-n`),
  `branch` (list, create, `-d`), `switch` (`<branch>`, `-c`), using git's two-way merge rules.
- Tests: unit tests (`npm test`), differential scenarios for every command under `test/difftest/scenarios/`,
  and random sequences (`npm run difftest` runs the scenarios plus 100 random sequences for each of 3 seeds;
  `node test/difftest/difftest.ts --seeds 1,2,3 --count 500` runs the full set).
- The real git behavior that was confirmed before implementing is in `docs/notes/v1-git-behavior.md`.

Known differences from the real git:

- `status --porcelain` does not detect renames (a non-goal of the specification): where the real git shows
  `R  old -> new` for a staged deletion and a similar staged addition, tgit shows `D  old` and `A  new`.
  The random sequences hit this now and then: with `--count 500`, seeds 1, 2, and 4 pass, and seed 3 fails one
  sequence (`v1-random-0285`) for this reason only. See `docs/notes/v1-rename-detection.md`.
- No reflogs are written. `branch` reads the HEAD reflog written by the real git to describe a detached HEAD.
- Refs are read only as loose files; `packed-refs` is not read (packfiles and `gc` are non-goals).
- Only the `.gitignore` at the top of the working tree is read, as the specification asks; `.gitignore` files in
  subdirectories and `core.excludesFile` are ignored.
- Changes in the working tree are always detected by hashing file contents; the index's stat data is
  written but not used to skip unchanged files.
- `commit` prints only the summary line (`[main (root-commit) abc1234] subject`), not the diffstat.
  Without `-m` it does not start an editor and fails with an empty message.
- Error messages on standard error do not always use the real git's wording.
