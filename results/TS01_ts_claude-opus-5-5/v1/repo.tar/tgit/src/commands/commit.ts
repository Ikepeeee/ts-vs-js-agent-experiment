import fs from "node:fs";
import path from "node:path";
import type { CommandContext } from "../cli/context.ts";
import { usageError } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { identFor } from "../core/ident/ident.ts";
import { indexPath, readIndex, writeIndex, type Index } from "../core/index/index-file.ts";
import { formatIdent, readCommit, serializeCommit } from "../core/objects/commit.ts";
import { writeObject } from "../core/objects/store.ts";
import { writeTreeFromFiles } from "../core/objects/tree.ts";
import { HEADS_PREFIX, readHead, resolveHead, writeRef } from "../core/refs/refs.ts";
import type { Repository } from "../core/repo/repository.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { Abbreviator } from "../core/revision/abbrev.ts";
import { indexFiles } from "../core/status/changes.ts";
import { hashWorktreeFile, toIndexEntry } from "../core/worktree/files.ts";

/** Joins `-m` values the way the real git does: each one becomes its own paragraph. */
function joinMessages(messages: readonly string[]): string {
  let text = "";
  for (const message of messages) {
    if (text !== "") text += "\n";
    text += message;
    if (!text.endsWith("\n")) text += "\n";
  }
  return text;
}

/**
 * The real git's "whitespace" cleanup: strips trailing whitespace from each line, collapses runs
 * of blank lines, and drops blank lines at the start and the end.
 */
export function cleanupMessage(text: string): string {
  const lines = text.split("\n").map((line) => line.replace(/\s+$/, ""));
  const kept: string[] = [];
  for (const line of lines) {
    if (line === "" && (kept.length === 0 || kept.at(-1) === "")) continue;
    kept.push(line);
  }
  while (kept.at(-1) === "") kept.pop();
  return kept.length === 0 ? "" : `${kept.join("\n")}\n`;
}

/** Updates the index with the working tree's version of every tracked file (`commit -a`). */
function stageTrackedFiles(repo: Repository, index: Index): void {
  const filemode = repo.config.getBool("core.filemode", true);
  for (const entry of index.list()) {
    const file = hashWorktreeFile(repo.gitDir, path.join(repo.workTree, entry.path), { filemode, previousMode: entry.mode, write: true });
    if (file) index.set(toIndexEntry(entry.path, file));
    else index.delete(entry.path);
  }
}

export function commit(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [
    { name: "message", short: "m", long: "message", takesValue: true },
    { name: "all", short: "a", long: "all" },
  ]);
  if (parsed.positionals.length > 0) throw usageError("committing only some paths is not supported");
  const repo = requireRepository(ctx.cwd, ctx.env);
  const index = readIndex(repo.gitDir);
  const all = hasOption(parsed, "all");
  if (all) stageTrackedFiles(repo, index);

  const tree = writeTreeFromFiles(repo.gitDir, indexFiles(index));
  // Without -a the real git refreshes and writes the index even when the commit fails.
  if (!all && (index.changed || !fs.existsSync(indexPath(repo.gitDir)))) writeIndex(repo.gitDir, index);

  const parent = resolveHead(repo.gitDir);
  const parentTree = parent === null ? null : readCommit(repo.gitDir, parent)?.tree;
  if (tree === parentTree || (parent === null && index.size === 0)) {
    ctx.stdout("nothing to commit, working tree clean\n");
    return 1;
  }
  const message = cleanupMessage(joinMessages(parsed.options.get("message") ?? []));
  if (message === "") {
    ctx.stderr("Aborting commit due to empty commit message.\n");
    return 1;
  }

  const oid = writeObject(
    repo.gitDir,
    "commit",
    serializeCommit({
      tree,
      parents: parent === null ? [] : [parent],
      author: formatIdent(identFor("AUTHOR", repo, ctx.env)),
      committer: formatIdent(identFor("COMMITTER", repo, ctx.env)),
      message,
    }),
  );
  const head = readHead(repo.gitDir);
  writeRef(repo.gitDir, head.kind === "branch" ? head.ref : "HEAD", oid);
  if (all) writeIndex(repo.gitDir, index);

  const where = head.kind === "branch" ? head.ref.replace(HEADS_PREFIX, "") : "detached HEAD";
  const root = parent === null ? " (root-commit)" : "";
  ctx.stdout(`[${where}${root} ${new Abbreviator(repo.gitDir).abbreviate(oid)}] ${message.split("\n")[0]}\n`);
  return 0;
}
