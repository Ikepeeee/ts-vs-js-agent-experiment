import type { CommandContext } from "../cli/context.ts";
import { usageError } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { quotePath } from "../cli/quote.ts";
import { readIndex } from "../core/index/index-file.ts";
import { comparePaths } from "../core/paths.ts";
import { resolveHead } from "../core/refs/refs.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { commitFiles, diffFiles, indexFiles, worktreeFiles } from "../core/status/changes.ts";
import { IgnoreRules } from "../core/worktree/ignore.ts";
import { scanWorktree } from "../core/worktree/scan.ts";

/** `git status --porcelain`: paths are always relative to the top of the working tree. */
export function status(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "porcelain", long: "porcelain" }]);
  if (!hasOption(parsed, "porcelain")) throw usageError("only --porcelain is supported");
  const repo = requireRepository(ctx.cwd, ctx.env);
  const index = readIndex(repo.gitDir);
  const files = indexFiles(index);
  const staged = diffFiles(commitFiles(repo.gitDir, resolveHead(repo.gitDir)), files);
  const unstaged = diffFiles(files, worktreeFiles(repo, index));

  const quote = (filePath: string): string => quotePath(filePath, { quoteSpace: true });
  const changed = [...new Set([...staged.keys(), ...unstaged.keys()])].sort(comparePaths);
  const lines = changed.map((filePath) => `${staged.get(filePath) ?? " "}${unstaged.get(filePath) ?? " "} ${quote(filePath)}\n`);
  const { untracked } = scanWorktree(repo, index, IgnoreRules.load(repo), { collapseDirectories: true });
  for (const filePath of untracked.sort(comparePaths)) lines.push(`?? ${quote(filePath)}\n`);
  ctx.stdout(lines.join(""));
  return 0;
}
