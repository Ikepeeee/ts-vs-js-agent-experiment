import type { CommandContext } from "../cli/context.ts";
import { ExitError, fatal } from "../cli/errors.ts";
import { formatDefaultDate } from "../cli/date.ts";
import { parseIdent, type Commit } from "../core/objects/commit.ts";
import { HEADS_PREFIX, readHead, resolveHead } from "../core/refs/refs.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { Abbreviator } from "../core/revision/abbrev.ts";
import { resolveCommit } from "../core/revision/resolve.ts";
import { walkHistory } from "../core/revision/walk.ts";

interface LogOptions {
  oneline: boolean;
  maxCount: number;
  revisions: string[];
}

function parseCount(text: string): number {
  if (!/^\s*[+-]?\d+$/.test(text)) throw fatal(`'${text}': not an integer`);
  const count = Number(text);
  return count < 0 ? Infinity : count;
}

/** Parses the arguments like the real git's revision options, which have their own error messages. */
function parseLogArgs(args: readonly string[]): LogOptions {
  const options: LogOptions = { oneline: false, maxCount: Infinity, revisions: [] };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i] as string;
    if (arg === "--oneline") {
      options.oneline = true;
    } else if (arg === "-n" || arg === "--max-count") {
      const value = args[++i];
      if (value === undefined) throw new ExitError(`error: ${arg} requires an argument`, 128);
      options.maxCount = parseCount(value);
    } else if (arg.startsWith("--max-count=")) {
      options.maxCount = parseCount(arg.slice("--max-count=".length));
    } else if (arg.startsWith("-n")) {
      options.maxCount = parseCount(arg.slice(2));
    } else if (/^-\d+$/.test(arg)) {
      options.maxCount = parseCount(arg.slice(1));
    } else if (arg.startsWith("-")) {
      throw fatal(`unrecognized argument: ${arg}`);
    } else {
      options.revisions.push(arg);
    }
  }
  return options;
}

/** The message lines without the blank lines at the start and the end. */
function messageLines(commit: Commit): string[] {
  const lines = commit.message.split("\n");
  while (lines.length > 0 && (lines[0] as string).trim() === "") lines.shift();
  while (lines.length > 0 && (lines.at(-1) as string).trim() === "") lines.pop();
  return lines;
}

/** The subject: the lines of the first paragraph, joined with spaces. */
function subject(lines: readonly string[]): string {
  const end = lines.indexOf("");
  return (end < 0 ? lines : lines.slice(0, end)).map((line) => line.trim()).join(" ");
}

export function log(ctx: CommandContext): number {
  const repo = requireRepository(ctx.cwd, ctx.env);
  const options = parseLogArgs(ctx.args);
  const starts: string[] = [];
  for (const revision of options.revisions) {
    const oid = resolveCommit(repo.gitDir, revision);
    if (oid === null) throw fatal(`ambiguous argument '${revision}': unknown revision or path not in the working tree.`);
    starts.push(oid);
  }
  if (options.revisions.length === 0) {
    const head = resolveHead(repo.gitDir);
    if (head === null) {
      const current = readHead(repo.gitDir);
      const name = current.kind === "branch" ? current.ref.replace(HEADS_PREFIX, "") : "HEAD";
      throw fatal(`your current branch '${name}' does not have any commits yet`);
    }
    starts.push(head);
  }

  const abbreviator = new Abbreviator(repo.gitDir);
  const entries: string[] = [];
  for (const { oid, commit } of walkHistory(repo.gitDir, starts)) {
    if (entries.length >= options.maxCount) break;
    const lines = messageLines(commit);
    if (options.oneline) {
      entries.push(`${abbreviator.abbreviate(oid)} ${subject(lines)}\n`);
      continue;
    }
    const author = parseIdent(commit.author);
    const body = lines.map((line) => `    ${line}\n`).join("");
    entries.push(`commit ${oid}\nAuthor: ${author.name} <${author.email}>\nDate:   ${formatDefaultDate(author.timestamp, author.tz)}\n\n${body}`);
  }
  ctx.stdout(entries.join(options.oneline ? "" : "\n"));
  return 0;
}
