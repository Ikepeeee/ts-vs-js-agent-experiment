import type { CommandContext } from "../cli/context.ts";
import { fatal } from "../cli/errors.ts";
import { lastValue, parseOptions } from "../cli/options.ts";
import { quotePath } from "../cli/quote.ts";
import { switchTrees, type CheckoutProblems } from "../core/checkout/two-way.ts";
import { readIndex, writeIndex } from "../core/index/index-file.ts";
import { comparePaths } from "../core/paths.ts";
import { HEADS_PREFIX, isValidBranchName, readHead, readRef, resolveHead, setHeadToBranch, writeRef } from "../core/refs/refs.ts";
import { requireRepository } from "../core/repo/repository.ts";
import { resolveCommit, resolveRevision } from "../core/revision/resolve.ts";
import { commitFiles, diffFiles, worktreeFiles } from "../core/status/changes.ts";
import { IgnoreRules } from "../core/worktree/ignore.ts";

function reportProblems(ctx: CommandContext, problems: CheckoutProblems): void {
  const section = (paths: string[], what: string, advice: string): void => {
    if (paths.length === 0) return;
    ctx.stderr(`error: ${what}\n${paths.map((p) => `\t${p}\n`).join("")}${advice}\n`);
  };
  section(
    problems.localChanges,
    "Your local changes to the following files would be overwritten by checkout:",
    "Please commit your changes or stash them before you switch branches.",
  );
  section(
    problems.untrackedOverwritten,
    "The following untracked working tree files would be overwritten by checkout:",
    "Please move or remove them before you switch branches.",
  );
  section(
    problems.untrackedRemoved,
    "The following untracked working tree files would be removed by checkout:",
    "Please move or remove them before you switch branches.",
  );
  ctx.stderr("Aborting\n");
}

/** Resolves the branch to switch to, failing like the real git for anything that is not a branch. */
function existingBranch(gitDir: string, name: string): string {
  const ref = HEADS_PREFIX + name;
  if (isValidBranchName(name) && readRef(gitDir, ref) !== null) return ref;
  if (resolveRevision(gitDir, name) !== null) throw fatal(`a branch is expected, got '${name}'`);
  throw fatal(`invalid reference: ${name}`);
}

export function switchBranch(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "create", short: "c", long: "create", takesValue: true }]);
  const repo = requireRepository(ctx.cwd, ctx.env);
  const newBranch = lastValue(parsed, "create");
  const [target, ...rest] = parsed.positionals;
  if (rest.length > 0) throw fatal("only one reference expected");

  let ref: string;
  let targetOid: string | null;
  if (newBranch !== undefined) {
    if (!isValidBranchName(newBranch)) throw fatal(`'${newBranch}' is not a valid branch name`);
    ref = HEADS_PREFIX + newBranch;
    if (readRef(repo.gitDir, ref) !== null) throw fatal(`a branch named '${newBranch}' already exists`);
    targetOid = target === undefined ? resolveHead(repo.gitDir) : resolveCommit(repo.gitDir, target);
    if (target !== undefined && targetOid === null) throw fatal(`invalid reference: ${target}`);
  } else {
    if (target === undefined) throw fatal("missing branch or commit argument");
    ref = existingBranch(repo.gitDir, target);
    targetOid = readRef(repo.gitDir, ref);
  }

  const index = readIndex(repo.gitDir);
  const headOid = resolveHead(repo.gitDir);
  const newFiles = commitFiles(repo.gitDir, targetOid);
  const problems = switchTrees(repo, index, IgnoreRules.load(repo), commitFiles(repo.gitDir, headOid), newFiles);
  if (problems) {
    reportProblems(ctx, problems);
    return 1;
  }
  if (targetOid !== null) writeIndex(repo.gitDir, index);
  if (newBranch !== undefined && targetOid !== null) writeRef(repo.gitDir, ref, targetOid);

  const head = readHead(repo.gitDir);
  const name = ref.slice(HEADS_PREFIX.length);
  if (newBranch !== undefined) ctx.stderr(`Switched to a new branch '${name}'\n`);
  else if (head.kind === "branch" && head.ref === ref) ctx.stderr(`Already on '${name}'\n`);
  else ctx.stderr(`Switched to branch '${name}'\n`);
  setHeadToBranch(repo.gitDir, ref);

  // Like the real git, list the local changes carried over to the new branch.
  const changes = diffFiles(newFiles, worktreeFiles(repo, index));
  const lines = [...changes].sort(([a], [b]) => comparePaths(a, b)).map(([filePath, kind]) => `${kind}\t${quotePath(filePath)}\n`);
  ctx.stdout(lines.join(""));
  return 0;
}
