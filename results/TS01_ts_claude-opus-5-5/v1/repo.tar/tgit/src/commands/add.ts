import fs from "node:fs";
import path from "node:path";
import type { CommandContext } from "../cli/context.ts";
import { fatal } from "../cli/errors.ts";
import { hasOption, parseOptions } from "../cli/options.ts";
import { readIndex, writeIndex } from "../core/index/index-file.ts";
import { matchesItem, parsePathspecs, type PathspecItem } from "../core/pathspec/pathspec.ts";
import { requireRepository, worktreePrefix } from "../core/repo/repository.ts";
import { hashWorktreeFile, toIndexEntry } from "../core/worktree/files.ts";
import { IgnoreRules } from "../core/worktree/ignore.ts";
import { scanWorktree } from "../core/worktree/scan.ts";

/**
 * Whether an ignored path should be reported for a pathspec: the real git reports it when the
 * pathspec names it, or names something inside it (comparing only the part before any wildcard).
 */
function namesIgnoredPath(item: PathspecItem, ignoredPath: string): boolean {
  const wildcardAt = item.path.search(/[*?[\\]/);
  const literal = wildcardAt < 0 ? item.path : item.path.slice(0, wildcardAt);
  return literal === ignoredPath || literal.startsWith(`${ignoredPath}/`);
}

export function add(ctx: CommandContext): number {
  const parsed = parseOptions(ctx.args, [{ name: "all", short: "A", long: "all" }]);
  const repo = requireRepository(ctx.cwd, ctx.env);
  if (parsed.positionals.length === 0 && !hasOption(parsed, "all")) {
    ctx.stderr("Nothing specified, nothing added.\n");
    return 0;
  }
  const items = parsePathspecs(parsed.positionals, worktreePrefix(repo, ctx.cwd), repo.workTree);
  const selected = (filePath: string): boolean => items.length === 0 || items.some((item) => matchesItem(item, filePath));

  const index = readIndex(repo.gitDir);
  const scan = scanWorktree(repo, index, IgnoreRules.load(repo), { collapseDirectories: false });
  const tracked = index.list().map((entry) => entry.path);

  // Like the real git, fail before changing anything if a pathspec matches nothing.
  for (const item of items) {
    const seen = tracked.some((p) => matchesItem(item, p)) || scan.untracked.some((p) => matchesItem(item, p));
    if (!seen && item.path !== "" && !fs.existsSync(path.join(repo.workTree, item.path))) {
      throw fatal(`pathspec '${item.original}' did not match any files`);
    }
  }

  const filemode = repo.config.getBool("core.filemode", true);
  for (const filePath of [...tracked, ...scan.untracked]) {
    if (!selected(filePath)) continue;
    const previous = index.get(filePath);
    const file = hashWorktreeFile(repo.gitDir, path.join(repo.workTree, filePath), { filemode, previousMode: previous?.mode, write: true });
    if (file) index.set(toIndexEntry(filePath, file));
    else index.delete(filePath);
  }
  if (index.changed) writeIndex(repo.gitDir, index);

  const ignored = scan.ignored.filter((p) => items.some((item) => namesIgnoredPath(item, p)));
  if (ignored.length > 0) {
    ctx.stderr(`The following paths are ignored by one of your .gitignore files:\n${ignored.join("\n")}\n`);
    ctx.stderr("hint: Use -f if you really want to add them.\n");
    return 1;
  }
  return 0;
}
