import path from "node:path";
import type { Index } from "../index/index-file.ts";
import { readCommit } from "../objects/commit.ts";
import { flattenTree, type FileEntry } from "../objects/tree.ts";
import type { Repository } from "../repo/repository.ts";
import { hashWorktreeFile } from "../worktree/files.ts";

/** How a path differs between two sides: Added, Modified, Deleted, or Type changed. */
export type ChangeKind = "A" | "M" | "D" | "T";

/** The index mode as a tree mode string, e.g. 0o100644 -> "100644". */
export function treeMode(indexMode: number): string {
  return indexMode.toString(8);
}

/** The file type part of a mode (regular file, symlink, gitlink), as in S_IFMT. */
function fileType(mode: string): string {
  return mode.slice(0, -3);
}

function compareEntries(from: FileEntry, to: FileEntry): ChangeKind | null {
  if (fileType(from.mode) !== fileType(to.mode)) return "T";
  return from.mode !== to.mode || from.oid !== to.oid ? "M" : null;
}

/** The files of a commit's tree, keyed by path; empty for null (an unborn branch). */
export function commitFiles(gitDir: string, commitOid: string | null): Map<string, FileEntry> {
  if (commitOid === null) return new Map();
  const commit = readCommit(gitDir, commitOid);
  if (!commit) throw new Error(`not a commit: ${commitOid}`);
  return flattenTree(gitDir, commit.tree);
}

/** The files recorded in the index, keyed by path. */
export function indexFiles(index: Index): Map<string, FileEntry> {
  return new Map(index.list().map((e) => [e.path, { mode: treeMode(e.mode), oid: e.oid }]));
}

/** Compares two sets of files (e.g. HEAD and the index). */
export function diffFiles(from: Map<string, FileEntry>, to: Map<string, FileEntry>): Map<string, ChangeKind> {
  const changes = new Map<string, ChangeKind>();
  for (const [filePath, entry] of to) {
    const old = from.get(filePath);
    const kind = old ? compareEntries(old, entry) : "A";
    if (kind) changes.set(filePath, kind);
  }
  for (const filePath of from.keys()) if (!to.has(filePath)) changes.set(filePath, "D");
  return changes;
}

/**
 * Reads the working tree files of the index entries. A file that is missing, or that is no longer
 * a regular file or a symlink, is absent from the result.
 */
export function worktreeFiles(repo: Repository, index: Index): Map<string, FileEntry> {
  const filemode = repo.config.getBool("core.filemode", true);
  const files = new Map<string, FileEntry>();
  for (const entry of index.list()) {
    const file = hashWorktreeFile(repo.gitDir, path.join(repo.workTree, entry.path), { filemode, previousMode: entry.mode, write: false });
    if (file) files.set(entry.path, { mode: treeMode(file.mode), oid: file.oid });
  }
  return files;
}
