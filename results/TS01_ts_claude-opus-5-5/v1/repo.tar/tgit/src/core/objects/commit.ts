import { readObject } from "./store.ts";

export interface Commit {
  tree: string;
  parents: string[];
  /** Identity lines as stored: "Name <email> 1700000000 +0000". */
  author: string;
  committer: string;
  message: string;
}

export function parseCommit(data: Buffer): Commit {
  const text = data.toString("utf8");
  const end = text.indexOf("\n\n");
  const headerText = end < 0 ? text : text.slice(0, end);
  const commit: Commit = { tree: "", parents: [], author: "", committer: "", message: end < 0 ? "" : text.slice(end + 2) };
  for (const line of headerText.split("\n")) {
    const space = line.indexOf(" ");
    const key = line.slice(0, space);
    const value = line.slice(space + 1);
    if (key === "tree") commit.tree = value;
    else if (key === "parent") commit.parents.push(value);
    else if (key === "author") commit.author = value;
    else if (key === "committer") commit.committer = value;
  }
  return commit;
}

export function serializeCommit(commit: Commit): Buffer {
  const lines = [`tree ${commit.tree}`, ...commit.parents.map((p) => `parent ${p}`)];
  lines.push(`author ${commit.author}`, `committer ${commit.committer}`);
  return Buffer.from(`${lines.join("\n")}\n\n${commit.message}`, "utf8");
}

/** Reads a commit, or returns null if the object is missing or is not a commit. */
export function readCommit(gitDir: string, oid: string): Commit | null {
  const object = readObject(gitDir, oid);
  return object?.type === "commit" ? parseCommit(object.data) : null;
}

export interface Ident {
  name: string;
  email: string;
  timestamp: number;
  tz: string;
}

/** Parses an identity line: "Name <email> 1700000000 +0000". */
export function parseIdent(line: string): Ident {
  const match = /^(.*?) ?<([^>]*)> ?(\d+)? ?([+-]\d+)?$/.exec(line);
  if (!match) return { name: line, email: "", timestamp: 0, tz: "+0000" };
  return { name: match[1] as string, email: match[2] as string, timestamp: Number(match[3] ?? 0), tz: match[4] ?? "+0000" };
}

export function formatIdent(ident: Ident): string {
  return `${ident.name} <${ident.email}> ${ident.timestamp} ${ident.tz}`;
}
