import { comparePaths } from "../paths.ts";
import { readObject, writeObject } from "./store.ts";

/** Modes as the real git writes them in trees. */
export const MODE_FILE = "100644";
export const MODE_EXECUTABLE = "100755";
export const MODE_SYMLINK = "120000";
export const MODE_TREE = "40000";

export interface TreeEntry {
  mode: string;
  name: string;
  oid: string;
}

export function parseTree(data: Buffer): TreeEntry[] {
  const entries: TreeEntry[] = [];
  let pos = 0;
  while (pos < data.length) {
    const space = data.indexOf(0x20, pos);
    const nul = data.indexOf(0, space);
    entries.push({
      mode: data.subarray(pos, space).toString(),
      name: data.subarray(space + 1, nul).toString("utf8"),
      oid: data.subarray(nul + 1, nul + 21).toString("hex"),
    });
    pos = nul + 21;
  }
  return entries;
}

/** Tree order: names compare bytewise, with directories compared as if their name ended in "/". */
function treeSortKey(entry: TreeEntry): string {
  return entry.mode === MODE_TREE ? `${entry.name}/` : entry.name;
}

export function serializeTree(entries: readonly TreeEntry[]): Buffer {
  const sorted = [...entries].sort((a, b) => comparePaths(treeSortKey(a), treeSortKey(b)));
  return Buffer.concat(
    sorted.map((e) => Buffer.concat([Buffer.from(`${e.mode} ${e.name}\0`, "utf8"), Buffer.from(e.oid, "hex")])),
  );
}

export function readTree(gitDir: string, oid: string): TreeEntry[] {
  const object = readObject(gitDir, oid);
  if (!object || object.type !== "tree") throw new Error(`not a tree: ${oid}`);
  return parseTree(object.data);
}

/** A file in a flattened tree. */
export interface FileEntry {
  mode: string;
  oid: string;
}

/** Lists every file (non-tree entry) under a tree, keyed by its full path. */
export function flattenTree(gitDir: string, oid: string, prefix = "", into = new Map<string, FileEntry>()): Map<string, FileEntry> {
  for (const entry of readTree(gitDir, oid)) {
    const fullPath = prefix + entry.name;
    if (entry.mode === MODE_TREE) flattenTree(gitDir, entry.oid, `${fullPath}/`, into);
    else into.set(fullPath, { mode: entry.mode, oid: entry.oid });
  }
  return into;
}

/** Writes the trees for a set of files (keyed by full path) and returns the root tree's ID. */
export function writeTreeFromFiles(gitDir: string, files: Iterable<[string, FileEntry]>): string {
  interface Dir {
    files: TreeEntry[];
    dirs: Map<string, Dir>;
  }
  const root: Dir = { files: [], dirs: new Map() };
  for (const [filePath, file] of files) {
    const parts = filePath.split("/");
    const name = parts.pop() as string;
    let dir = root;
    for (const part of parts) {
      let child = dir.dirs.get(part);
      if (!child) {
        child = { files: [], dirs: new Map() };
        dir.dirs.set(part, child);
      }
      dir = child;
    }
    dir.files.push({ mode: file.mode, name, oid: file.oid });
  }
  const write = (dir: Dir): string => {
    const entries = [...dir.files];
    for (const [name, child] of dir.dirs) entries.push({ mode: MODE_TREE, name, oid: write(child) });
    return writeObject(gitDir, "tree", serializeTree(entries));
  };
  return write(root);
}
