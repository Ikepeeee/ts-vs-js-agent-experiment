import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { comparePaths } from "../paths.ts";

/** File metadata cached in the index, used by the real git to detect changes quickly. */
export interface StatData {
  ctimeSec: number;
  ctimeNsec: number;
  mtimeSec: number;
  mtimeNsec: number;
  dev: number;
  ino: number;
  uid: number;
  gid: number;
  size: number;
}

export interface IndexEntry {
  path: string;
  oid: string;
  /** The mode as a number, e.g. 0o100644. */
  mode: number;
  stat: StatData;
}

export const EMPTY_STAT: StatData = { ctimeSec: 0, ctimeNsec: 0, mtimeSec: 0, mtimeNsec: 0, dev: 0, ino: 0, uid: 0, gid: 0, size: 0 };

/** The staging area (`.git/index`), holding one entry per path. */
export class Index {
  private readonly entries = new Map<string, IndexEntry>();
  /** Whether entries were added, removed, or changed since the index was read. */
  changed = false;

  get(filePath: string): IndexEntry | undefined {
    return this.entries.get(filePath);
  }

  has(filePath: string): boolean {
    return this.entries.has(filePath);
  }

  get size(): number {
    return this.entries.size;
  }

  set(entry: IndexEntry): void {
    const old = this.entries.get(entry.path);
    if (!old || old.oid !== entry.oid || old.mode !== entry.mode) this.changed = true;
    this.entries.set(entry.path, entry);
  }

  delete(filePath: string): void {
    if (this.entries.delete(filePath)) this.changed = true;
  }

  /** The entries in index order (bytewise by path). */
  list(): IndexEntry[] {
    return [...this.entries.values()].sort((a, b) => comparePaths(a.path, b.path));
  }

  /** Every directory that contains at least one entry, e.g. "d" and "d/e" for "d/e/f.txt". */
  directories(): Set<string> {
    const dirs = new Set<string>();
    for (const filePath of this.entries.keys()) {
      for (let slash = filePath.indexOf("/"); slash >= 0; slash = filePath.indexOf("/", slash + 1)) {
        dirs.add(filePath.slice(0, slash));
      }
    }
    return dirs;
  }
}

export function indexPath(gitDir: string): string {
  return path.join(gitDir, "index");
}

/** Reads `.git/index` (versions 2 and 3); a missing file is an empty index. */
export function readIndex(gitDir: string): Index {
  const index = new Index();
  let data: Buffer;
  try {
    data = fs.readFileSync(indexPath(gitDir));
  } catch {
    return index;
  }
  if (data.toString("latin1", 0, 4) !== "DIRC") throw new Error("index file corrupt");
  const version = data.readUInt32BE(4);
  if (version !== 2 && version !== 3) throw new Error(`index version ${version} is not supported`);
  const count = data.readUInt32BE(8);
  let pos = 12;
  for (let i = 0; i < count; i++) {
    const word = (n: number): number => data.readUInt32BE(pos + n * 4);
    const stat: StatData = {
      ctimeSec: word(0),
      ctimeNsec: word(1),
      mtimeSec: word(2),
      mtimeNsec: word(3),
      dev: word(4),
      ino: word(5),
      uid: word(7),
      gid: word(8),
      size: word(9),
    };
    const mode = word(6);
    const oid = data.toString("hex", pos + 40, pos + 60);
    const flags = data.readUInt16BE(pos + 60);
    const nameStart = pos + 62 + (flags & 0x4000 ? 2 : 0);
    const nameEnd = data.indexOf(0, nameStart);
    const entryPath = data.toString("utf8", nameStart, nameEnd);
    // Entries with a stage (merge conflicts) are not produced by this version; keep stage 0 only.
    if (((flags >> 12) & 3) === 0) index.set({ path: entryPath, oid, mode, stat });
    pos += (nameEnd - pos + 8) & ~7;
  }
  index.changed = false;
  return index;
}

/** Writes `.git/index` in version 2, through a lock file. */
export function writeIndex(gitDir: string, index: Index): void {
  const entries = index.list();
  const parts: Buffer[] = [];
  const header = Buffer.alloc(12);
  header.write("DIRC", 0, "latin1");
  header.writeUInt32BE(2, 4);
  header.writeUInt32BE(entries.length, 8);
  parts.push(header);
  for (const entry of entries) {
    const name = Buffer.from(entry.path, "utf8");
    const length = (62 + name.length + 8) & ~7;
    const buf = Buffer.alloc(length);
    const s = entry.stat;
    const words = [s.ctimeSec, s.ctimeNsec, s.mtimeSec, s.mtimeNsec, s.dev, s.ino, entry.mode, s.uid, s.gid, s.size];
    words.forEach((value, i) => buf.writeUInt32BE(value >>> 0, i * 4));
    buf.write(entry.oid, 40, "hex");
    buf.writeUInt16BE(Math.min(name.length, 0xfff), 60);
    name.copy(buf, 62);
    parts.push(buf);
  }
  const body = Buffer.concat(parts);
  const checksum = createHash("sha1").update(body).digest();
  const lock = `${indexPath(gitDir)}.lock`;
  fs.writeFileSync(lock, Buffer.concat([body, checksum]));
  fs.renameSync(lock, indexPath(gitDir));
  index.changed = false;
}
