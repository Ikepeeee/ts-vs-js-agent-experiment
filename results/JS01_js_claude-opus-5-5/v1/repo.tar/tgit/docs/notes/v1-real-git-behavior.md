# Real git behavior confirmed for v1 (git 2.47.3)

Everything below was checked by running the real git under the fixed test environment.

## Dispatch and errors

- Unknown command: exit 1. No command at all: exit 1.
- A command that needs a repository, run outside one: `fatal: not a git repository (or any of the parent directories): .git`, exit 128.
- Option parsing errors (unknown option, missing value): usage on stderr, exit 129.

## init

- Output: `Initialized empty Git repository in <real path>/.git/`, or `Reinitialized existing Git repository in ...` when `HEAD` already exists.
- Re-init with `-b` keeps `HEAD` and warns `re-init: ignored --initial-branch=<name>` on stderr.
- `-b` without a value: exit 129. Two directories: exit 129.
- `config --local --list`: `core.repositoryformatversion=0`, `core.filemode=true`, `core.bare=false`, `core.logallrefupdates=true`.

## hash-object / cat-file

- `hash-object` works outside a repository; `-w` outside one exits 128.
- Symlinks are followed (the target file's content is hashed). A directory: exit 128. A missing file: exit 128, after the IDs of the earlier files were printed.
- No file arguments: prints nothing, exit 0.
- `cat-file` without arguments, with two of `-t`/`-s`/`-p`, without an object, or with extra arguments: exit 129.
- Unknown revision: `fatal: Not a valid object name <rev>`, exit 128. A well-formed 40-hex ID of a missing object: exit 128.
- `cat-file -p <tree>` prints `ls-tree` lines (`%06o %s %s\t<path>`), with paths C-quoted (spaces are not quoted).
- Abbreviated IDs need at least 4 hex digits.

## ls-files

- Paths are relative to the current directory and limited to it; C-quoted, spaces not quoted.

## status --porcelain

- Paths are always relative to the repository root, C-quoted, and **spaces force quoting** (`?? "sp ace.txt"`).
- Change entries (sorted by path) come before untracked entries (sorted by path, directories as `dir/`).
- An untracked directory is shown as `dir/` only if it contains a non-ignored file; directories with only ignored files are not shown.
- `T` marks a change between a regular file and a symlink; an executable-bit change is `M`.
- A tracked file deleted from the index and still on disk shows as `D ` plus `?? path`.

## add

- No arguments: `Nothing specified, nothing added.` on stderr, exit 0.
- A pathspec that matches neither the index nor an existing path: `fatal: pathspec 'x' did not match any files`, exit 128, and nothing is added (checked before any change).
- Ignored paths: an ignored path is reported only when a pathspec equals it or lies inside it.
  The report lists the ignored path (for `add d/c.txt` with `d/` ignored, it lists `d`), exits 1, but every other change, including tracked files inside the ignored directory, is still staged.
  `add .` never reports ignored files inside the tree.
- Tracked files are never treated as ignored themselves (`add a.txt` with `*.txt` ignored works if `a.txt` is tracked).
- `add <path>` also stages deletions under the path. `add -A` covers the whole tree regardless of the current directory.
- A path outside the work tree: exit 128.

## commit

- `-m` paragraphs are joined with a blank line; whitespace cleanup strips trailing spaces, collapses blank lines, and removes leading/trailing blank lines (leading spaces of the first line are kept).
- Empty message after cleanup: `Aborting commit due to empty commit message.`, exit 1.
- Nothing to commit (index equals HEAD, or an empty index on an unborn branch): status-like text on stdout, exit 1.
- Tree objects are written before these checks: a failed commit on an empty index still writes the empty tree `4b825dc...`.
- `commit -a` that fails leaves the index unchanged.

## rev-parse

- An argument that is not a revision is printed to stdout and then the command dies with exit 128 (`ambiguous argument`), unless it names an existing path; once a path is seen, the rest are treated as paths.
- Arguments starting with `-` are printed as they are; `--` is printed and everything after it is printed as it is.
- A 40-hex ID is printed even when the object does not exist. An unborn `HEAD` is an unknown revision.
- `~`, `~<n>`, `^`, `^<n>`, `^0` are supported; leading zeros in numbers are allowed.

## log

- Unborn branch: `fatal: your current branch 'main' does not have any commits yet`, exit 128.
- Default format: `commit <id>`, `Author: <name> <email>`, `Date:   <Tue Nov 14 22:13:20 2023 +0000>` (in the author's time zone), a blank line, the message with each line right-trimmed, indented by 4 spaces and with tabs expanded to 8 columns (counted after the indent). Blank message lines become 4 spaces. Commits are separated by a blank line.
- `--oneline`: abbreviated ID (7+ digits, unique) and the subject (the first paragraph, lines joined with a space, tabs not expanded).
- `-n` without a value, or a non-number: exit 128. `-n 0` prints nothing. Negative means no limit. An unknown option: exit 128.

## branch

- Listing: `* <current>` and `  <other>`, sorted by name; an unborn repository lists nothing.
- Creating at an unborn HEAD: `fatal: not a valid object name: 'main'`, exit 128. Existing branch, invalid name (including a leading `-` after `--`), unknown start point, or a file/directory conflict with another branch: exit 128.
- `-d`: not found, the current branch, or not merged into HEAD: an `error:` line, the other names are still processed, exit 1. `-d` without a name: exit 128. Empty parent directories under `refs/heads/` are removed.

## switch

- `Already on '<branch>'` when switching to the current branch, exit 0.
- Unknown name: exit 128. A revision that is not a branch: exit 128. No argument: exit 128. Two arguments: exit 128.
- `-c` with an existing or invalid name: exit 128. `-c` on an unborn branch just moves HEAD to the new unborn branch.
- The two-way merge follows `git read-tree -m -u` ("Two Tree Merge" table): local changes are carried over when the file is the same on both branches, otherwise the command fails (exit 1) without changing anything.
  Untracked files that would be overwritten make it fail, unless they are ignored (then they are overwritten).

## Additional findings

- `init -b <name>` only checks that `refs/heads/<name>` is a valid ref name: `-b HEAD` and `-b -x` are accepted, `-b 'a b'` fails with exit 128.
- `rev-parse <path>` accepts any existing path, even outside the work tree (`..`, `/tmp`).
- `switch`: a tracked file deleted in the working tree (but still in the index) counts as unchanged, so switching to a branch where it differs succeeds and writes the file. A deletion staged in the index makes the switch fail.
- `branch -d main` on an unborn `main` fails with exit 1 (the branch is checked out).
- `switch` compares file contents, not only stat data: a file rewritten with the same content does not block a switch.
- `switch`: a file removed from the index but still on disk (`git rm --cached`) blocks a switch to a branch that does not have it ("untracked working tree files would be removed"), unless it is ignored; then it is left in place.
- The index file is created or written by: `add` only when it changed something (no index after `add -A` in an empty repository); `commit` without `-a` always (even when it fails); `commit -a` only when it succeeds; `switch` whenever it moves to a commit (not `switch -c` on an unborn branch). `status` does not create it.
- A failed `commit -a` (for example with an empty message) still writes the blobs of the modified files and the trees.

## status: rename detection

The specification lists rename detection as a non-goal, but the real `git status --porcelain` detects renames by default, and its output must match. So tgit implements the part that `status` uses. Observed with git 2.47:

- Only staged changes are paired: files deleted from the index (relative to HEAD) with files added to it. They show as `R  <old> -> <new>`, sorted by the new path. The second column is the new path's working tree status (`RM`, `RD`). The old path is no longer listed as `D`. Both paths are quoted separately.
- Identical contents are paired first, empty files included. Among identical sources, one with the same basename wins, otherwise the first by path. Symlinks pair only with identical symlinks.
- Then a source and a destination whose basename is unique on both sides pair up if they are at least 75% similar, even when another source is more similar (`a/f.txt -> b/f.txt` at 80% beats `g.txt` at 90%).
- Then the remaining pairs pair from most to least similar, down to 50% (exactly 50% is accepted). Similarity is git's diffcore-delta score: bytes in matching spans (lines, or 64-byte chunks) divided by the larger file size. CR before LF is ignored in text files.
- Ties go to the earlier pair in git's candidate order, which depends on the other candidates (scenario `status-07`).

## The empty tree and the cache tree

Found through a random test (`v1-random-1270`, seed 101, reduced to scenario `switch-08`):

- The real git knows the empty tree `4b825dc642cb6eb9a060e54bf8d69288fbee4904` without an object file: `cat-file -t/-s/-p` with its full ID works in a new repository. An abbreviated `4b825dc` is not found (exit 128).
- `switch` (like any checkout) writes the cache tree (index extension `TREE`) in "repair" mode. A directory's tree is recorded only if the tree object exists, and a directory containing an unrecorded one is invalid (`-1`). With an empty index, the root records the empty tree, which "exists" even without a file. So `git fsck` then reports `missing tree 4b825dc...` and exits 2.
- `commit` builds its trees from the cache tree, reusing valid nodes whose trees exist and writing the others. After `switch` with an empty index, `commit` therefore does not write the empty tree object, and the new commit's tree is missing on disk (fsck exits 2). Otherwise `commit` writes the empty tree as usual.
- After `commit` the cache tree is fully valid. `add` invalidates the directories on the way to each changed path. The real git sometimes invalidates more (for example, all directories when a file replaces a directory). tgit invalidates only the path's own directories, which leads to the same trees.
- `switch -c <name>` without a start point, when HEAD has a commit, takes a shortcut: it does not merge, so it neither rewrites the index (nor its cache tree) nor prints the local changes (`M\t<path>` lines). With an explicit start point, even `HEAD`, it does the full two-way merge and prints them. Found through `v1-random-0118` and `v1-random-0450` (seed 33), reduced to scenario `switch-09`.
