# Progress

## v0.1.0

Implemented `docs/spec-v1.md`.

- Commands: `init`, `hash-object`, `cat-file`, `add`, `ls-files`, `status --porcelain`, `commit`, `rev-parse`, `log`, `branch`, and `switch`, with the options the specification lists.
- Repository format:
  - Loose objects (blob, tree, commit) and index version 2.
  - The index cache tree (`TREE` extension) is read, invalidated, and written like the real git's: `switch` records existing trees in repair mode, and `commit` reuses valid trees. As in the real git, the empty tree counts as present without an object file. Other index extensions are dropped when tgit rewrites the index.
  - HEAD as a symbolic ref to a branch, unborn branches, and branches under `refs/heads/`.
  - Config is read from `$HOME/.gitconfig` and `.git/config`.
- `.gitignore` at the repository root: comments, blank lines, wildcards (a port of git's wildmatch), directory patterns, negation, and anchored patterns.
- Revisions: ref names, full and abbreviated object IDs, and `~<n>` and `^<n>` suffixes in any combination.
- `status --porcelain` detects staged renames as the real git does (see `docs/notes/v1-real-git-behavior.md`). The specification lists rename detection as a non-goal, but the real git's porcelain output includes renames, and the random tests compare it.
- `switch` follows the real git's two-way merge rules. Non-conflicting local changes are carried over. On a conflict it reports the same categories of problems as the real git (local changes, untracked files that would be overwritten or removed) and changes nothing.
- Exit codes follow the real git, including usage errors (129) and errors outside a repository (128). Behavior observed with the real git is recorded in `docs/notes/v1-real-git-behavior.md`.
- Tests:
  - Unit tests in `test/unit/`.
  - Differential scenarios in `test/difftest/scenarios/v1/`, covering subdirectories, special paths, error cases, and unborn repositories.
  - `npm run difftest` runs all scenarios, then random sequences for seeds 1, 2, and 3. `DIFFTEST_SEEDS` and `DIFFTEST_COUNT` (default 100) change these.

### Known differences from the real git

- `status` supports only `--porcelain`. Rename detection there uses git's default settings (`diff.renames`, `status.renames`, and `diff.renameLimit` are not read), without the limit on the number of rename candidates.
- `ls-files` takes no path arguments, and pathspecs given to `add` are literal paths (no glob patterns or magic).
- Only the root `.gitignore` is read. Nested `.gitignore` files, `.git/info/exclude`, and `core.excludesFile` are ignored.
- Nested repositories inside the work tree are not treated specially: their files are listed and added like ordinary files, whereas the real git treats such a directory as a single gitlink entry.
- No reflogs, hooks, packfiles, or object types other than blob, tree, and commit.
- Error message wording differs from the real git (the messages still go to standard error).
