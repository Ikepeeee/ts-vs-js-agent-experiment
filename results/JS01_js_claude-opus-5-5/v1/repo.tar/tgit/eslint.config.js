import js from "@eslint/js";

const NODE_GLOBALS = ["process", "console", "Buffer", "URL", "setTimeout", "clearTimeout", "setInterval", "clearInterval"];

export default [
  // The difftest tools are provided as they are and are not linted.
  { ignores: ["node_modules/", "test/difftest/tools/"] },
  js.configs.recommended,
  {
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: Object.fromEntries(NODE_GLOBALS.map((name) => [name, "readonly"])),
    },
  },
];
