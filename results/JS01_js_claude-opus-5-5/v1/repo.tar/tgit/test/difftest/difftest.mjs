// Runs the differential tests: every scenario under scenarios/, then random sequences from gen.mjs.
// DIFFTEST_SEEDS (comma-separated) and DIFFTEST_COUNT choose the random sequences.
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const tgit = `node ${path.resolve(here, "../../src/main.js")}`;
const seeds = (process.env.DIFFTEST_SEEDS ?? "1,2,3").split(",").filter(Boolean);
const count = process.env.DIFFTEST_COUNT ?? "100";

function node(script, args) {
  const result = spawnSync(process.execPath, [path.join(here, "tools", script), ...args], { stdio: "inherit" });
  return result.status === 0;
}

let ok = node("run.mjs", ["--tgit", tgit, path.join(here, "scenarios")]);
const randomDir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-random-"));
try {
  for (const seed of seeds) {
    const out = path.join(randomDir, seed);
    ok = node("gen.mjs", ["--version", "v1", "--seed", seed, "--count", count, "--out", out]) && ok;
    ok = node("run.mjs", ["--tgit", tgit, out]) && ok;
  }
} finally {
  fs.rmSync(randomDir, { recursive: true, force: true });
}
process.exitCode = ok ? 0 : 1;
