import assert from "node:assert/strict";
import { test } from "node:test";
import { quotePath } from "../../src/cli/quote.js";

test("plain paths are not quoted", () => {
  assert.equal(quotePath("a/b.txt"), "a/b.txt");
  assert.equal(quotePath("-x.txt"), "-x.txt");
  assert.equal(quotePath("sp ace.txt"), "sp ace.txt");
});

test("spaces force quoting only when asked", () => {
  assert.equal(quotePath("sp ace.txt", { quoteSpaces: true }), '"sp ace.txt"');
});

test("special and non-ASCII bytes are escaped", () => {
  assert.equal(quotePath("tab\there"), '"tab\\there"');
  assert.equal(quotePath('q"uote'), '"q\\"uote"');
  assert.equal(quotePath("back\\slash"), '"back\\\\slash"');
  assert.equal(quotePath("日本.txt"), '"\\346\\227\\245\\346\\234\\254.txt"');
  assert.equal(quotePath("\x01"), '"\\001"');
});
