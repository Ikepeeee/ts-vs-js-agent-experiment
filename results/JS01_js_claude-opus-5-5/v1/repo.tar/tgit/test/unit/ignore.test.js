import assert from "node:assert/strict";
import { test } from "node:test";
import { IgnoreRules, parseIgnoreFile } from "../../src/core/worktree/ignore.js";
import { wildmatch } from "../../src/core/worktree/wildmatch.js";

test("wildmatch", () => {
  assert.ok(wildmatch("*.log", "app.log"));
  assert.ok(!wildmatch("*.log", "app.txt"));
  assert.ok(wildmatch("a/*/c", "a/b/c", { pathname: true }));
  assert.ok(!wildmatch("a/*", "a/b/c", { pathname: true }));
  assert.ok(wildmatch("a/**/c", "a/b/d/c", { pathname: true }));
  assert.ok(wildmatch("[a-c]x", "bx"));
  assert.ok(!wildmatch("[!a-c]x", "bx"));
  assert.ok(wildmatch("?.txt", "a.txt"));
});

test("comments, blank lines and trailing spaces", () => {
  const rules = new IgnoreRules(parseIgnoreFile("# comment\n\n*.log  \n\\#hash\n"));
  assert.equal(rules.patterns.length, 2);
  assert.ok(rules.isIgnored("app.log", false));
  assert.ok(rules.isIgnored("#hash", false));
  assert.ok(!rules.isIgnored("# comment", false));
});

test("directory patterns and negation", () => {
  const rules = new IgnoreRules(parseIgnoreFile("build/\n*.txt\n!keep.txt\n/root.md\n"));
  assert.ok(rules.isIgnored("build", true));
  assert.ok(!rules.isIgnored("build", false));
  assert.ok(rules.isIgnored("build/out.o", false));
  assert.ok(rules.isIgnored("x/build/out.o", false));
  assert.ok(rules.isIgnored("d/a.txt", false));
  assert.ok(!rules.isIgnored("keep.txt", false));
  assert.ok(rules.isIgnored("root.md", false));
  assert.ok(!rules.isIgnored("d/root.md", false));
  assert.equal(rules.ignoredParent("build/x/y"), "build");
});

test("a file inside an ignored directory cannot be re-included", () => {
  const rules = new IgnoreRules(parseIgnoreFile("d/\n!d/keep\n"));
  assert.ok(rules.isIgnored("d/keep", false));
});
