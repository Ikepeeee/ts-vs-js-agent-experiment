import assert from "node:assert/strict";
import { test } from "node:test";
import { parseOptions, UsageError } from "../../src/cli/options.js";

const SPECS = [
  { key: "all", short: "a", long: "all" },
  { key: "message", short: "m", long: "message", value: true, repeat: true },
];

test("bundled, attached and separate values", () => {
  assert.deepEqual(parseOptions(["-am", "x", "-my", "--message=z", "--message", "w"], SPECS), {
    options: { all: true, message: ["x", "y", "z", "w"] },
    args: [],
  });
});

test("arguments may be mixed with options, and -- ends them", () => {
  assert.deepEqual(parseOptions(["p", "-a", "--", "-m", "q"], SPECS), { options: { all: true }, args: ["p", "-m", "q"] });
});

test("errors exit with 129", () => {
  assert.throws(() => parseOptions(["-z"], SPECS), (e) => e instanceof UsageError && e.exitCode === 129);
  assert.throws(() => parseOptions(["-m"], SPECS), UsageError);
  assert.throws(() => parseOptions(["--bogus"], SPECS), UsageError);
});
