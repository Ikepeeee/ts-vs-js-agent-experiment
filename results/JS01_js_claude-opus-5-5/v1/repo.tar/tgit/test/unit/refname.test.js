import assert from "node:assert/strict";
import { test } from "node:test";
import { isValidRefName } from "../../src/core/refs/refname.js";

test("valid ref names", () => {
  for (const name of ["refs/heads/main", "refs/heads/feature/x", "refs/heads/日本", "refs/heads/-x"]) {
    assert.ok(isValidRefName(name), name);
  }
});

test("invalid ref names", () => {
  const invalid = ["refs/heads/a b", "refs/heads/a..b", "refs/heads/.x", "refs/heads/x.lock", "refs/heads/x/", "refs/heads/a~1", "refs/heads/a^", "refs/heads/a:b", "refs/heads/@{x", "refs/heads/a\\b", "@"];
  for (const name of invalid) assert.ok(!isValidRefName(name), name);
});
