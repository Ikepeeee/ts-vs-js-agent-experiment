import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { test } from "node:test";
import { detectRenames } from "../../src/core/diff/renames.js";
import { MODE_FILE, MODE_SYMLINK } from "../../src/core/objects/modes.js";
import { writeObject } from "../../src/core/objects/store.js";

const gitDir = fs.mkdtempSync(path.join(os.tmpdir(), "tgit-renames-"));
const file = (filePath, content, mode = MODE_FILE) => ({ path: filePath, mode, oid: writeObject(gitDir, "blob", Buffer.from(content)) });
const LINES = "1111111111\n2222222222\n3333333333\n4444444444\n5555555555\n6666666666\n7777777777\n8888888888\n";

test("identical files pair up, preferring the same basename", () => {
  const renames = detectRenames(gitDir, [file("s1", "same\n"), file("x/s2", "same\n")], [file("c/s2", "same\n"), file("d", "same\n")]);
  assert.deepEqual([...renames], [["c/s2", "x/s2"], ["d", "s1"]]);
});

test("similar files pair up from 50% similarity", () => {
  const renames = detectRenames(gitDir, [file("t4", "a\nb\nc\nd\n"), file("t5", "ab\ncd\nef\n")], [file("t4n", "a\nb\nX\nY\n"), file("t5n", "ab\nXX\nYY\nZZ\n")]);
  assert.deepEqual([...renames], [["t4n", "t4"]]);
});

test("a unique basename wins from 75% similarity", () => {
  const deleted = [file("a/f.txt", `${LINES}qqqqqqqqqq\nrrrrrrrrrr\n`), file("g.txt", `${LINES}9999999999\nssssssssss\n`)];
  const renames = detectRenames(gitDir, deleted, [file("b/f.txt", `${LINES}9999999999\nzzzzzzzzzz\n`)]);
  assert.deepEqual([...renames], [["b/f.txt", "a/f.txt"]]);
});

test("CR before LF is ignored in text files", () => {
  const renames = detectRenames(gitDir, [file("crlf", "one\r\ntwo\r\n")], [file("lf", "one\ntwo\nthree\n")]);
  assert.deepEqual([...renames], [["lf", "crlf"]]);
});

test("symlinks pair up only when identical", () => {
  const deleted = [file("l1", "target-one", MODE_SYMLINK), file("l2", "target-two", MODE_SYMLINK)];
  const added = [file("l3", "target-one", MODE_SYMLINK), file("l4", "target-twx", MODE_SYMLINK)];
  assert.deepEqual([...detectRenames(gitDir, deleted, added)], [["l3", "l1"]]);
});
