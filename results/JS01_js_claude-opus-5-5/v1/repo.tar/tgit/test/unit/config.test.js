import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { test } from "node:test";
import { configValue, parseConfig, setConfigValue } from "../../src/core/repo/config.js";

test("parsing sections, subsections, quotes and comments", () => {
  const entries = parseConfig('[init]\n\tdefaultBranch = main ; comment\n[Remote "origin"]\n\turl = "a b"\n[core]\n\tbare\n');
  assert.equal(configValue(entries, "init.defaultbranch"), "main");
  assert.equal(configValue(entries, "remote.origin.url"), "a b");
  assert.equal(configValue(entries, "core.bare"), true);
});

test("setting values in place and in new sections", () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "tgit-config-")), "config");
  setConfigValue(file, "core", "bare", "false");
  setConfigValue(file, "core", "filemode", "true");
  setConfigValue(file, "core", "bare", "true");
  assert.equal(fs.readFileSync(file, "utf8"), "[core]\n\tbare = true\n\tfilemode = true\n");
});
