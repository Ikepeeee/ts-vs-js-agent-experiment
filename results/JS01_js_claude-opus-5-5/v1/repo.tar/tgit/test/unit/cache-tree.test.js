import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { test } from "node:test";
import { invalidateCacheTreePath, parseCacheTree, serializeCacheTree, updateCacheTree } from "../../src/core/index/cache-tree.js";
import { MODE_FILE } from "../../src/core/objects/modes.js";
import { EMPTY_TREE_OID, objectExists, writeObject } from "../../src/core/objects/store.js";

const newGitDir = () => fs.mkdtempSync(path.join(os.tmpdir(), "tgit-cache-tree-"));
const entries = (gitDir, paths) =>
  paths.map((p) => ({ path: p, mode: MODE_FILE, oid: writeObject(gitDir, "blob", Buffer.from(`${p}\n`)), stage: 0 }));
const shape = (node) => [node.name, node.oid ? node.entryCount : -1, node.subtrees.map(shape)];

test("trees are written, and subtrees ordered by name length first", () => {
  const gitDir = newGitDir();
  const root = updateCacheTree(gitDir, entries(gitDir, ["bb/x", "c/d/e", "c/f", "top"]));
  assert.deepEqual(shape(root), ["", 4, [["c", 2, [["d", 1, []]]], ["bb", 1, []]]]);
  assert.ok(objectExists(gitDir, root.oid));
  assert.deepEqual(parseCacheTree(serializeCacheTree(root)), root);
});

test("repair records only existing trees, and the empty tree always exists", () => {
  const gitDir = newGitDir();
  const files = entries(gitDir, ["a/x", "b/y"]);
  updateCacheTree(gitDir, files.slice(0, 1));
  const root = updateCacheTree(gitDir, files, null, { repair: true });
  assert.deepEqual(shape(root), ["", -1, [["a", 1, []], ["b", -1, []]]]);
  assert.equal(updateCacheTree(gitDir, [], null, { repair: true }).oid, EMPTY_TREE_OID);
  assert.ok(!fs.existsSync(path.join(gitDir, "objects", "4b")));
});

test("valid nodes are reused, and a changed path invalidates its directories", () => {
  const gitDir = newGitDir();
  const files = entries(gitDir, ["a/b/x", "a/y", "c/z"]);
  const root = updateCacheTree(gitDir, files);
  invalidateCacheTreePath(root, "a/b");
  assert.deepEqual(shape(root), ["", -1, [["a", -1, []], ["c", 1, []]]]);
  const cached = updateCacheTree(gitDir, [], { name: "", entryCount: 0, oid: EMPTY_TREE_OID, subtrees: [] });
  assert.equal(cached.oid, EMPTY_TREE_OID);
  assert.ok(!fs.existsSync(path.join(gitDir, "objects", "4b")));
});
