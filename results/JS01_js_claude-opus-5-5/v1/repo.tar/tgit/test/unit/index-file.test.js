import assert from "node:assert/strict";
import { test } from "node:test";
import { EMPTY_STAT, parseIndex, serializeIndex } from "../../src/core/index/index-file.js";
import { Index } from "../../src/core/index/index.js";

const OID = "4a58007052a65fbc2fc3f910f2855f45a4058e74";
const entry = (path) => ({ path, mode: 0o100644, oid: OID, stage: 0, stat: EMPTY_STAT });

test("the index round-trips and sorts by bytes", () => {
  const entries = [entry("日本.txt"), entry("b"), entry("a/b"), entry("a.txt"), entry("12345678")];
  const parsed = parseIndex(serializeIndex(entries)).entries;
  assert.deepEqual(parsed.map((e) => e.path), ["12345678", "a.txt", "a/b", "b", "日本.txt"]);
  assert.equal(parsed[0].oid, OID);
});

test("adding a file removes entries that conflict with it as a directory", () => {
  const index = new Index([entry("d/x"), entry("d/y"), entry("e")]);
  index.set(entry("d"));
  index.set(entry("e/z"));
  assert.deepEqual(index.entries().map((e) => e.path), ["d", "e/z"]);
  assert.ok(index.changed);
});
