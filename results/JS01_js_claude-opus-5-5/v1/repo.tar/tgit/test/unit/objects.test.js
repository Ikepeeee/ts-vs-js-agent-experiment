import assert from "node:assert/strict";
import { test } from "node:test";
import { parseCommit, serializeCommit } from "../../src/core/objects/commit.js";
import { MODE_EXECUTABLE, MODE_FILE, MODE_SYMLINK, MODE_TREE } from "../../src/core/objects/modes.js";
import { hashObject } from "../../src/core/objects/store.js";
import { parseTree, serializeTree } from "../../src/core/objects/tree.js";

const BLOB = "4a58007052a65fbc2fc3f910f2855f45a4058e74";

test("blob IDs match git", () => {
  assert.equal(hashObject("blob", Buffer.from("alpha\n")), BLOB);
  assert.equal(hashObject("blob", Buffer.alloc(0)), "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391");
  assert.equal(hashObject("tree", Buffer.alloc(0)), "4b825dc642cb6eb9a060e54bf8d69288fbee4904");
});

test("trees sort directories as if their names ended with a slash", () => {
  const entries = [
    { mode: MODE_FILE, name: "d.txt", oid: BLOB },
    { mode: MODE_TREE, name: "d", oid: BLOB },
    { mode: MODE_FILE, name: "d-", oid: BLOB },
    { mode: MODE_EXECUTABLE, name: "a", oid: BLOB },
    { mode: MODE_SYMLINK, name: "日本", oid: BLOB },
  ];
  const parsed = parseTree(serializeTree(entries));
  assert.deepEqual(parsed.map((e) => e.name), ["a", "d-", "d.txt", "d", "日本"]);
  assert.match(serializeTree([{ mode: MODE_TREE, name: "d", oid: BLOB }]).toString("latin1"), /^40000 d\0/);
});

test("commits round-trip", () => {
  const commit = {
    tree: "4b825dc642cb6eb9a060e54bf8d69288fbee4904",
    parents: [BLOB],
    author: "A <a@example.com> 1700000000 +0000",
    committer: "C <c@example.com> 1700000000 +0000",
    message: "subject\n\nbody\n",
  };
  assert.deepEqual(parseCommit(serializeCommit(commit)), commit);
});
