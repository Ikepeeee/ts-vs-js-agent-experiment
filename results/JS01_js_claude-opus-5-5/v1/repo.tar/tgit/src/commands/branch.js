import { parseOptions, UsageError } from "../cli/options.js";
import { GitError } from "../core/errors.js";
import { isAncestor } from "../core/history/walk.js";
import { abbreviate } from "../core/objects/store.js";
import { isValidBranchName } from "../core/refs/refname.js";
import { BRANCH_PREFIX, branchName, deleteRef, listBranches, readHead, resolveRef, updateRef } from "../core/refs/refs.js";
import { requireRepository } from "../core/repo/repository.js";
import { resolveCommit } from "../core/revisions/resolve.js";

const USAGE = "tgit branch [<branch-name> [<start-point>]] | tgit branch -d <branch-name>...";
const OPTIONS = [{ key: "delete", short: "d", long: "delete" }];

function list(repo, stdout) {
  const head = readHead(repo.gitDir);
  for (const { name } of listBranches(repo.gitDir)) {
    stdout.write(`${name === head.branch ? "*" : " "} ${branchName(name)}\n`);
  }
}

function create(repo, name, startPoint) {
  if (!isValidBranchName(name)) throw new GitError(`'${name}' is not a valid branch name`);
  const ref = `${BRANCH_PREFIX}${name}`;
  if (resolveRef(repo.gitDir, ref)?.oid) throw new GitError(`a branch named '${name}' already exists`);
  const start = startPoint ?? "HEAD";
  const oid = resolveCommit(repo.gitDir, start);
  if (!oid) {
    const shown = startPoint ?? branchName(readHead(repo.gitDir).branch ?? "HEAD");
    throw new GitError(`not a valid object name: '${shown}'`);
  }
  updateRef(repo.gitDir, ref, oid);
}

// Deletes each branch that is fully merged into HEAD. Returns the exit code: 1 if any branch could not be deleted.
function remove(repo, names, { stdout, stderr }) {
  const head = readHead(repo.gitDir);
  let exitCode = 0;
  const fail = (message) => {
    stderr.write(`error: ${message}\n`);
    exitCode = 1;
  };
  for (const name of names) {
    const ref = `${BRANCH_PREFIX}${name}`;
    if (ref === head.branch) {
      fail(`cannot delete branch '${name}' used by worktree at '${repo.workTree}'`);
      continue;
    }
    const oid = resolveRef(repo.gitDir, ref)?.oid;
    if (!oid) {
      fail(`branch '${name}' not found`);
      continue;
    }
    if (!head.oid || !isAncestor(repo.gitDir, oid, head.oid)) {
      fail(`the branch '${name}' is not fully merged`);
      continue;
    }
    deleteRef(repo.gitDir, ref);
    stdout.write(`Deleted branch ${name} (was ${abbreviate(repo.gitDir, oid)}).\n`);
  }
  return exitCode;
}

function run(argv, context) {
  const repo = requireRepository(context.cwd);
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  if (options.delete) {
    if (args.length === 0) throw new GitError("branch name required");
    return remove(repo, args, context);
  }
  if (args.length === 0) return list(repo, context.stdout);
  if (args.length > 2) throw new UsageError("too many arguments", USAGE);
  create(repo, args[0], args[1]);
}

export default { name: "branch", run };
