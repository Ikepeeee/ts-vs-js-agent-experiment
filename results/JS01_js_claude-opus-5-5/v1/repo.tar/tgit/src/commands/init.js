import fs from "node:fs";
import path from "node:path";
import { parseOptions, UsageError } from "../cli/options.js";
import { GitError } from "../core/errors.js";
import { configValue, loadConfig, setConfigValue } from "../core/repo/config.js";
import { isValidRefName } from "../core/refs/refname.js";
import { BRANCH_PREFIX, setSymbolicRef } from "../core/refs/refs.js";

const USAGE = "tgit init [-q | --quiet] [-b <branch-name> | --initial-branch=<branch-name>] [<directory>]";
const OPTIONS = [
  { key: "quiet", short: "q", long: "quiet" },
  { key: "initialBranch", short: "b", long: "initial-branch", value: true },
];
const DEFAULT_BRANCH = "master";
const REF_DIRECTORIES = ["refs/heads", "refs/tags"];
const OBJECT_DIRECTORIES = ["objects/info", "objects/pack"];
const CORE_CONFIG = [
  ["repositoryformatversion", "0"],
  ["filemode", "true"],
  ["bare", "false"],
  ["logallrefupdates", "true"],
];

function createWorkTree(dir, shownName) {
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch (e) {
    if (e.code === "EEXIST" || e.code === "ENOTDIR") throw new GitError(`cannot mkdir ${shownName}: File exists`);
    throw e;
  }
}

function run(argv, { cwd, env, stdout, stderr }) {
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  if (args.length > 1) throw new UsageError("too many arguments", USAGE);
  const workTree = path.resolve(cwd, args[0] ?? ".");
  const gitDir = path.join(workTree, ".git");
  const reinit = fs.existsSync(path.join(gitDir, "HEAD"));

  // The steps run in the real git's order, so that an invalid branch name leaves the same partial .git behind.
  if (!reinit) createWorkTree(workTree, args[0] ?? ".");
  for (const dir of REF_DIRECTORIES) fs.mkdirSync(path.join(gitDir, dir), { recursive: true });
  for (const [name, value] of CORE_CONFIG) setConfigValue(path.join(gitDir, "config"), "core", name, value);
  if (reinit) {
    if (options.initialBranch !== undefined) stderr.write(`warning: re-init: ignored --initial-branch=${options.initialBranch}\n`);
  } else {
    const branch = options.initialBranch ?? configValue(loadConfig(env), "init.defaultBranch") ?? DEFAULT_BRANCH;
    if (!isValidRefName(`${BRANCH_PREFIX}${branch}`)) throw new GitError(`invalid initial branch name: '${branch}'`);
    setSymbolicRef(gitDir, "HEAD", `${BRANCH_PREFIX}${branch}`);
  }
  for (const dir of OBJECT_DIRECTORIES) fs.mkdirSync(path.join(gitDir, dir), { recursive: true });

  if (!options.quiet) {
    const verb = reinit ? "Reinitialized existing" : "Initialized empty";
    stdout.write(`${verb} Git repository in ${fs.realpathSync(gitDir)}/\n`);
  }
}

export default { name: "init", run };
