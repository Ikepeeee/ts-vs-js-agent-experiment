import { parseOptions, UsageError } from "../cli/options.js";
import { quotePath } from "../cli/quote.js";
import { GitError } from "../core/errors.js";
import { updateCacheTree } from "../core/index/cache-tree.js";
import { Index } from "../core/index/index.js";
import { readCommit } from "../core/objects/commit.js";
import { sameType } from "../core/objects/modes.js";
import { flattenTree } from "../core/objects/tree.js";
import { comparePaths, isInside, leadingDirectories } from "../core/paths.js";
import { isValidBranchName } from "../core/refs/refname.js";
import { BRANCH_PREFIX, readHead, resolveRef, setSymbolicRef, updateRef } from "../core/refs/refs.js";
import { requireRepository, worktreePath } from "../core/repo/repository.js";
import { resolveCommit } from "../core/revisions/resolve.js";
import { checkoutBlob, hashWorktreeFile, lstatOrNull, removeWorktreeFile } from "../core/worktree/files.js";
import { IgnoreRules } from "../core/worktree/ignore.js";
import { findUntracked } from "../core/worktree/untracked.js";

const USAGE = "tgit switch <branch> | tgit switch -c <new-branch> [<start-point>]";
const OPTIONS = [{ key: "create", short: "c", long: "create", value: true }];
const CONFLICT = 1;

const PROBLEMS = {
  localChanges: "Your local changes to the following files would be overwritten by checkout:",
  untrackedInDirectory: "Updating the following directories would lose untracked files in them:",
  untrackedOverwritten: "The following untracked working tree files would be overwritten by checkout:",
  untrackedRemoved: "The following untracked working tree files would be removed by checkout:",
};

function same(a, b) {
  if (!a || !b) return !a && !b;
  return a.mode === b.mode && a.oid === b.oid;
}

function commitFiles(gitDir, oid) {
  return oid ? flattenTree(gitDir, readCommit(gitDir, oid).tree) : new Map();
}

// Moves the index and the working tree from the commit oldOid to newOid with git's two-way merge
// ("git read-tree -m -u"): paths that differ between the commits are updated if they have no
// local changes; local changes to other paths are kept. Nothing is changed if any path conflicts.
// Returns the problems found, as { kind: [paths] }, or null after a successful update.
function twoWayMerge(repo, index, oldOid, newOid) {
  const oldFiles = commitFiles(repo.gitDir, oldOid);
  const newFiles = commitFiles(repo.gitDir, newOid);
  const ignore = IgnoreRules.load(repo.workTree);
  const problems = {};
  const reject = (kind, path) => (problems[kind] ??= []).push(path);
  const removals = new Set();
  const updates = new Map();

  // A tracked file has no local changes if the working tree has its content, or no file at all.
  const upToDate = (entry) => {
    if (!lstatOrNull(worktreePath(repo, entry.path))) return true;
    return same(hashWorktreeFile(repo, entry.path), entry);
  };
  const checkUpToDate = (entry) => {
    if (upToDate(entry)) return true;
    reject("localChanges", entry.path);
    return false;
  };
  const remove = (entry) => {
    if (checkUpToDate(entry)) removals.add(entry.path);
  };

  const paths = [...new Set([...index.byPath.keys(), ...oldFiles.keys(), ...newFiles.keys()])].sort(comparePaths);
  // Decides what happens to each path, following the cases of git's twoway_merge().
  const deferred = [];
  for (const path of paths) {
    const current = index.get(path);
    const oldEntry = oldFiles.get(path);
    const newEntry = newFiles.get(path);
    if (current) {
      if ((!oldEntry && !newEntry) || (!oldEntry && same(current, newEntry)) || (oldEntry && newEntry && (same(oldEntry, newEntry) || same(current, newEntry)))) {
        continue;
      } else if (oldEntry && !newEntry && same(current, oldEntry)) {
        remove(current);
      } else if (oldEntry && newEntry && same(current, oldEntry)) {
        if (checkUpToDate(current)) updates.set(path, newEntry);
      } else {
        reject("localChanges", path);
      }
    } else if (newEntry) {
      // The deletion of the path is staged.
      if (oldEntry && same(oldEntry, newEntry)) continue;
      if (oldEntry) reject("localChanges", path);
      else deferred.push({ path, entry: newEntry, kind: "untrackedOverwritten" });
    } else {
      deferred.push({ path, entry: null, kind: "untrackedRemoved" });
    }
  }

  // Whether the working tree file or directory at path can be replaced without losing data.
  const okToReplace = (path, stat, kind) => {
    if (ignore.isIgnored(path, stat.isDirectory())) return true;
    if (stat.isDirectory()) {
      const insideUpToDate = index.entries().filter((e) => isInside(e.path, path) && e.path !== path).every(checkUpToDate);
      const untracked = findUntracked(repo, index, ignore).some((p) => isInside(p, path));
      if (untracked) reject("untrackedInDirectory", path);
      return insideUpToDate && !untracked;
    }
    if (removals.has(path)) return true;
    reject(kind, path);
    return false;
  };
  // Paths not in the index must not hold untracked files that would be lost, as git's verify_absent().
  for (const { path, entry, kind } of deferred) {
    let blocked = false;
    for (const dir of leadingDirectories(path)) {
      const stat = lstatOrNull(worktreePath(repo, dir));
      if (!stat) break;
      if (stat.isDirectory()) continue;
      blocked = !okToReplace(dir, stat, kind);
      break;
    }
    if (blocked) continue;
    const stat = lstatOrNull(worktreePath(repo, path));
    if (stat && !okToReplace(path, stat, kind)) continue;
    if (entry) updates.set(path, entry);
  }

  if (Object.keys(problems).length > 0) return problems;

  for (const path of removals) {
    removeWorktreeFile(repo, path);
    index.delete(path);
  }
  for (const [path, { mode, oid }] of updates) index.set(checkoutBlob(repo, path, mode, oid));
  return null;
}

function reportProblems(problems, stderr) {
  for (const [kind, title] of Object.entries(PROBLEMS)) {
    if (!problems[kind]) continue;
    stderr.write(`error: ${title}\n${[...new Set(problems[kind])].map((p) => `\t${p}\n`).join("")}`);
  }
  stderr.write("Aborting\n");
}

// Like "git diff --name-status <commit>": the local changes that were carried over.
function showLocalChanges(repo, index, oid, stdout) {
  const files = commitFiles(repo.gitDir, oid);
  const paths = [...new Set([...files.keys(), ...index.byPath.keys()])].sort(comparePaths);
  for (const path of paths) {
    const committed = files.get(path);
    const current = index.has(path) ? hashWorktreeFile(repo, path) : null;
    let status = null;
    if (!committed) status = current ? "A" : null;
    else if (!current) status = "D";
    else if (!sameType(committed.mode, current.mode)) status = "T";
    else if (!same(committed, current)) status = "M";
    if (status) stdout.write(`${status}\t${quotePath(path)}\n`);
  }
}

function run(argv, { cwd, stdout, stderr }) {
  const repo = requireRepository(cwd);
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  const head = readHead(repo.gitDir);
  const newBranch = options.create;
  let target;
  let targetOid;

  if (newBranch !== undefined) {
    if (args.length > 1) throw new UsageError("too many arguments", USAGE);
    if (!isValidBranchName(newBranch)) throw new GitError(`'${newBranch}' is not a valid branch name`);
    target = `${BRANCH_PREFIX}${newBranch}`;
    if (resolveRef(repo.gitDir, target)?.oid) throw new GitError(`a branch named '${newBranch}' already exists`);
    targetOid = args.length > 0 ? resolveCommit(repo.gitDir, args[0]) : head.oid;
    if (args.length > 0 && !targetOid) throw new GitError(`invalid reference: ${args[0]}`);
  } else {
    if (args.length === 0) throw new GitError("missing branch or commit argument");
    if (args.length > 1) throw new GitError("only one reference expected");
    target = `${BRANCH_PREFIX}${args[0]}`;
    targetOid = resolveRef(repo.gitDir, target)?.oid;
    if (!targetOid) {
      if (resolveCommit(repo.gitDir, args[0])) throw new GitError(`a branch is expected, got '${args[0]}'`);
      throw new GitError(`invalid reference: ${args[0]}`);
    }
  }

  // Creating a branch without a start point keeps the current commit. Like the real git, leave the index
  // and the working tree alone then (no local changes are listed either). On an unborn branch the new
  // branch is unborn too.
  if (newBranch === undefined || args.length > 0) {
    const index = Index.read(repo.gitDir);
    const problems = twoWayMerge(repo, index, head.oid, targetOid);
    if (problems) {
      reportProblems(problems, stderr);
      return CONFLICT;
    }
    // Like the real git after a checkout, record the trees that already exist.
    index.cacheTree = updateCacheTree(repo.gitDir, index.entries(), index.cacheTree, { repair: true });
    index.write(repo.gitDir);
    showLocalChanges(repo, index, targetOid, stdout);
  }

  if (newBranch !== undefined && targetOid) updateRef(repo.gitDir, target, targetOid);
  if (target === head.branch) {
    stderr.write(`Already on '${args[0]}'\n`);
    return 0;
  }
  setSymbolicRef(repo.gitDir, "HEAD", target);
  stderr.write(newBranch !== undefined ? `Switched to a new branch '${newBranch}'\n` : `Switched to branch '${args[0]}'\n`);
}

export default { name: "switch", run };
