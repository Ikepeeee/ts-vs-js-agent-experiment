import fs from "node:fs";
import path from "node:path";
import { parseOptions } from "../cli/options.js";
import { GitError } from "../core/errors.js";
import { hashObject, writeObject } from "../core/objects/store.js";
import { requireRepository } from "../core/repo/repository.js";

const USAGE = "tgit hash-object [-w] [--] <file>...";
const OPTIONS = [{ key: "write", short: "w" }];

function readFile(cwd, file) {
  try {
    return fs.readFileSync(path.resolve(cwd, file));
  } catch (e) {
    if (e.code === "EISDIR") throw new GitError(`Unable to hash ${file}`);
    if (e.code === "ENOENT") throw new GitError(`could not open '${file}' for reading: No such file or directory`);
    throw e;
  }
}

function run(argv, { cwd, stdout }) {
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  // Only writing needs a repository.
  const repo = options.write ? requireRepository(cwd) : null;
  for (const file of args) {
    const content = readFile(cwd, file);
    const oid = repo ? writeObject(repo.gitDir, "blob", content) : hashObject("blob", content);
    stdout.write(`${oid}\n`);
  }
}

export default { name: "hash-object", run };
