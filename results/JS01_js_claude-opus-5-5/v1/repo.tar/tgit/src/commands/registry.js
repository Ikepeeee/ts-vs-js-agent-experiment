import add from "./add.js";
import branch from "./branch.js";
import catFile from "./cat-file.js";
import commit from "./commit.js";
import hashObject from "./hash-object.js";
import init from "./init.js";
import log from "./log.js";
import lsFiles from "./ls-files.js";
import revParse from "./rev-parse.js";
import status from "./status.js";
import switchCommand from "./switch.js";

export const commands = new Map(
  [add, branch, catFile, commit, hashObject, init, log, lsFiles, revParse, status, switchCommand].map((command) => [command.name, command]),
);
