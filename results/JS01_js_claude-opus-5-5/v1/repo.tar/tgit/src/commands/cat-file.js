import { parseOptions, UsageError } from "../cli/options.js";
import { quotePath } from "../cli/quote.js";
import { GitError } from "../core/errors.js";
import { isTreeMode } from "../core/objects/modes.js";
import { readObject } from "../core/objects/store.js";
import { parseTree } from "../core/objects/tree.js";
import { requireRepository } from "../core/repo/repository.js";
import { resolveRevision } from "../core/revisions/resolve.js";

const USAGE = "tgit cat-file (-t | -s | -p) <object>";
const OPTIONS = [
  { key: "type", short: "t" },
  { key: "size", short: "s" },
  { key: "print", short: "p" },
];
const GITLINK_MODE = 0o160000;

function entryType(mode) {
  if (isTreeMode(mode)) return "tree";
  return mode === GITLINK_MODE ? "commit" : "blob";
}

// "git cat-file -p" shows a tree the way "git ls-tree" does.
function formatTree(content) {
  return parseTree(content)
    .map((e) => `${e.mode.toString(8).padStart(6, "0")} ${entryType(e.mode)} ${e.oid}\t${quotePath(e.name)}\n`)
    .join("");
}

function run(argv, { cwd, stdout }) {
  const repo = requireRepository(cwd);
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  const modes = OPTIONS.filter((o) => options[o.key]);
  if (modes.length !== 1) throw new UsageError(modes.length ? "only one of -t, -s and -p can be used" : "an option is required", USAGE);
  if (args.length !== 1) throw new UsageError(args.length ? "too many arguments" : "an object is required", USAGE);

  const oid = resolveRevision(repo.gitDir, args[0]);
  const object = oid && readObject(repo.gitDir, oid);
  if (!object) throw new GitError(`Not a valid object name ${args[0]}`);
  if (options.type) stdout.write(`${object.type}\n`);
  else if (options.size) stdout.write(`${object.content.length}\n`);
  else if (object.type === "tree") stdout.write(formatTree(object.content));
  else stdout.write(object.content);
}

export default { name: "cat-file", run };
