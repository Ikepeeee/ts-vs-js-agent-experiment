import { parseOptions } from "../cli/options.js";
import { updateCacheTree } from "../core/index/cache-tree.js";
import { Index } from "../core/index/index.js";
import { stageTrackedChanges } from "../core/index/stage.js";
import { readCommit, serializeCommit } from "../core/objects/commit.js";
import { identityFromEnv } from "../core/objects/identity.js";
import { abbreviate, writeObject } from "../core/objects/store.js";
import { branchName, readHead, updateRef } from "../core/refs/refs.js";
import { requireRepository } from "../core/repo/repository.js";

const USAGE = "tgit commit [-a | --all] -m <message>...";
const OPTIONS = [
  { key: "all", short: "a", long: "all" },
  { key: "message", short: "m", long: "message", value: true, repeat: true },
];
const NOTHING_TO_COMMIT = 1;
const EMPTY_MESSAGE = 1;

// git's "whitespace" cleanup: trailing whitespace is removed from every line, runs of blank lines
// become one, and leading and trailing blank lines are dropped. Returns "" for an empty message.
function cleanUpMessage(text) {
  const lines = [];
  for (const line of text.split("\n").map((l) => l.trimEnd())) {
    if (line === "" && (lines.length === 0 || lines.at(-1) === "")) continue;
    lines.push(line);
  }
  if (lines.at(-1) === "") lines.pop();
  return lines.length === 0 ? "" : `${lines.join("\n")}\n`;
}

function run(argv, { cwd, env, stdout, stderr }) {
  const repo = requireRepository(cwd);
  const { options } = parseOptions(argv, OPTIONS, USAGE);
  const index = Index.read(repo.gitDir);
  if (options.all) stageTrackedChanges(repo, index);
  // As in the real git, the trees are written (reusing those recorded in the cache tree) before it is
  // known whether there is anything to commit.
  index.cacheTree = updateCacheTree(repo.gitDir, index.entries(), index.cacheTree);
  const tree = index.cacheTree.oid;
  // Without -a the real git writes the (refreshed) index even when the commit then fails;
  // with -a the updated index is kept only if the commit succeeds.
  if (!options.all) index.write(repo.gitDir);
  const head = readHead(repo.gitDir);
  const parentTree = head.oid ? readCommit(repo.gitDir, head.oid).tree : null;
  if (head.oid ? tree === parentTree : index.size === 0) {
    stdout.write("nothing to commit\n");
    return NOTHING_TO_COMMIT;
  }
  const message = cleanUpMessage((options.message ?? []).join("\n\n"));
  if (message === "") {
    stderr.write("Aborting commit due to empty commit message.\n");
    return EMPTY_MESSAGE;
  }

  const oid = writeObject(
    repo.gitDir,
    "commit",
    serializeCommit({
      tree,
      parents: head.oid ? [head.oid] : [],
      author: identityFromEnv("AUTHOR", env),
      committer: identityFromEnv("COMMITTER", env),
      message,
    }),
  );
  if (options.all) index.write(repo.gitDir);
  updateRef(repo.gitDir, head.branch ?? "HEAD", oid);

  const where = head.branch ? branchName(head.branch) : "detached HEAD";
  stdout.write(`[${where}${head.oid ? "" : " (root-commit)"} ${abbreviate(repo.gitDir, oid)}] ${message.split("\n")[0]}\n`);
}

export default { name: "commit", run };
