import { parseOptions } from "../cli/options.js";
import { GitError } from "../core/errors.js";
import { Index } from "../core/index/index.js";
import { stageTrackedChanges } from "../core/index/stage.js";
import { isInside } from "../core/paths.js";
import { requireRepository, toRepoPath, worktreePath } from "../core/repo/repository.js";
import { lstatOrNull, stageWorktreeFile } from "../core/worktree/files.js";
import { IgnoreRules } from "../core/worktree/ignore.js";
import { findUntracked } from "../core/worktree/untracked.js";

const USAGE = "tgit add [-A | --all] [--] [<pathspec>...]";
const OPTIONS = [{ key: "all", short: "A", long: "all" }];

// The ignored path that a pathspec names or lies inside, or null. A tracked file is never ignored itself.
function ignoredBy(repo, index, ignore, pathspec) {
  if (pathspec === "") return null;
  const parent = ignore.ignoredParent(pathspec);
  if (parent !== null) return parent;
  const stat = lstatOrNull(worktreePath(repo, pathspec));
  return !index.has(pathspec) && ignore.matchesItself(pathspec, stat?.isDirectory() ?? false) ? pathspec : null;
}

function run(argv, { cwd, stderr }) {
  const repo = requireRepository(cwd);
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  if (args.length === 0 && !options.all) {
    stderr.write("Nothing specified, nothing added.\n");
    return 0;
  }
  const pathspecs = args.length > 0 ? args.map((arg) => toRepoPath(repo, arg)) : [""];
  const index = Index.read(repo.gitDir);
  const ignore = IgnoreRules.load(repo.workTree);

  pathspecs.forEach((pathspec, i) => {
    const tracked = index.entries().some((entry) => isInside(entry.path, pathspec));
    if (!tracked && !lstatOrNull(worktreePath(repo, pathspec))) {
      throw new GitError(`pathspec '${args[i]}' did not match any files`);
    }
  });
  const ignored = [...new Set(pathspecs.map((p) => ignoredBy(repo, index, ignore, p)).filter((p) => p !== null))];

  stageTrackedChanges(repo, index, pathspecs);
  for (const path of findUntracked(repo, index, ignore)) {
    if (pathspecs.some((pathspec) => isInside(path, pathspec))) index.set(stageWorktreeFile(repo, path));
  }
  // Like the real git, the index is not written when nothing changed, so none is created in an empty repository.
  if (index.changed) index.write(repo.gitDir);

  if (ignored.length === 0) return 0;
  stderr.write(`The following paths are ignored by one of your .gitignore files:\n${ignored.map((p) => `${p}\n`).join("")}`);
  return 1;
}

export default { name: "add", run };
