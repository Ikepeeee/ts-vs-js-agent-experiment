import path from "node:path";
import { GitError } from "../core/errors.js";
import { lstatOrNull } from "../core/worktree/files.js";
import { requireRepository } from "../core/repo/repository.js";
import { resolveRevision } from "../core/revisions/resolve.js";

// Prints the object ID of each revision. As in the real git, arguments starting with "-" are
// printed as they are, and so is everything after "--". An argument that is not a revision
// but an existing path is printed too, and all later arguments must then be paths as well.
function run(args, { cwd, stdout }) {
  const repo = requireRepository(cwd);
  const pathExists = (arg) => lstatOrNull(path.resolve(cwd, arg)) !== null;
  let mode = "revisions";
  for (const arg of args) {
    if (mode === "verbatim") {
      stdout.write(`${arg}\n`);
    } else if (mode === "paths") {
      stdout.write(`${arg}\n`);
      if (arg.startsWith("-")) throw new GitError(`option '${arg}' must come before non-option arguments`);
      if (!pathExists(arg)) throw new GitError(`${arg}: no such path in the working tree.`);
    } else if (arg === "--") {
      stdout.write(`${arg}\n`);
      mode = "verbatim";
    } else if (arg.startsWith("-")) {
      stdout.write(`${arg}\n`);
    } else {
      const oid = resolveRevision(repo.gitDir, arg);
      stdout.write(`${oid ?? arg}\n`);
      if (oid) continue;
      if (!pathExists(arg)) throw new GitError(`ambiguous argument '${arg}': unknown revision or path not in the working tree.`);
      mode = "paths";
    }
  }
}

export default { name: "rev-parse", run };
