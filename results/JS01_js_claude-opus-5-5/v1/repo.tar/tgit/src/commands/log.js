import { GitError } from "../core/errors.js";
import { walkCommits } from "../core/history/walk.js";
import { parseIdentity } from "../core/objects/identity.js";
import { abbreviate } from "../core/objects/store.js";
import { branchName, readHead } from "../core/refs/refs.js";
import { requireRepository } from "../core/repo/repository.js";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const TAB_WIDTH = 8;
const INDENT = "    ";

// Options are parsed like git's revision options, whose errors exit with 128 rather than 129.
function parseArgs(args) {
  const options = { oneline: false, maxCount: -1 };
  const setCount = (text) => {
    if (text === undefined) throw new GitError("switch `n' requires a value");
    if (!/^[+-]?\d+$/.test(text)) throw new GitError(`'${text}': not an integer`);
    options.maxCount = Number(text);
  };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === "--oneline") options.oneline = true;
    else if (arg === "-n" || arg === "--max-count") setCount(args[++i]);
    else if (arg.startsWith("--max-count=")) setCount(arg.slice("--max-count=".length));
    else if (/^-n./.test(arg)) setCount(arg.slice(2));
    else if (/^-\d+$/.test(arg)) setCount(arg.slice(1));
    else throw new GitError(`unrecognized argument: ${arg}`);
  }
  return options;
}

function formatDate({ timestamp, timezone }) {
  const sign = timezone[0] === "-" ? -1 : 1;
  const offset = sign * (Number(timezone.slice(1, 3)) * 60 + Number(timezone.slice(3, 5)));
  const d = new Date((timestamp + offset * 60) * 1000);
  const time = [d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds()].map((n) => String(n).padStart(2, "0")).join(":");
  return `${DAYS[d.getUTCDay()]} ${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()} ${time} ${d.getUTCFullYear()} ${timezone}`;
}

// Display width of a character: 2 for East Asian wide characters, as git counts columns.
function charWidth(char) {
  const c = char.codePointAt(0);
  const wide =
    (c >= 0x1100 && c <= 0x115f) || (c >= 0x2e80 && c <= 0xa4cf) || (c >= 0xac00 && c <= 0xd7a3) ||
    (c >= 0xf900 && c <= 0xfaff) || (c >= 0xfe30 && c <= 0xfe4f) || (c >= 0xff00 && c <= 0xff60) ||
    (c >= 0xffe0 && c <= 0xffe6) || (c >= 0x20000 && c <= 0x3fffd);
  return wide ? 2 : 1;
}

function expandTabs(line) {
  let result = "";
  let column = 0;
  for (const char of line) {
    if (char === "\t") {
      const spaces = TAB_WIDTH - (column % TAB_WIDTH);
      result += " ".repeat(spaces);
      column += spaces;
    } else {
      result += char;
      column += charWidth(char);
    }
  }
  return result;
}

function messageLines(message) {
  const lines = message.split("\n").map((line) => line.trimEnd());
  while (lines.length > 0 && lines[0] === "") lines.shift();
  while (lines.length > 0 && lines.at(-1) === "") lines.pop();
  return lines;
}

// The first paragraph of the message, on one line.
function subject(message) {
  const lines = messageLines(message);
  const end = lines.indexOf("");
  return (end === -1 ? lines : lines.slice(0, end)).join(" ");
}

function formatMedium(gitDir, oid, commit) {
  const author = parseIdentity(commit.author);
  const body = messageLines(commit.message).map((line) => `${INDENT}${expandTabs(line)}\n`).join("");
  const merge = commit.parents.length > 1 ? `Merge: ${commit.parents.map((p) => abbreviate(gitDir, p)).join(" ")}\n` : "";
  return `commit ${oid}\n${merge}Author: ${author.name} <${author.email}>\nDate:   ${formatDate(author)}\n\n${body}`;
}

function run(args, { cwd, stdout }) {
  const repo = requireRepository(cwd);
  const options = parseArgs(args);
  const head = readHead(repo.gitDir);
  if (!head.oid) throw new GitError(`your current branch '${branchName(head.branch ?? "HEAD")}' does not have any commits yet`);

  let shown = 0;
  for (const { oid, commit } of walkCommits(repo.gitDir, [head.oid])) {
    if (shown === options.maxCount) break;
    if (options.oneline) stdout.write(`${abbreviate(repo.gitDir, oid)} ${subject(commit.message)}\n`);
    else stdout.write(`${shown > 0 ? "\n" : ""}${formatMedium(repo.gitDir, oid, commit)}`);
    shown++;
  }
}

export default { name: "log", run };
