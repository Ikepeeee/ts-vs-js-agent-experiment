import { parseOptions, UsageError } from "../cli/options.js";
import { quotePath } from "../cli/quote.js";
import { Index } from "../core/index/index.js";
import { isInside } from "../core/paths.js";
import { requireRepository, toCwdPath } from "../core/repo/repository.js";

const USAGE = "tgit ls-files [-s | --stage]";
const OPTIONS = [{ key: "stage", short: "s", long: "stage" }];

// Lists the index entries inside the current directory, with paths relative to it.
function run(argv, { cwd, stdout }) {
  const repo = requireRepository(cwd);
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  if (args.length > 0) throw new UsageError("paths are not supported", USAGE);
  for (const entry of Index.read(repo.gitDir).entries()) {
    if (!isInside(entry.path, repo.prefix)) continue;
    const name = quotePath(toCwdPath(repo, entry.path));
    if (options.stage) stdout.write(`${entry.mode.toString(8).padStart(6, "0")} ${entry.oid} ${entry.stage}\t${name}\n`);
    else stdout.write(`${name}\n`);
  }
}

export default { name: "ls-files", run };
