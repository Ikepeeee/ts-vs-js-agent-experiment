import { parseOptions, UsageError } from "../cli/options.js";
import { quotePath } from "../cli/quote.js";
import { detectRenames } from "../core/diff/renames.js";
import { Index } from "../core/index/index.js";
import { sameType } from "../core/objects/modes.js";
import { flattenTree } from "../core/objects/tree.js";
import { readCommit } from "../core/objects/commit.js";
import { comparePaths } from "../core/paths.js";
import { readHead } from "../core/refs/refs.js";
import { requireRepository } from "../core/repo/repository.js";
import { hashWorktreeFile } from "../core/worktree/files.js";
import { IgnoreRules } from "../core/worktree/ignore.js";
import { findUntracked } from "../core/worktree/untracked.js";

const USAGE = "tgit status --porcelain";
const OPTIONS = [{ key: "porcelain", long: "porcelain" }];

// The status letter for a change from one { mode, oid } to another (either may be missing), or " " when unchanged.
function changeCode(from, to) {
  if (!from && !to) return " ";
  if (!from) return "A";
  if (!to) return "D";
  if (!sameType(from.mode, to.mode)) return "T";
  return from.mode !== to.mode || from.oid !== to.oid ? "M" : " ";
}

function headFiles(gitDir) {
  const { oid } = readHead(gitDir);
  return oid ? flattenTree(gitDir, readCommit(gitDir, oid).tree) : new Map();
}

function run(argv, { cwd, stdout }) {
  const repo = requireRepository(cwd);
  const { options, args } = parseOptions(argv, OPTIONS, USAGE);
  if (!options.porcelain || args.length > 0) throw new UsageError("only --porcelain is supported", USAGE);

  const head = headFiles(repo.gitDir);
  const index = Index.read(repo.gitDir);
  const paths = [...new Set([...head.keys(), ...index.byPath.keys()])].sort(comparePaths);
  // Staged deletions and additions may pair up as renames, shown under the new path.
  const deleted = paths.filter((path) => !index.get(path)).map((path) => ({ path, ...head.get(path) }));
  const added = paths.filter((path) => !head.has(path)).map((path) => index.get(path));
  const renames = detectRenames(repo.gitDir, deleted, added);
  const renamedAway = new Set(renames.values());
  const quote = (path) => quotePath(path, { quoteSpaces: true });
  for (const path of paths) {
    if (renamedAway.has(path)) continue;
    const entry = index.get(path);
    const source = renames.get(path);
    const staged = source ? "R" : changeCode(head.get(path), entry);
    const unstaged = entry ? changeCode(entry, hashWorktreeFile(repo, path)) : " ";
    const shown = source ? `${quote(source)} -> ${quote(path)}` : quote(path);
    if (staged !== " " || unstaged !== " ") stdout.write(`${staged}${unstaged} ${shown}\n`);
  }
  for (const path of findUntracked(repo, index, IgnoreRules.load(repo.workTree), { collapseDirectories: true })) {
    stdout.write(`?? ${quote(path)}\n`);
  }
}

export default { name: "status", run };
