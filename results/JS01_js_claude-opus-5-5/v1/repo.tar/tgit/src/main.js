#!/usr/bin/env node
import { reportError } from "./cli/report.js";
import { commands } from "./commands/registry.js";

// Exit code of the real git for an unknown or missing command.
const UNKNOWN_COMMAND = 1;

function main(argv) {
  const [name, ...args] = argv;
  const context = { cwd: process.cwd(), env: process.env, stdout: process.stdout, stderr: process.stderr };
  if (name === undefined) {
    context.stderr.write(`usage: tgit <command> [<args>]\n\ncommands: ${[...commands.keys()].join(", ")}\n`);
    return UNKNOWN_COMMAND;
  }
  const command = commands.get(name);
  if (!command) {
    context.stderr.write(`tgit: '${name}' is not a tgit command.\n`);
    return UNKNOWN_COMMAND;
  }
  try {
    return command.run(args, context) ?? 0;
  } catch (error) {
    return reportError(error, context.stderr);
  }
}

process.exitCode = main(process.argv.slice(2));
