import { isRegularMode } from "../objects/modes.js";
import { readObject } from "../objects/store.js";

// Rename detection between deleted and added files, ported from git's diffcore-rename with the
// settings `git status` uses: renames only (no copies) and a minimum similarity of 50%.
// It runs in three passes, as git does: identical contents, then files with the same unique basename,
// then the most similar pairs among the rest.

const MAX_SCORE = 60000;
const MIN_SCORE = 30000;
// Pairs found by basename alone must be more similar: halfway between the minimum and identical.
const MIN_BASENAME_SCORE = MIN_SCORE + (MAX_SCORE - MIN_SCORE) / 2;
const CANDIDATES_PER_DESTINATION = 4;
const MAX_IDENTICAL_CANDIDATES = 100;
const HASHBASE = 107927;
const MAX_SPAN = 64;
const BINARY_CHECK_BYTES = 8000;

function basename(path) {
  return path.slice(path.lastIndexOf("/") + 1);
}

// 1 when the two paths have the same last component, 0 otherwise.
function basenameScore(a, b) {
  return basename(a) === basename(b) ? 1 : 0;
}

// The file's content split into spans ending at a newline or after 64 bytes, as a map from each span's
// hash to the total number of bytes in spans with that hash. Text files ignore the CR of a CRLF.
function spanCounts(data) {
  const isText = !data.subarray(0, BINARY_CHECK_BYTES).includes(0);
  const counts = new Map();
  let length = 0;
  let accum1 = 0;
  let accum2 = 0;
  const addSpan = () => {
    const hash = ((accum1 + Math.imul(accum2, 0x61)) >>> 0) % HASHBASE;
    counts.set(hash, (counts.get(hash) ?? 0) + length);
  };
  for (let i = 0; i < data.length; i++) {
    const c = data[i];
    if (isText && c === 0x0d && data[i + 1] === 0x0a) continue;
    const old1 = accum1;
    accum1 = ((((accum1 << 7) ^ (accum2 >>> 25)) >>> 0) + c) >>> 0;
    accum2 = ((accum2 << 7) ^ (old1 >>> 25)) >>> 0;
    if (++length < MAX_SPAN && c !== 0x0a) continue;
    addSpan();
    length = accum1 = accum2 = 0;
  }
  if (length > 0) addSpan();
  return counts;
}

// A deleted or added file, with its content loaded on first use.
class Candidate {
  constructor(gitDir, { path, mode, oid }) {
    Object.assign(this, { gitDir, path, mode, oid, used: false, source: null });
  }

  get content() {
    this.data ??= readObject(this.gitDir, this.oid).content;
    return this.data;
  }

  get spans() {
    this.spanData ??= spanCounts(this.content);
    return this.spanData;
  }
}

// How much of the destination's content comes from the source, from 0 to MAX_SCORE.
// Only regular files are compared; other kinds are renamed only when identical.
function similarity(source, destination, minimumScore) {
  if (!isRegularMode(source.mode) || !isRegularMode(destination.mode)) return 0;
  const sourceSize = source.content.length;
  const destinationSize = destination.content.length;
  const maxSize = Math.max(sourceSize, destinationSize);
  const sizeDifference = maxSize - Math.min(sourceSize, destinationSize);
  if (maxSize * (MAX_SCORE - minimumScore) < sizeDifference * MAX_SCORE) return 0;
  let copied = 0;
  for (const [hash, count] of source.spans) copied += Math.min(count, destination.spans.get(hash) ?? 0);
  return destinationSize === 0 ? 0 : Math.floor((copied * MAX_SCORE) / maxSize);
}

function recordRename(source, destination) {
  destination.source = source;
  source.used = true;
}

function findIdenticalRenames(sources, destinations) {
  for (const destination of destinations) {
    let best = null;
    let bestScore = -1;
    let remaining = MAX_IDENTICAL_CANDIDATES;
    for (const source of sources) {
      if (source.oid !== destination.oid || source.used) continue;
      const bothRegular = isRegularMode(source.mode) && isRegularMode(destination.mode);
      if (!bothRegular && source.mode !== destination.mode) continue;
      const score = 1 + basenameScore(source.path, destination.path);
      if (score > bestScore) {
        best = source;
        bestScore = score;
        if (score === 2) break;
      }
      if (--remaining === 0) break;
    }
    if (best) recordRename(best, destination);
  }
}

// Maps each basename that occurs exactly once among the candidates to that candidate.
function uniqueBasenames(candidates) {
  const byName = new Map();
  for (const candidate of candidates) {
    const name = basename(candidate.path);
    byName.set(name, byName.has(name) ? null : candidate);
  }
  return byName;
}

function findBasenameRenames(sources, destinations) {
  const uniqueSources = uniqueBasenames(sources);
  const uniqueDestinations = uniqueBasenames(destinations.filter((d) => !d.source));
  for (const source of sources) {
    const name = basename(source.path);
    const destination = uniqueDestinations.get(name);
    if (!uniqueSources.get(name) || !destination || destination.source) continue;
    if (similarity(source, destination, MIN_BASENAME_SCORE) >= MIN_BASENAME_SCORE) recordRename(source, destination);
  }
}

// Orders pairs from the most to the least similar, preferring the same basename on equal scores.
// Unused slots (without a destination) sort last.
function comparePairs(a, b) {
  if (!a.destination) return b.destination ? 1 : 0;
  if (!b.destination) return -1;
  if (a.score === b.score) return b.nameScore - a.nameScore;
  return b.score - a.score;
}

// Keeps the best few candidates for one destination in fixed slots, replacing the worst one.
function recordIfBetter(slots, pair) {
  let worst = 0;
  for (let i = 1; i < slots.length; i++) {
    if (comparePairs(slots[i], slots[worst]) > 0) worst = i;
  }
  if (comparePairs(slots[worst], pair) > 0) slots[worst] = pair;
}

function findSimilarRenames(sources, destinations) {
  const pairs = [];
  for (const destination of destinations.filter((d) => !d.source)) {
    const slots = Array.from({ length: CANDIDATES_PER_DESTINATION }, () => ({ destination: null }));
    for (const source of sources) {
      const score = similarity(source, destination, MIN_SCORE);
      recordIfBetter(slots, { source, destination, score, nameScore: basenameScore(source.path, destination.path) });
    }
    pairs.push(...slots);
  }
  pairs.sort(comparePairs);
  for (const { source, destination, score } of pairs) {
    if (!destination || score < MIN_SCORE) break;
    if (destination.source || source.used) continue;
    recordRename(source, destination);
  }
}

// Takes the deleted and the added files as { path, mode, oid }, each sorted by path, and returns
// a map from each renamed destination path to its source path.
export function detectRenames(gitDir, deleted, added) {
  const destinations = added.map((file) => new Candidate(gitDir, file));
  let sources = deleted.map((file) => new Candidate(gitDir, file));
  findIdenticalRenames(sources, destinations);
  sources = sources.filter((source) => !source.used);
  findBasenameRenames(sources, destinations);
  sources = sources.filter((source) => !source.used);
  findSimilarRenames(sources, destinations);
  return new Map(destinations.filter((d) => d.source).map((d) => [d.path, d.source.path]));
}
