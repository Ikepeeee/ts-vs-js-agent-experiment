import fs from "node:fs";
import path from "node:path";
import { statData } from "../index/index-file.js";
import { MODE_EXECUTABLE, MODE_SYMLINK, modeFromStat } from "../objects/modes.js";
import { hashObject, readObject, writeObject } from "../objects/store.js";
import { GitError } from "../errors.js";
import { worktreePath } from "../repo/repository.js";

export function lstatOrNull(file) {
  try {
    return fs.lstatSync(file, { bigint: true });
  } catch (e) {
    if (e.code === "ENOENT" || e.code === "ENOTDIR") return null;
    throw e;
  }
}

// The content git stores for a working tree file: the file's bytes, or a symlink's target.
// Returns { mode, content, stat }, or null when there is no file or symlink at the path.
export function readWorktreeFile(repo, repoPath) {
  const file = worktreePath(repo, repoPath);
  const stat = lstatOrNull(file);
  const mode = stat && modeFromStat(stat);
  if (!mode) return null;
  const content = mode === MODE_SYMLINK ? fs.readlinkSync(file, { encoding: "buffer" }) : fs.readFileSync(file);
  return { mode, content, stat: statData(stat) };
}

// Like readWorktreeFile, with the blob ID instead of the content. Nothing is written.
export function hashWorktreeFile(repo, repoPath) {
  const file = readWorktreeFile(repo, repoPath);
  return file && { mode: file.mode, oid: hashObject("blob", file.content), stat: file.stat };
}

// Writes the file's blob and returns its index entry, or null when there is no file at the path.
export function stageWorktreeFile(repo, repoPath) {
  const file = readWorktreeFile(repo, repoPath);
  if (!file) return null;
  const oid = writeObject(repo.gitDir, "blob", file.content);
  return { path: repoPath, mode: file.mode, oid, stage: 0, stat: file.stat };
}

// Whether the working tree has the entry's content and mode. A missing file does not match.
export function worktreeMatches(repo, entry) {
  const current = hashWorktreeFile(repo, entry.path);
  return current !== null && current.mode === entry.mode && current.oid === entry.oid;
}

// Removes whatever is at file so that something else can be written there.
function clearPath(file) {
  const stat = lstatOrNull(file);
  if (stat?.isDirectory()) fs.rmSync(file, { recursive: true, force: true });
  else if (stat) fs.unlinkSync(file);
}

// Writes a blob to the working tree and returns its index entry.
export function checkoutBlob(repo, repoPath, mode, oid) {
  const object = readObject(repo.gitDir, oid);
  if (!object || object.type !== "blob") throw new GitError(`unable to read blob ${oid} for '${repoPath}'`);
  const file = worktreePath(repo, repoPath);
  let dir = repo.workTree;
  for (const part of repoPath.split("/").slice(0, -1)) {
    dir = path.join(dir, part);
    const stat = lstatOrNull(dir);
    if (stat && !stat.isDirectory()) fs.unlinkSync(dir);
    if (!stat?.isDirectory()) fs.mkdirSync(dir);
  }
  clearPath(file);
  if (mode === MODE_SYMLINK) fs.symlinkSync(object.content, file);
  else fs.writeFileSync(file, object.content, { mode: mode === MODE_EXECUTABLE ? 0o777 : 0o666 });
  return { path: repoPath, mode, oid, stage: 0, stat: statData(fs.lstatSync(file, { bigint: true })) };
}

// Deletes a file from the working tree, then its parent directories that became empty.
export function removeWorktreeFile(repo, repoPath) {
  const file = worktreePath(repo, repoPath);
  const stat = lstatOrNull(file);
  if (!stat) return;
  if (stat.isDirectory()) return;
  fs.unlinkSync(file);
  for (let dir = path.dirname(file); dir !== repo.workTree; dir = path.dirname(dir)) {
    try {
      fs.rmdirSync(dir);
    } catch {
      break;
    }
  }
}
