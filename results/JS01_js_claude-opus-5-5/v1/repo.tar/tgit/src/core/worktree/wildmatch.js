// A port of git's wildmatch(), used for .gitignore patterns. Works on bytes.
// With pathname set, "*" and "?" do not match "/", and "**" matches across directories.

const MATCH = 0;
const NO_MATCH = 1;
const ABORT_ALL = -1;
const ABORT_TO_STARSTAR = -2;

const SLASH = 0x2f;
const BACKSLASH = 0x5c;
const STAR = 0x2a;
const QUESTION = 0x3f;
const OPEN_BRACKET = 0x5b;
const CLOSE_BRACKET = 0x5d;
const DASH = 0x2d;

function isGlobSpecial(c) {
  return c === STAR || c === QUESTION || c === OPEN_BRACKET || c === BACKSLASH;
}

// Matches a bracket expression starting after "[". Returns [matched, position of "]"] or null if unterminated.
function matchClass(p, pi, t) {
  let negated = false;
  if (p[pi] === 0x21 || p[pi] === 0x5e) {
    negated = true;
    pi++;
  }
  let matched = false;
  let prev = 0;
  let c = p[pi];
  do {
    if (c === undefined) return null;
    if (c === BACKSLASH) {
      c = p[++pi];
      if (c === undefined) return null;
      if (t === c) matched = true;
    } else if (c === DASH && prev && p[pi + 1] !== undefined && p[pi + 1] !== CLOSE_BRACKET) {
      c = p[++pi];
      if (c === BACKSLASH) {
        c = p[++pi];
        if (c === undefined) return null;
      }
      if (t <= c && t >= prev) matched = true;
      c = 0;
    } else if (t === c) {
      matched = true;
    }
    prev = c;
    c = p[++pi];
  } while (c !== CLOSE_BRACKET);
  return [matched !== negated, pi];
}

function dowild(p, pi, t, ti, pathname) {
  for (; pi < p.length; pi++, ti++) {
    let pc = p[pi];
    const tc = t[ti];
    if (tc === undefined && pc !== STAR) return ABORT_ALL;
    switch (pc) {
      case BACKSLASH:
        pc = p[++pi];
        if (tc !== pc) return NO_MATCH;
        continue;
      case QUESTION:
        if (pathname && tc === SLASH) return NO_MATCH;
        continue;
      case STAR: {
        let matchSlash;
        if (p[++pi] === STAR) {
          const prevP = pi - 2;
          while (p[++pi] === STAR);
          if (
            (prevP < 0 || p[prevP] === SLASH) &&
            (pi >= p.length || p[pi] === SLASH || (p[pi] === BACKSLASH && p[pi + 1] === SLASH))
          ) {
            if (p[pi] === SLASH && dowild(p, pi + 1, t, ti, pathname) === MATCH) return MATCH;
            matchSlash = true;
          } else {
            matchSlash = false;
          }
        } else {
          matchSlash = !pathname;
        }
        if (pi >= p.length) {
          if (!matchSlash && t.indexOf(SLASH, ti) !== -1) return NO_MATCH;
          return MATCH;
        }
        if (!matchSlash && p[pi] === SLASH) {
          const slash = t.indexOf(SLASH, ti);
          if (slash === -1) return NO_MATCH;
          ti = slash;
          break;
        }
        for (;;) {
          if (ti >= t.length) break;
          if (!isGlobSpecial(p[pi])) {
            const literal = p[pi];
            while (ti < t.length && (matchSlash || t[ti] !== SLASH) && t[ti] !== literal) ti++;
            if (t[ti] !== literal) return matchSlash ? ABORT_ALL : ABORT_TO_STARSTAR;
          }
          const result = dowild(p, pi, t, ti, pathname);
          if (result !== NO_MATCH) {
            if (!matchSlash || result !== ABORT_TO_STARSTAR) return result;
          } else if (!matchSlash && t[ti] === SLASH) {
            return ABORT_TO_STARSTAR;
          }
          ti++;
        }
        return ABORT_ALL;
      }
      case OPEN_BRACKET: {
        const result = matchClass(p, pi + 1, tc);
        if (!result) return ABORT_ALL;
        pi = result[1];
        if (!result[0] || (pathname && tc === SLASH)) return NO_MATCH;
        continue;
      }
      default:
        if (tc !== pc) return NO_MATCH;
        continue;
    }
  }
  return ti < t.length ? NO_MATCH : MATCH;
}

export function wildmatch(pattern, text, { pathname = false } = {}) {
  return dowild(Buffer.from(pattern), 0, Buffer.from(text), 0, pathname) === MATCH;
}
