import fs from "node:fs";
import path from "node:path";
import { comparePaths, joinPath } from "../paths.js";

function readDirectory(repo, dir) {
  const entries = fs.readdirSync(path.join(repo.workTree, dir), { withFileTypes: true });
  return entries.filter((entry) => entry.name !== ".git");
}

function isFileLike(entry) {
  return entry.isFile() || entry.isSymbolicLink();
}

// Whether the directory holds a file that is neither tracked nor ignored.
function hasUntrackedFile(repo, index, ignore, dir) {
  return readDirectory(repo, dir).some((entry) => {
    const repoPath = joinPath(dir, entry.name);
    if (entry.isDirectory()) return !ignore.matchesItself(repoPath, true) && hasUntrackedFile(repo, index, ignore, repoPath);
    return isFileLike(entry) && !index.has(repoPath) && !ignore.matchesItself(repoPath, false);
  });
}

// Lists the files in the working tree that are neither in the index nor ignored, sorted.
// Ignored directories are not entered. With collapseDirectories, a directory that has no
// tracked files is listed once as "dir/" (if it holds any untracked file), as "git status" shows it.
export function findUntracked(repo, index, ignore, { collapseDirectories = false } = {}) {
  const result = [];
  const visit = (dir) => {
    for (const entry of readDirectory(repo, dir)) {
      const repoPath = joinPath(dir, entry.name);
      if (entry.isDirectory()) {
        if (ignore.matchesItself(repoPath, true)) continue;
        if (collapseDirectories && !index.hasEntriesInside(repoPath)) {
          if (hasUntrackedFile(repo, index, ignore, repoPath)) result.push(`${repoPath}/`);
        } else {
          visit(repoPath);
        }
      } else if (isFileLike(entry) && !index.has(repoPath) && !ignore.matchesItself(repoPath, false)) {
        result.push(repoPath);
      }
    }
  };
  visit("");
  return result.sort(comparePaths);
}
