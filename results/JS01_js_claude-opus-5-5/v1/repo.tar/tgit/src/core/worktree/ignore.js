import fs from "node:fs";
import path from "node:path";
import { leadingDirectories } from "../paths.js";
import { wildmatch } from "./wildmatch.js";

// Patterns from the .gitignore at the root of the work tree.

// Trailing spaces are dropped unless escaped with a backslash.
function trimTrailingSpaces(line) {
  let end = line.length;
  while (end > 0 && line[end - 1] === " ") {
    let backslashes = 0;
    for (let i = end - 2; i >= 0 && line[i] === "\\"; i--) backslashes++;
    if (backslashes % 2 === 1) break;
    end--;
  }
  return line.slice(0, end);
}

export function parsePattern(line) {
  let text = trimTrailingSpaces(line);
  if (text === "" || text.startsWith("#")) return null;
  const pattern = { negative: false, mustBeDir: false, basenameOnly: false, text: "" };
  if (text.startsWith("!")) {
    pattern.negative = true;
    text = text.slice(1);
  }
  if (text.endsWith("/")) {
    pattern.mustBeDir = true;
    text = text.slice(0, -1);
  }
  if (!text.includes("/")) pattern.basenameOnly = true;
  else if (text.startsWith("/")) text = text.slice(1);
  if (text === "") return null;
  pattern.text = text;
  return pattern;
}

export function parseIgnoreFile(content) {
  return content
    .replace(/^\uFEFF/, "")
    .split("\n")
    .map((line) => parsePattern(line.replace(/\r$/, "")))
    .filter(Boolean);
}

function matches(pattern, repoPath, isDir) {
  if (pattern.mustBeDir && !isDir) return false;
  if (pattern.basenameOnly) return wildmatch(pattern.text, path.posix.basename(repoPath));
  return wildmatch(pattern.text, repoPath, { pathname: true });
}

export class IgnoreRules {
  constructor(patterns = []) {
    this.patterns = patterns;
  }

  static load(workTree) {
    let content;
    try {
      content = fs.readFileSync(path.join(workTree, ".gitignore"), "utf8");
    } catch (e) {
      if (e.code === "ENOENT" || e.code === "ENOTDIR" || e.code === "EISDIR") return new IgnoreRules();
      throw e;
    }
    return new IgnoreRules(parseIgnoreFile(content));
  }

  // Whether the path itself matches, ignoring its parent directories. The last matching pattern decides.
  matchesItself(repoPath, isDir) {
    for (let i = this.patterns.length - 1; i >= 0; i--) {
      if (matches(this.patterns[i], repoPath, isDir)) return !this.patterns[i].negative;
    }
    return false;
  }

  // The first leading directory of the path that is ignored, or null.
  // Everything inside an ignored directory is ignored, and a pattern cannot re-include it.
  ignoredParent(repoPath) {
    return leadingDirectories(repoPath).find((dir) => this.matchesItself(dir, true)) ?? null;
  }

  isIgnored(repoPath, isDir) {
    return this.ignoredParent(repoPath) !== null || this.matchesItself(repoPath, isDir);
  }
}
