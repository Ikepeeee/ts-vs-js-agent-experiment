import { readCommit } from "../objects/commit.js";
import { findObjectsByPrefix, MIN_ABBREV_LENGTH } from "../objects/store.js";
import { isValidRefName } from "../refs/refname.js";
import { resolveRef } from "../refs/refs.js";

// How a short name is looked up as a reference, in order (git's "ref_rev_parse_rules").
const REF_RULES = [
  (name) => name,
  (name) => `refs/${name}`,
  (name) => `refs/tags/${name}`,
  (name) => `refs/heads/${name}`,
  (name) => `refs/remotes/${name}`,
  (name) => `refs/remotes/${name}/HEAD`,
];

// Only references under refs/ and all-caps names such as HEAD are looked up directly in .git.
function isRootOrFullRef(name) {
  return /^[A-Z_]+$/.test(name) || name.startsWith("refs/");
}

function resolveName(gitDir, name) {
  if (/^[0-9a-fA-F]{40}$/.test(name)) return name.toLowerCase();
  for (const rule of REF_RULES) {
    const ref = rule(name);
    if (ref === name && !isRootOrFullRef(name)) continue;
    if (!isValidRefName(ref)) continue;
    const oid = resolveRef(gitDir, ref)?.oid;
    if (oid) return oid;
  }
  if (name.length >= MIN_ABBREV_LENGTH && /^[0-9a-fA-F]+$/.test(name)) {
    const candidates = findObjectsByPrefix(gitDir, name.toLowerCase());
    if (candidates.length === 1) return candidates[0];
  }
  return null;
}

function parent(gitDir, oid, n) {
  const commit = readCommit(gitDir, oid);
  if (!commit) return null;
  if (n === 0) return oid;
  return commit.parents[n - 1] ?? null;
}

// Resolves a revision such as "main", "HEAD~2^", or a full or abbreviated object ID.
// Returns the object ID, or null when the revision does not name an object.
// A full 40-digit ID is returned even if no such object exists, as the real git does.
export function resolveRevision(gitDir, spec) {
  const match = /^([^~^]+)((?:[~^]\d*)*)$/.exec(spec);
  if (!match) return null;
  let oid = resolveName(gitDir, match[1]);
  for (const [, op, digits] of match[2].matchAll(/([~^])(\d*)/g)) {
    if (oid === null) break;
    const n = digits === "" ? 1 : Number(digits);
    if (op === "^") oid = parent(gitDir, oid, n);
    else for (let i = 0; i < n && oid !== null; i++) oid = parent(gitDir, oid, 1);
  }
  return oid;
}

// Resolves a revision that must name a commit; returns null otherwise.
export function resolveCommit(gitDir, spec) {
  const oid = resolveRevision(gitDir, spec);
  return oid && readCommit(gitDir, oid) ? oid : null;
}
