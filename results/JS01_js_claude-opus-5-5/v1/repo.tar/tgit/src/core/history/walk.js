import { GitError } from "../errors.js";
import { readCommit } from "../objects/commit.js";
import { parseIdentity } from "../objects/identity.js";

// Yields { oid, commit } for every commit reachable from the start commits, most recent
// committer date first (ties in the order the commits were found), as "git log" does by default.
export function* walkCommits(gitDir, starts) {
  const queue = [];
  const seen = new Set();
  let found = 0;
  const add = (oid) => {
    if (seen.has(oid)) return;
    seen.add(oid);
    const commit = readCommit(gitDir, oid);
    if (!commit) throw new GitError(`could not read commit ${oid}`);
    queue.push({ oid, commit, date: parseIdentity(commit.committer).timestamp, order: found++ });
  };
  starts.forEach(add);
  while (queue.length > 0) {
    let best = 0;
    for (let i = 1; i < queue.length; i++) {
      const a = queue[i];
      const b = queue[best];
      if (a.date > b.date || (a.date === b.date && a.order < b.order)) best = i;
    }
    const [next] = queue.splice(best, 1);
    yield { oid: next.oid, commit: next.commit };
    next.commit.parents.forEach(add);
  }
}

// Whether ancestor is reachable from descendant (a commit is its own ancestor).
export function isAncestor(gitDir, ancestor, descendant) {
  for (const { oid } of walkCommits(gitDir, [descendant])) {
    if (oid === ancestor) return true;
  }
  return false;
}
