import fs from "node:fs";
import path from "node:path";
import { GitError } from "../errors.js";

// A repository: { gitDir, workTree, cwd, prefix }, where prefix is the current directory
// relative to the work tree root ("" at the root).

function isGitDir(dir) {
  try {
    return (
      fs.statSync(path.join(dir, "objects")).isDirectory() &&
      fs.statSync(path.join(dir, "refs")).isDirectory() &&
      fs.statSync(path.join(dir, "HEAD")).isFile()
    );
  } catch {
    return false;
  }
}

function toPosix(p) {
  return p.split(path.sep).join("/");
}

// Searches cwd and its parents for a ".git" directory, as the real git does.
export function findRepository(cwd) {
  for (let dir = cwd; ; dir = path.dirname(dir)) {
    const gitDir = path.join(dir, ".git");
    if (isGitDir(gitDir)) return { gitDir, workTree: dir, cwd, prefix: toPosix(path.relative(dir, cwd)) };
    if (path.dirname(dir) === dir) return null;
  }
}

export function requireRepository(cwd) {
  const repo = findRepository(cwd);
  if (!repo) throw new GitError("not a git repository (or any of the parent directories): .git");
  return repo;
}

// Converts a path given on the command line (relative to the current directory) to a repository path.
export function toRepoPath(repo, arg) {
  const relative = toPosix(path.relative(repo.workTree, path.resolve(repo.cwd, arg)));
  if (relative === ".." || relative.startsWith("../") || path.isAbsolute(relative)) {
    throw new GitError(`${arg}: '${arg}' is outside repository at '${repo.workTree}'`);
  }
  return relative;
}

// Converts a repository path to a path relative to the current directory.
export function toCwdPath(repo, repoPath) {
  return toPosix(path.relative(repo.cwd, path.join(repo.workTree, repoPath)));
}

export function worktreePath(repo, repoPath) {
  return path.join(repo.workTree, repoPath);
}
