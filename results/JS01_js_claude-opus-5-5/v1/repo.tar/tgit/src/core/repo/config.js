import fs from "node:fs";
import path from "node:path";

const ESCAPES = { n: "\n", t: "\t", b: "\b", '"': '"', "\\": "\\" };

// Reads one value starting at text[pos], following git's rules for quotes, escapes,
// comments and line continuations. Returns [value, position after the line].
function parseValue(text, pos) {
  let value = "";
  let pending = "";
  let quoted = false;
  while (pos < text.length) {
    const c = text[pos++];
    if (c === "\n") {
      if (!quoted) break;
      value += pending + c;
      pending = "";
    } else if (!quoted && (c === "#" || c === ";")) {
      while (pos < text.length && text[pos] !== "\n") pos++;
    } else if (c === '"') {
      value += pending;
      pending = "";
      quoted = !quoted;
    } else if (c === "\\") {
      const next = text[pos++];
      if (next === "\n") continue;
      if (next === "\r" && text[pos] === "\n") {
        pos++;
        continue;
      }
      value += pending + (ESCAPES[next] ?? next);
      pending = "";
    } else if (!quoted && (c === " " || c === "\t" || c === "\r")) {
      if (value !== "") pending += c;
    } else {
      value += pending + c;
      pending = "";
    }
  }
  return [value, pos];
}

// Entries: { key, value } with key as "section.name" or "section.subsection.name";
// section and name are lowercased, the subsection keeps its case. A key without "=" has the value true.
export function parseConfig(text) {
  const entries = [];
  let section = "";
  let pos = 0;
  while (pos < text.length) {
    while (pos < text.length && /[ \t\r\n]/.test(text[pos])) pos++;
    if (pos >= text.length) break;
    const c = text[pos];
    if (c === "#" || c === ";") {
      while (pos < text.length && text[pos] !== "\n") pos++;
    } else if (c === "[") {
      const end = text.indexOf("]", pos);
      const header = text.slice(pos + 1, end === -1 ? text.length : end);
      const sub = /^\s*([^\s"]+)\s+"((?:[^"\\]|\\.)*)"\s*$/.exec(header);
      if (sub) section = `${sub[1].toLowerCase()}.${sub[2].replace(/\\(.)/g, "$1")}`;
      else {
        const dot = header.indexOf(".");
        section = dot === -1 ? header.trim().toLowerCase() : `${header.slice(0, dot).toLowerCase()}${header.slice(dot).trim()}`;
      }
      pos = end === -1 ? text.length : end + 1;
    } else {
      const match = /^[A-Za-z][A-Za-z0-9-]*/.exec(text.slice(pos, pos + 256));
      if (!match) {
        while (pos < text.length && text[pos] !== "\n") pos++;
        continue;
      }
      const key = `${section}.${match[0].toLowerCase()}`;
      pos += match[0].length;
      while (text[pos] === " " || text[pos] === "\t") pos++;
      if (text[pos] === "=") {
        const [value, next] = parseValue(text, pos + 1);
        entries.push({ key, value });
        pos = next;
      } else {
        entries.push({ key, value: true });
        while (pos < text.length && text[pos] !== "\n") pos++;
      }
    }
  }
  return entries;
}

export function readConfigFile(file) {
  try {
    return parseConfig(fs.readFileSync(file, "utf8"));
  } catch (e) {
    if (e.code === "ENOENT") return [];
    throw e;
  }
}

// The global configuration ($HOME/.gitconfig) followed by the repository's own, so later entries win.
export function loadConfig(env, gitDir = null) {
  const global = env.HOME ? readConfigFile(path.join(env.HOME, ".gitconfig")) : [];
  return gitDir ? [...global, ...readConfigFile(path.join(gitDir, "config"))] : global;
}

export function configValue(entries, key) {
  const [section, ...rest] = key.split(".");
  const name = rest.pop().toLowerCase();
  const wanted = [section.toLowerCase(), ...rest, name].join(".");
  return entries.findLast((e) => e.key === wanted)?.value;
}

// Sets "<section>.<name> = <value>" in a config file, replacing an existing value in place.
// Only plain sections (without a subsection) are supported, which is all that tgit writes.
export function setConfigValue(file, section, name, value) {
  const text = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
  const lines = text === "" ? [] : text.replace(/\n$/, "").split("\n");
  const headerPattern = /^\s*\[([^\]"]*)\]/;
  const keyPattern = new RegExp(`^\\s*${name}\\s*(=|$)`, "i");
  let inSection = false;
  let insertAt = -1;
  for (let i = 0; i < lines.length; i++) {
    const header = headerPattern.exec(lines[i]);
    if (header) {
      inSection = header[1].trim().toLowerCase() === section.toLowerCase();
      if (inSection) insertAt = i + 1;
      continue;
    }
    if (!inSection) continue;
    if (keyPattern.test(lines[i])) {
      lines[i] = `\t${name} = ${value}`;
      fs.writeFileSync(file, `${lines.join("\n")}\n`);
      return;
    }
    if (lines[i].trim() !== "") insertAt = i + 1;
  }
  if (insertAt === -1) lines.push(`[${section}]`, `\t${name} = ${value}`);
  else lines.splice(insertAt, 0, `\t${name} = ${value}`);
  fs.writeFileSync(file, `${lines.join("\n")}\n`);
}
