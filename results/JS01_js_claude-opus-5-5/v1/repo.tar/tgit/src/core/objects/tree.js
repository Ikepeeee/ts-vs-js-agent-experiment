import { comparePaths, joinPath } from "../paths.js";
import { isTreeMode } from "./modes.js";
import { GitError } from "../errors.js";
import { readObject } from "./store.js";

// Entries: { mode, name, oid }, with mode as a number.
export function parseTree(content) {
  const entries = [];
  let pos = 0;
  while (pos < content.length) {
    const space = content.indexOf(0x20, pos);
    const nul = content.indexOf(0, space);
    const mode = parseInt(content.subarray(pos, space).toString(), 8);
    const name = content.subarray(space + 1, nul).toString();
    const oid = content.subarray(nul + 1, nul + 21).toString("hex");
    entries.push({ mode, name, oid });
    pos = nul + 21;
  }
  return entries;
}

// Trees sort their entries by name, comparing a directory as if its name ended with "/".
function treeSortKey(entry) {
  return isTreeMode(entry.mode) ? `${entry.name}/` : entry.name;
}

export function serializeTree(entries) {
  const sorted = [...entries].sort((a, b) => comparePaths(treeSortKey(a), treeSortKey(b)));
  return Buffer.concat(
    sorted.flatMap((e) => [Buffer.from(`${e.mode.toString(8)} ${e.name}\0`), Buffer.from(e.oid, "hex")]),
  );
}

export function readTree(gitDir, oid) {
  const object = readObject(gitDir, oid);
  if (!object || object.type !== "tree") throw new GitError(`unable to read tree ${oid}`);
  return parseTree(object.content);
}

// All non-tree entries reachable from a tree, as a Map from path to { mode, oid }.
export function flattenTree(gitDir, oid, prefix = "", into = new Map()) {
  for (const entry of readTree(gitDir, oid)) {
    const path = joinPath(prefix, entry.name);
    if (isTreeMode(entry.mode)) flattenTree(gitDir, entry.oid, path, into);
    else into.set(path, { mode: entry.mode, oid: entry.oid });
  }
  return into;
}
