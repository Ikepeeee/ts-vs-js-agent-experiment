import { GitError } from "../errors.js";

// "Name <email> 1700000000 +0000" -> { name, email, timestamp, timezone }
export function parseIdentity(line) {
  const match = /^(.*?) ?<(.*)> (\d+) ([+-]\d{4})$/.exec(line);
  if (!match) return { name: line, email: "", timestamp: 0, timezone: "+0000" };
  return { name: match[1], email: match[2], timestamp: Number(match[3]), timezone: match[4] };
}

function localTimezone(date) {
  const offset = -date.getTimezoneOffset();
  const abs = Math.abs(offset);
  return `${offset < 0 ? "-" : "+"}${String(Math.floor(abs / 60)).padStart(2, "0")}${String(abs % 60).padStart(2, "0")}`;
}

// Accepts git's raw date format ("<seconds> <offset>", optionally prefixed with "@").
function parseDate(text, variable) {
  if (text === undefined || text === "") {
    const now = new Date();
    return `${Math.floor(now.getTime() / 1000)} ${localTimezone(now)}`;
  }
  const match = /^@?(\d+)(?: ([+-]\d{4}))?$/.exec(text.trim());
  if (!match) throw new GitError(`invalid date format in ${variable}: ${text}`);
  return `${match[1]} ${match[2] ?? localTimezone(new Date(Number(match[1]) * 1000))}`;
}

// The identity line for "AUTHOR" or "COMMITTER", taken from the GIT_<kind>_* environment variables.
export function identityFromEnv(kind, env) {
  const name = env[`GIT_${kind}_NAME`];
  const email = env[`GIT_${kind}_EMAIL`];
  if (!name || email === undefined) {
    throw new GitError(`${kind.toLowerCase()} identity unknown: set GIT_${kind}_NAME and GIT_${kind}_EMAIL`);
  }
  return `${name} <${email}> ${parseDate(env[`GIT_${kind}_DATE`], `GIT_${kind}_DATE`)}`;
}
