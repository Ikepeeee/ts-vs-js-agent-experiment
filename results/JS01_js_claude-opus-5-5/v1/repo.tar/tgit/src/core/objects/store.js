import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { GitError } from "../errors.js";

export const OID_HEX_LENGTH = 40;
export const MIN_ABBREV_LENGTH = 4;
export const DEFAULT_ABBREV_LENGTH = 7;

// The real git knows the empty tree without storing it, so it can be read even when no object file exists.
export const EMPTY_TREE_OID = "4b825dc642cb6eb9a060e54bf8d69288fbee4904";

export function isFullOid(text) {
  return /^[0-9a-f]{40}$/.test(text);
}

function frame(type, content) {
  return Buffer.concat([Buffer.from(`${type} ${content.length}\0`), content]);
}

export function hashObject(type, content) {
  return createHash("sha1").update(frame(type, content)).digest("hex");
}

function objectPath(gitDir, oid) {
  return path.join(gitDir, "objects", oid.slice(0, 2), oid.slice(2));
}

export function objectExists(gitDir, oid) {
  return oid === EMPTY_TREE_OID || fs.existsSync(objectPath(gitDir, oid));
}

// Writes a loose object (unless it already exists) and returns its ID.
export function writeObject(gitDir, type, content) {
  const data = frame(type, content);
  const oid = createHash("sha1").update(data).digest("hex");
  const file = objectPath(gitDir, oid);
  if (fs.existsSync(file)) return oid;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = path.join(path.dirname(file), `tmp_obj_${process.pid}_${Date.now()}`);
  fs.writeFileSync(temp, zlib.deflateSync(data), { mode: 0o444 });
  fs.renameSync(temp, file);
  return oid;
}

// Returns { type, content } or null when the object does not exist.
export function readObject(gitDir, oid) {
  let compressed;
  try {
    compressed = fs.readFileSync(objectPath(gitDir, oid));
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
    return oid === EMPTY_TREE_OID ? { type: "tree", content: Buffer.alloc(0) } : null;
  }
  const data = zlib.inflateSync(compressed);
  const space = data.indexOf(0x20);
  const nul = data.indexOf(0);
  const type = data.subarray(0, space).toString();
  const size = Number(data.subarray(space + 1, nul).toString());
  const content = data.subarray(nul + 1);
  if (content.length !== size) throw new GitError(`object ${oid} is corrupt`);
  return { type, content };
}

// The IDs of all objects whose ID starts with the given hex prefix (at least 2 digits).
export function findObjectsByPrefix(gitDir, prefix) {
  let names;
  try {
    names = fs.readdirSync(path.join(gitDir, "objects", prefix.slice(0, 2)));
  } catch (e) {
    if (e.code === "ENOENT" || e.code === "ENOTDIR") return [];
    throw e;
  }
  const rest = prefix.slice(2);
  return names
    .filter((name) => name.length === OID_HEX_LENGTH - 2 && name.startsWith(rest))
    .map((name) => prefix.slice(0, 2) + name)
    .sort();
}

// The shortest prefix of oid, at least DEFAULT_ABBREV_LENGTH long, that no other object shares.
export function abbreviate(gitDir, oid) {
  const others = findObjectsByPrefix(gitDir, oid.slice(0, 2)).filter((o) => o !== oid);
  let length = DEFAULT_ABBREV_LENGTH;
  while (length < OID_HEX_LENGTH && others.some((o) => o.startsWith(oid.slice(0, length)))) length++;
  return oid.slice(0, length);
}
