import { readObject } from "./store.js";

// Returns { tree, parents, author, committer, message }; author and committer are raw identity lines.
export function parseCommit(content) {
  const text = content.toString();
  const headerEnd = text.indexOf("\n\n");
  const header = headerEnd === -1 ? text : text.slice(0, headerEnd);
  const commit = { tree: null, parents: [], author: null, committer: null, message: headerEnd === -1 ? "" : text.slice(headerEnd + 2) };
  for (const line of header.split("\n")) {
    const space = line.indexOf(" ");
    const key = line.slice(0, space);
    const value = line.slice(space + 1);
    if (key === "tree") commit.tree = value;
    else if (key === "parent") commit.parents.push(value);
    else if (key === "author") commit.author = value;
    else if (key === "committer") commit.committer = value;
  }
  return commit;
}

export function serializeCommit({ tree, parents, author, committer, message }) {
  const lines = [`tree ${tree}`, ...parents.map((p) => `parent ${p}`), `author ${author}`, `committer ${committer}`];
  return Buffer.from(`${lines.join("\n")}\n\n${message}`);
}

// The parsed commit, or null if the object is missing or is not a commit.
export function readCommit(gitDir, oid) {
  const object = readObject(gitDir, oid);
  if (!object || object.type !== "commit") return null;
  return parseCommit(object.content);
}
