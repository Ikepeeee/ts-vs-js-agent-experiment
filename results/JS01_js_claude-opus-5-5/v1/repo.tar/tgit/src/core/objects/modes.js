// File modes as git records them in trees and in the index.
export const MODE_FILE = 0o100644;
export const MODE_EXECUTABLE = 0o100755;
export const MODE_SYMLINK = 0o120000;
export const MODE_TREE = 0o40000;

const TYPE_MASK = 0o170000;

export function isTreeMode(mode) {
  return (mode & TYPE_MASK) === MODE_TREE;
}

// Regular files and symlinks are different types; the executable bit does not change the type.
export function sameType(a, b) {
  return (a & TYPE_MASK) === (b & TYPE_MASK);
}

// The mode the index records for a file in the working tree, or null for anything git does not track.
export function modeFromStat(stat) {
  if (stat.isSymbolicLink()) return MODE_SYMLINK;
  if (stat.isFile()) return Number(stat.mode) & 0o100 ? MODE_EXECUTABLE : MODE_FILE;
  return null;
}

export function isRegularMode(mode) {
  return (mode & TYPE_MASK) === 0o100000;
}
