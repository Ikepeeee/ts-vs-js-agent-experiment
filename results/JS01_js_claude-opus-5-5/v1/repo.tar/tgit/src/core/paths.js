// Repository paths are "/"-separated and relative to the work tree root; "" is the root itself.

// Git orders paths by their UTF-8 bytes, which differs from JavaScript's UTF-16 string order.
export function comparePaths(a, b) {
  return Buffer.compare(Buffer.from(a), Buffer.from(b));
}

export function joinPath(dir, name) {
  return dir === "" ? name : `${dir}/${name}`;
}

export function isInside(path, dir) {
  return dir === "" || path === dir || path.startsWith(`${dir}/`);
}

// "a/b/c" -> ["a", "a/b"]
export function leadingDirectories(path) {
  const parts = path.split("/");
  return parts.slice(0, -1).map((_, i) => parts.slice(0, i + 1).join("/"));
}
