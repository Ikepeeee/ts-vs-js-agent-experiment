import fs from "node:fs";
import path from "node:path";
import { GitError } from "../errors.js";
import { comparePaths, leadingDirectories } from "../paths.js";
import { isFullOid } from "../objects/store.js";

// Loose references: files under .git holding either an object ID or "ref: <other ref>".

const SYMREF_PREFIX = "ref: ";
const MAX_SYMREF_DEPTH = 5;
export const BRANCH_PREFIX = "refs/heads/";

function refFile(gitDir, name) {
  return path.join(gitDir, ...name.split("/"));
}

function readRefFile(gitDir, name) {
  try {
    const stat = fs.lstatSync(refFile(gitDir, name));
    if (!stat.isFile()) return null;
    return fs.readFileSync(refFile(gitDir, name), "utf8").trim();
  } catch (e) {
    if (e.code === "ENOENT" || e.code === "ENOTDIR") return null;
    throw e;
  }
}

// Follows symbolic references. Returns { name, oid }: the last reference in the chain,
// and its object ID or null when it does not exist (an unborn branch). Returns null if name is not a reference.
export function resolveRef(gitDir, name) {
  for (let depth = 0; depth <= MAX_SYMREF_DEPTH; depth++) {
    const content = readRefFile(gitDir, name);
    if (content === null) return depth === 0 ? null : { name, oid: null };
    if (!content.startsWith(SYMREF_PREFIX)) return isFullOid(content) ? { name, oid: content } : null;
    name = content.slice(SYMREF_PREFIX.length);
  }
  return null;
}

// HEAD: { branch, oid }. branch is the full name of the branch HEAD points to ("refs/heads/main"),
// or null when HEAD is detached; oid is null on an unborn branch.
export function readHead(gitDir) {
  const content = readRefFile(gitDir, "HEAD");
  if (content?.startsWith(SYMREF_PREFIX)) {
    const branch = content.slice(SYMREF_PREFIX.length);
    return { branch, oid: resolveRef(gitDir, branch)?.oid ?? null };
  }
  return { branch: null, oid: content && isFullOid(content) ? content : null };
}

export function branchName(refName) {
  return refName.startsWith(BRANCH_PREFIX) ? refName.slice(BRANCH_PREFIX.length) : refName;
}

function writeAtomically(file, content) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const lock = `${file}.lock`;
  fs.writeFileSync(lock, content);
  fs.renameSync(lock, file);
}

function firstRefInside(dir, name) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => comparePaths(a.name, b.name))) {
    const child = `${name}/${entry.name}`;
    if (entry.isFile()) return child;
    if (entry.isDirectory()) {
      const found = firstRefInside(path.join(dir, entry.name), child);
      if (found) return found;
    }
  }
  return null;
}

// A reference cannot be created where another one is a parent directory of it, or lives below it.
function checkNameConflicts(gitDir, name) {
  const conflict = (existing) =>
    new GitError(`cannot lock ref '${name}': '${existing}' exists; cannot create '${name}'`);
  for (const dir of leadingDirectories(name)) {
    if (fs.lstatSync(refFile(gitDir, dir), { throwIfNoEntry: false })?.isFile()) throw conflict(dir);
  }
  const file = refFile(gitDir, name);
  if (fs.lstatSync(file, { throwIfNoEntry: false })?.isDirectory()) {
    const inside = firstRefInside(file, name);
    if (inside) throw conflict(inside);
    fs.rmSync(file, { recursive: true });
  }
}

export function updateRef(gitDir, name, oid) {
  checkNameConflicts(gitDir, name);
  writeAtomically(refFile(gitDir, name), `${oid}\n`);
}

// Deletes a reference and the directories it leaves empty below refs/<category>/.
export function deleteRef(gitDir, name) {
  const file = refFile(gitDir, name);
  fs.rmSync(file, { force: true });
  const refsDir = path.join(gitDir, "refs");
  for (let dir = path.dirname(file); path.relative(refsDir, dir).includes(path.sep); dir = path.dirname(dir)) {
    if (fs.readdirSync(dir).length > 0) break;
    fs.rmdirSync(dir);
  }
}

export function setSymbolicRef(gitDir, name, target) {
  writeAtomically(refFile(gitDir, name), `${SYMREF_PREFIX}${target}\n`);
}

// All branches as [{ name, oid }], with full reference names, sorted by name.
export function listBranches(gitDir) {
  const branches = [];
  const walk = (dir, prefix) => {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      if (e.code === "ENOENT") return;
      throw e;
    }
    for (const entry of entries) {
      const name = `${prefix}${entry.name}`;
      if (entry.isDirectory()) walk(path.join(dir, entry.name), `${name}/`);
      else if (entry.isFile() && !entry.name.endsWith(".lock")) {
        const oid = resolveRef(gitDir, name)?.oid;
        if (oid) branches.push({ name, oid });
      }
    }
  };
  walk(refFile(gitDir, "refs/heads"), BRANCH_PREFIX);
  return branches.sort((a, b) => comparePaths(a.name, b.name));
}
