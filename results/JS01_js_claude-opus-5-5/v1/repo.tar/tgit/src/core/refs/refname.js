// The rules of "git check-ref-format" for a full reference name such as "refs/heads/main".
export function isValidRefName(name) {
  if (name === "@" || name.includes("..") || name.includes("@{")) return false;
  // Control characters, space, and ~ ^ : ? * [ \ are not allowed.
  if ([...name].some((c) => c.charCodeAt(0) <= 0x20 || c.charCodeAt(0) === 0x7f) || /[~^:?*[\\]/.test(name)) return false;
  if (name.endsWith(".")) return false;
  return name.split("/").every((part) => part !== "" && !part.startsWith(".") && !part.endsWith(".lock"));
}

export function isValidBranchName(name) {
  return !name.startsWith("-") && name !== "HEAD" && isValidRefName(`refs/heads/${name}`);
}
