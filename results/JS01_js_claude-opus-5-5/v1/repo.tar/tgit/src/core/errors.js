// An error that ends the command. The entry point prints "<prefix>: <message>" to standard error
// and exits with exitCode; 128 is what the real git uses when it dies.
export class GitError extends Error {
  constructor(message, { exitCode = 128, prefix = "fatal" } = {}) {
    super(message);
    this.exitCode = exitCode;
    this.prefix = prefix;
  }
}
