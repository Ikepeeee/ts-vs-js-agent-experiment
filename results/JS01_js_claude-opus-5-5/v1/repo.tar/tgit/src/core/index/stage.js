import { isInside } from "../paths.js";
import { hashWorktreeFile, stageWorktreeFile } from "../worktree/files.js";

// Brings the index entries inside the given directories ("" for the whole tree) up to date
// with the working tree: modified files are staged (their blobs written) and deleted files removed.
export function stageTrackedChanges(repo, index, directories = [""]) {
  for (const entry of index.entries()) {
    if (!directories.some((dir) => isInside(entry.path, dir))) continue;
    const current = hashWorktreeFile(repo, entry.path);
    if (!current) index.delete(entry.path);
    else if (current.mode !== entry.mode || current.oid !== entry.oid) index.set(stageWorktreeFile(repo, entry.path));
    else index.set({ ...entry, stat: current.stat });
  }
}
