import { MODE_TREE } from "../objects/modes.js";
import { hashObject, objectExists, writeObject } from "../objects/store.js";
import { serializeTree } from "../objects/tree.js";

// The cache tree (the index's TREE extension) records the tree ID of each directory in the index, so
// that commits reuse trees instead of rebuilding them. Nodes are { name, entryCount, oid, subtrees },
// with oid null for an invalid node (one whose directory changed since its tree was recorded).

// Subtrees are ordered by name length first, then by bytes.
function compareSubtrees(a, b) {
  const nameA = Buffer.from(a.name);
  const nameB = Buffer.from(b.name);
  return nameA.length - nameB.length || Buffer.compare(nameA, nameB);
}

// Brings the cache tree up to date with the index entries (sorted by path) and returns the new root.
// Valid nodes whose trees exist are kept as they are; for the other directories the tree is computed.
// Normally missing trees are written. With repair, as after a checkout, a computed tree is recorded only
// if it already exists, and a directory is invalid when its tree, or the tree of a subdirectory, is missing.
export function updateCacheTree(gitDir, entries, cached = null, { repair = false } = {}) {
  const update = (name, dirEntries, prefixLength, old) => {
    if (old?.oid && objectExists(gitDir, old.oid)) return old;
    const node = { name, entryCount: dirEntries.length, oid: null, subtrees: [] };
    const treeEntries = [];
    let valid = true;
    for (let i = 0; i < dirEntries.length; ) {
      const rest = dirEntries[i].path.slice(prefixLength);
      const slash = rest.indexOf("/");
      if (slash === -1) {
        treeEntries.push({ mode: dirEntries[i].mode, name: rest, oid: dirEntries[i].oid });
        i++;
        continue;
      }
      // The entries of a directory are contiguous in path order.
      const prefix = dirEntries[i].path.slice(0, prefixLength + slash + 1);
      let end = i;
      while (end < dirEntries.length && dirEntries[end].path.startsWith(prefix)) end++;
      const subName = rest.slice(0, slash);
      const subtree = update(subName, dirEntries.slice(i, end), prefix.length, old?.subtrees.find((s) => s.name === subName));
      node.subtrees.push(subtree);
      if (subtree.oid) treeEntries.push({ mode: MODE_TREE, name: subName, oid: subtree.oid });
      else valid = false;
      i = end;
    }
    if (valid) {
      const content = serializeTree(treeEntries);
      if (!repair) {
        node.oid = writeObject(gitDir, "tree", content);
      } else {
        const oid = hashObject("tree", content);
        if (objectExists(gitDir, oid)) node.oid = oid;
      }
    }
    node.subtrees.sort(compareSubtrees);
    return node;
  };
  return update("", entries, 0, cached);
}

// Invalidates the nodes on the way to a changed index path and drops the subtree at the path itself.
export function invalidateCacheTreePath(root, path) {
  const parts = path.split("/");
  let node = root;
  for (let i = 0; node; i++) {
    node.oid = null;
    if (i === parts.length - 1) {
      node.subtrees = node.subtrees.filter((subtree) => subtree.name !== parts[i]);
      return;
    }
    node = node.subtrees.find((subtree) => subtree.name === parts[i]);
  }
}

// Each node is "<name>\0<entry count> <subtree count>\n" followed by its tree ID when valid (an invalid
// node has the entry count -1), then its subtrees.
export function parseCacheTree(data) {
  let pos = 0;
  const parse = () => {
    const nul = data.indexOf(0, pos);
    const newline = data.indexOf(0x0a, nul);
    const [entryCount, subtreeCount] = data.toString("latin1", nul + 1, newline).split(" ").map(Number);
    const node = { name: data.toString("utf8", pos, nul), entryCount, oid: null, subtrees: [] };
    pos = newline + 1;
    if (entryCount >= 0) {
      node.oid = data.toString("hex", pos, pos + 20);
      pos += 20;
    }
    for (let i = 0; i < subtreeCount; i++) node.subtrees.push(parse());
    return node;
  };
  return parse();
}

export function serializeCacheTree(root) {
  const parts = [];
  const write = (node) => {
    parts.push(Buffer.from(`${node.name}\0${node.oid ? node.entryCount : -1} ${node.subtrees.length}\n`));
    if (node.oid) parts.push(Buffer.from(node.oid, "hex"));
    node.subtrees.forEach(write);
  };
  write(root);
  return Buffer.concat(parts);
}
