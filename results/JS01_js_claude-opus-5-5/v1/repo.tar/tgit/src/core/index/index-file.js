import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { GitError } from "../errors.js";
import { comparePaths } from "../paths.js";

// Reads and writes .git/index (versions 2 and 3 are read, version 2 is written).
// Extensions are read and written as { signature, data }.
// Entry: { path, mode, oid, stage, stat }, where stat holds the cached file system data
// (ctimeSec, ctimeNsec, mtimeSec, mtimeNsec, dev, ino, uid, gid, size).

const SIGNATURE = "DIRC";
const HEADER_SIZE = 12;
const ENTRY_FIXED_SIZE = 62;
const FLAG_EXTENDED = 0x4000;
const NAME_MASK = 0xfff;
const STAT_FIELDS = ["ctimeSec", "ctimeNsec", "mtimeSec", "mtimeNsec", "dev", "ino", "mode", "uid", "gid", "size"];

export const EMPTY_STAT = { ctimeSec: 0, ctimeNsec: 0, mtimeSec: 0, mtimeNsec: 0, dev: 0, ino: 0, uid: 0, gid: 0, size: 0 };

// The cached stat data for a file, from fs.lstatSync(file, { bigint: true }).
export function statData(stat) {
  const low32 = (n) => Number(BigInt.asUintN(32, n));
  return {
    ctimeSec: low32(stat.ctimeNs / 1000000000n),
    ctimeNsec: Number(stat.ctimeNs % 1000000000n),
    mtimeSec: low32(stat.mtimeNs / 1000000000n),
    mtimeNsec: Number(stat.mtimeNs % 1000000000n),
    dev: low32(stat.dev),
    ino: low32(stat.ino),
    uid: low32(stat.uid),
    gid: low32(stat.gid),
    size: low32(stat.size),
  };
}

export function compareEntries(a, b) {
  return comparePaths(a.path, b.path) || a.stage - b.stage;
}

export function parseIndex(data) {
  if (data.length < HEADER_SIZE + 20 || data.toString("latin1", 0, 4) !== SIGNATURE) {
    throw new GitError("index file corrupt");
  }
  const version = data.readUInt32BE(4);
  if (version !== 2 && version !== 3) throw new GitError(`index file version ${version} is not supported`);
  const count = data.readUInt32BE(8);
  const entries = [];
  let pos = HEADER_SIZE;
  for (let i = 0; i < count; i++) {
    const values = STAT_FIELDS.map((_, k) => data.readUInt32BE(pos + k * 4));
    const fields = Object.fromEntries(STAT_FIELDS.map((name, k) => [name, values[k]]));
    const oid = data.toString("hex", pos + 40, pos + 60);
    const flags = data.readUInt16BE(pos + 60);
    let nameStart = pos + ENTRY_FIXED_SIZE;
    if (version === 3 && flags & FLAG_EXTENDED) nameStart += 2;
    const nameEnd = data.indexOf(0, nameStart);
    const { mode, ...stat } = fields;
    entries.push({ path: data.toString("utf8", nameStart, nameEnd), mode, oid, stage: (flags >> 12) & 3, stat });
    // Entries are padded with 1 to 8 NUL bytes to a multiple of 8 bytes.
    pos += Math.floor((nameEnd - pos + 8) / 8) * 8;
  }
  const extensions = [];
  const end = data.length - 20;
  while (pos + 8 <= end) {
    const size = data.readUInt32BE(pos + 4);
    extensions.push({ signature: data.toString("latin1", pos, pos + 4), data: data.subarray(pos + 8, pos + 8 + size) });
    pos += 8 + size;
  }
  return { entries, extensions };
}

export function serializeIndex(entries, extensions = []) {
  const sorted = [...entries].sort(compareEntries);
  const header = Buffer.alloc(HEADER_SIZE);
  header.write(SIGNATURE, 0, "latin1");
  header.writeUInt32BE(2, 4);
  header.writeUInt32BE(sorted.length, 8);
  const parts = [header];
  for (const entry of sorted) {
    const name = Buffer.from(entry.path);
    const size = Math.floor((ENTRY_FIXED_SIZE + name.length + 8) / 8) * 8;
    const buf = Buffer.alloc(size);
    const values = { ...entry.stat, mode: entry.mode };
    STAT_FIELDS.forEach((field, k) => buf.writeUInt32BE(values[field] >>> 0, k * 4));
    buf.write(entry.oid, 40, "hex");
    buf.writeUInt16BE((entry.stage << 12) | Math.min(name.length, NAME_MASK), 60);
    name.copy(buf, ENTRY_FIXED_SIZE);
    parts.push(buf);
  }
  for (const { signature, data } of extensions) {
    const header = Buffer.alloc(8);
    header.write(signature, 0, "latin1");
    header.writeUInt32BE(data.length, 4);
    parts.push(header, data);
  }
  const body = Buffer.concat(parts);
  return Buffer.concat([body, createHash("sha1").update(body).digest()]);
}

function indexFile(gitDir) {
  return path.join(gitDir, "index");
}

// The index entries in order and its extensions; empty lists when there is no index file yet.
export function readIndex(gitDir) {
  let data;
  try {
    data = fs.readFileSync(indexFile(gitDir));
  } catch (e) {
    if (e.code === "ENOENT") return { entries: [], extensions: [] };
    throw e;
  }
  return parseIndex(data);
}

export function writeIndex(gitDir, entries, extensions = []) {
  const file = indexFile(gitDir);
  const lock = `${file}.lock`;
  fs.writeFileSync(lock, serializeIndex(entries, extensions));
  fs.renameSync(lock, file);
}
