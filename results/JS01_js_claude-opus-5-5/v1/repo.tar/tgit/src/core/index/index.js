import { leadingDirectories } from "../paths.js";
import { invalidateCacheTreePath, parseCacheTree, serializeCacheTree } from "./cache-tree.js";
import { compareEntries, readIndex, writeIndex } from "./index-file.js";

// The index in memory: entries by path. tgit v1 never creates conflict stages,
// so each path has a single entry. The cache tree is kept and invalidated as entries change;
// other extensions are dropped.
export class Index {
  constructor(entries = [], cacheTree = null) {
    this.byPath = new Map(entries.map((e) => [e.path, e]));
    this.directories = null;
    // Whether entries were added, removed, or changed in mode or object since the index was read.
    this.changed = false;
    this.cacheTree = cacheTree;
  }

  static read(gitDir) {
    const { entries, extensions } = readIndex(gitDir);
    const tree = extensions.find((extension) => extension.signature === "TREE");
    return new Index(entries, tree ? parseCacheTree(tree.data) : null);
  }

  write(gitDir) {
    const extensions = this.cacheTree ? [{ signature: "TREE", data: serializeCacheTree(this.cacheTree) }] : [];
    writeIndex(gitDir, this.entries(), extensions);
  }

  get size() {
    return this.byPath.size;
  }

  get(path) {
    return this.byPath.get(path);
  }

  has(path) {
    return this.byPath.has(path);
  }

  // Adds or replaces an entry. Entries that conflict with it as file or directory are removed,
  // as when the real git adds "d" while "d/x" is tracked.
  set(entry) {
    const existing = this.byPath.get(entry.path);
    if (!existing || existing.mode !== entry.mode || existing.oid !== entry.oid || existing.stage !== entry.stage) {
      this.changed = true;
      this.invalidateCacheTree(entry.path);
    }
    if (!existing) {
      for (const dir of leadingDirectories(entry.path)) this.delete(dir);
      if (this.hasEntriesInside(entry.path)) {
        for (const path of this.byPath.keys()) {
          if (path.startsWith(`${entry.path}/`)) this.delete(path);
        }
      }
      for (const dir of leadingDirectories(entry.path)) this.directories?.add(dir);
    }
    this.byPath.set(entry.path, entry);
  }

  delete(path) {
    if (!this.byPath.delete(path)) return;
    this.directories = null;
    this.changed = true;
    this.invalidateCacheTree(path);
  }

  invalidateCacheTree(path) {
    if (this.cacheTree) invalidateCacheTreePath(this.cacheTree, path);
  }

  // Entries sorted as git sorts them.
  entries() {
    return [...this.byPath.values()].sort(compareEntries);
  }

  // Whether some tracked path lies inside the directory dir.
  hasEntriesInside(dir) {
    if (!this.directories) {
      this.directories = new Set([...this.byPath.keys()].flatMap(leadingDirectories));
    }
    return this.directories.has(dir);
  }
}
