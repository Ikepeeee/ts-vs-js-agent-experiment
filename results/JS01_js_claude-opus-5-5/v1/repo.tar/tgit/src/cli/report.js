import { GitError } from "../core/errors.js";
import { UsageError } from "./options.js";

// Exit code for an unexpected internal error, so that it is never mistaken for one of git's.
const INTERNAL_ERROR = 70;

// Prints an error to standard error and returns the exit code for it.
export function reportError(error, stderr) {
  if (!(error instanceof GitError)) {
    stderr.write(`tgit: internal error: ${error?.stack ?? error}\n`);
    return INTERNAL_ERROR;
  }
  stderr.write(`${error.prefix}: ${error.message}\n`);
  if (error instanceof UsageError && error.usage) stderr.write(`\nusage: ${error.usage}\n`);
  return error.exitCode;
}
