// Quotes a path the way git does with core.quotePath (the default): a path with control
// characters, '"', '\' or non-ASCII bytes is wrapped in double quotes with C-style escapes
// and octal bytes. "git status --porcelain" also quotes paths that contain a space.

const ESCAPES = { 0x07: "\\a", 0x08: "\\b", 0x09: "\\t", 0x0a: "\\n", 0x0b: "\\v", 0x0c: "\\f", 0x0d: "\\r", 0x22: '\\"', 0x5c: "\\\\" };

function needsEscape(byte) {
  return byte < 0x20 || byte === 0x22 || byte === 0x5c || byte >= 0x7f;
}

export function quotePath(path, { quoteSpaces = false } = {}) {
  const bytes = Buffer.from(path);
  if (!bytes.some(needsEscape) && !(quoteSpaces && path.includes(" "))) return path;
  let quoted = "";
  for (const byte of bytes) {
    if (ESCAPES[byte]) quoted += ESCAPES[byte];
    else if (needsEscape(byte)) quoted += `\\${byte.toString(8).padStart(3, "0")}`;
    else quoted += String.fromCharCode(byte);
  }
  return `"${quoted}"`;
}
