import { GitError } from "../core/errors.js";

// Command-line parsing in the style of git's parse-options: short options may be bundled
// ("-am msg") and take values attached or as the next argument ("-mmsg", "-m msg");
// long options take "--name=value" or "--name value"; options and other arguments may be mixed;
// "--" ends the options.

// An error in the command line. The real git prints the usage after it and exits with 129.
export class UsageError extends GitError {
  constructor(message, usage) {
    super(message, { exitCode: 129, prefix: "error" });
    this.usage = usage;
  }
}

// specs: [{ key, short, long, value: whether it takes a value, repeat: whether values accumulate }]
// Returns { options: { key: true | value | [values] }, args: the other arguments, in order }.
export function parseOptions(argv, specs, usage) {
  const options = {};
  const args = [];
  const set = (spec, value) => {
    if (spec.repeat) (options[spec.key] ??= []).push(value);
    else options[spec.key] = value;
  };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--") {
      args.push(...argv.slice(i + 1));
      break;
    }
    if (arg.startsWith("--")) {
      const [name, attached] = splitOnce(arg.slice(2), "=");
      const spec = specs.find((s) => s.long === name);
      if (!spec) throw new UsageError(`unknown option \`${name}'`, usage);
      if (!spec.value) {
        if (attached !== undefined) throw new UsageError(`option \`${name}' takes no value`, usage);
        set(spec, true);
      } else if (attached !== undefined) {
        set(spec, attached);
      } else {
        if (i + 1 >= argv.length) throw new UsageError(`option \`${name}' requires a value`, usage);
        set(spec, argv[++i]);
      }
    } else if (arg.startsWith("-") && arg !== "-") {
      for (let j = 1; j < arg.length; j++) {
        const spec = specs.find((s) => s.short === arg[j]);
        if (!spec) throw new UsageError(`unknown switch \`${arg[j]}'`, usage);
        if (!spec.value) {
          set(spec, true);
          continue;
        }
        if (j + 1 < arg.length) set(spec, arg.slice(j + 1));
        else if (i + 1 < argv.length) set(spec, argv[++i]);
        else throw new UsageError(`switch \`${arg[j]}' requires a value`, usage);
        break;
      }
    } else {
      args.push(arg);
    }
  }
  return { options, args };
}

function splitOnce(text, separator) {
  const at = text.indexOf(separator);
  return at < 0 ? [text, undefined] : [text.slice(0, at), text.slice(at + 1)];
}
